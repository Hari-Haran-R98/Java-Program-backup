package com.training.ui;

public class CustomerController {

}
