package com.training.model;

public class Address {

	String doorNumber;
	String cityName;
	int pincode;
	public String getDoorNumber() {
		return doorNumber;
	}
	public String getCityName() {
		return cityName;
	}
	public int getPincode() {
		return pincode;
	}
	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [doorNumber=" + doorNumber + ", cityName=" + cityName + ", pincode=" + pincode + "]";
	}
	public Address(String doorNumber, String cityName, int pincode) {
		super();
		this.doorNumber = doorNumber;
		this.cityName = cityName;
		this.pincode = pincode;
	}
	
	
}
