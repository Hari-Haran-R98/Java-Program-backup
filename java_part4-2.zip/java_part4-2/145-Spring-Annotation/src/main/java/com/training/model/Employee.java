package com.training.model;

public class Employee {

	int id;
	String name;
	double basic;
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public double getBasic() {
		return basic;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", basic=" + basic + "]";
	}
	
	
}
