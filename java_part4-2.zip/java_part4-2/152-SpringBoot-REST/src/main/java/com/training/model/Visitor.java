package com.training.model;

public class Visitor {

	int id;
	String name;
	String gender;
	int age;
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getGender() {
		return gender;
	}
	public int getAge() {
		return age;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Visitor(int id, String name, String gender, int age) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.age = age;
	}
	
	
	public Visitor() {

	}
	@Override
	public String toString() {
		return "Visitor [id=" + id + ", name=" + name + ", gender=" + gender + ", age=" + age + "]";
	}
	
	
}
