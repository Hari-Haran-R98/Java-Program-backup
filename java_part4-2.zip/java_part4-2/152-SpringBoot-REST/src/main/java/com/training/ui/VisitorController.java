package com.training.ui;

import java.util.LinkedList;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.training.model.Visitor;

@Controller
@RequestMapping("/api")
public class VisitorController {

	@GetMapping("/showVisitor")
	@ResponseBody
	public Visitor f1() {
		Visitor visitor= new Visitor(1025, "Hariharan", "Male", 24);
		return visitor;
	}
	
	@GetMapping("/visitors")
	@ResponseBody
	public List<Visitor> f2(){
		List<Visitor> allVisitors;
		allVisitors = new LinkedList<>();
		
		allVisitors.add(new Visitor(1023, "Hri", "Male", 24));
		allVisitors.add(new Visitor(1024, "Hello", "Male", 24));
		allVisitors.add(new Visitor(1025, "Gokul", "Male", 24));
		
		return allVisitors;
	}
}
