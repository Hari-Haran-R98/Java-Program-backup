package com.training.dto.request;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.model.AppUser;

public class AppUserAuthenticateRequest {

	
	private AppUser appUser;

	public AppUser getAppUser() {
		return appUser;
	}

	public void setAppUser(AppUser appUser) {
		this.appUser = appUser;
	}

	@Override
	public String toString() {
		return "AppUserAuthenticateRequest [appUser=" + appUser + "]";
	}
	
	
	
}
