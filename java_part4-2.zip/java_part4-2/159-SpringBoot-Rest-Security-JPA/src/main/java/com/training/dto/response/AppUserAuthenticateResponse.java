package com.training.dto.response;

import com.training.model.AppUser;

public class AppUserAuthenticateResponse {

	private AppUser appUser;

	private int statusCode;
	
	private String message;
	
	private String jwt;

	public AppUser getAppUser() {
		return appUser;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public String getMessage() {
		return message;
	}

	public String getJwt() {
		return jwt;
	}

	public void setAppUser(AppUser appUser) {
		this.appUser = appUser;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setJwt(String jwt) {
		this.jwt = jwt;
	}

	@Override
	public String toString() {
		return "AppUserAuthenticateResponse [appUser=" + appUser + ", statusCode=" + statusCode + ", message=" + message
				+ ", jwt=" + jwt + "]";
	}
	
	
	
	
}
