package com.training;

import java.applet.AppletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.db.StudentDAO;
import com.training.service.Studentservice;
import com.training.ui.StudentManagementController;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        ApplicationContext context;
        context=new ClassPathXmlApplicationContext("applicationContext.xml");
        
        StudentDAO dao=(StudentDAO) context.getBean("studentDAO");
        System.out.println(dao);
        
        Studentservice service=(Studentservice) context.getBean("studentservice");
        System.out.println(service);
        
        StudentManagementController controller= (StudentManagementController) context.getBean("studentManagementController");
        System.out.println(controller);
    }
}
