package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.training.service.Studentservice;

@Controller
public class StudentManagementController {

	@Autowired
	Studentservice studentservice;

	@Override
	public String toString() {
		return "StudentManagementController [studentservice=" + studentservice + "]";
	}
	
	
}
