package com.training.model;

public class Employee {

	int id;
	String name;
	double basic;
	String gender;

	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public double getBasic() {
		return basic;
	}
	public String getGender() {
		return gender;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Employee(int id, String name, double basic, String gender) {
		super();
		this.id = id;
		this.name = name;
		this.basic = basic;
		this.gender = gender;
	}
	public Employee() {
		super();
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", basic=" + basic + ", gender=" + gender + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Employee))
			return false;
		Employee other = (Employee) obj;
		if (id != other.id)
			return false;
		return true;
	}
	public double getAllowance() {
		return this.basic*0.45;
	}
	public double getTax() {
		return this.basic*0.15;
	}
	public double getNetSalary() {
		return this.basic+getAllowance()-getTax();
	}
	
}
