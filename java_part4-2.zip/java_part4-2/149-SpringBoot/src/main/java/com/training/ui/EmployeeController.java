package com.training.ui;

import java.util.Collection;
import java.util.LinkedList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.model.Employee;

@Controller
@RequestMapping(value="/employees")
public class EmployeeController {

	@GetMapping("/display")
	public String f1(Model model) {
		Employee employee= new Employee(101, "Hariharan", 1112000, "Male");
		model.addAttribute("emp", employee);
		return "EmployeeDisplay";
		
	}
	
	@GetMapping("/listing")
	public String f2(Model model) {
		Employee employee1= new Employee(101, "Hariharan", 1113000, "Male");
		Employee employee2= new Employee(102, "Hari", 1112000, "Male");
		Employee employee3= new Employee(103, "Hello", 1115000, "Male");
		Employee employee4= new Employee(104, "Akash", 1112000, "Male");
		Employee employee5= new Employee(105, "Haran", 1117000, "Male");
		Employee employee6= new Employee(106, "Ashwini", 1112000, "Female");

		Collection<Employee> employees= new LinkedList<>();
		
		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		employees.add(employee5);
		employees.add(employee6);
		model.addAttribute("emps", employees);
		return "EmployeeListing";
	}
	
}
