package com.training.dto.customer.request;

import com.training.model.Customer;

public class CustomerUpdateRequest {

	Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
	
}
