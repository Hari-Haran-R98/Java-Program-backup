package com.training.dto.response;

import com.training.model.Visitor;

public class VisitorModifyResponse {

	int statusCode;
	String description;
	Visitor visitors;
	public int getStatusCode() {
		return statusCode;
	}
	public String getDescription() {
		return description;
	}
	public Visitor getVisitors() {
		return visitors;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setVisitors(Visitor visitors) {
		this.visitors = visitors;
	}
	@Override
	public String toString() {
		return "VisitorModifyResponse [statusCode=" + statusCode + ", description=" + description + ", visitors="
				+ visitors + "]";
	}

	
}
