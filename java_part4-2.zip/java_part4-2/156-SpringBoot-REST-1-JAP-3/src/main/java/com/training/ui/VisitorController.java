package com.training.ui;

import java.util.List;

import org.slf4j.helpers.Reporter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.dto.request.VisitorAddRequest;
import com.training.dto.request.VisitorDeleteRequest;
import com.training.dto.request.VisitorUpdateRequest;
import com.training.dto.response.VisitorAddResponse;
import com.training.dto.response.VisitorDeleteResponse;
import com.training.dto.response.VisitorModifyResponse;
import com.training.dto.response.VisitorSearchResponse;
import com.training.dto.response.VisitorShowAllByCityResponse;
import com.training.dto.response.VisitorShowAllByNameResponse;
import com.training.dto.response.VisitorShowAllResponse;
import com.training.exception.VisitorNotFoundException;
import com.training.model.Visitor;
import com.training.service.VisitorService;

@RestController
@RequestMapping(value = "/api")
public class VisitorController {

	@Autowired
	VisitorService service;

	@PostMapping(value = "/add")
	public ResponseEntity<VisitorAddResponse> f1(@RequestBody VisitorAddRequest request) {
		Visitor visitor1 = this.service.addNewVisitor(request.getVisitor());
		VisitorAddResponse response = new VisitorAddResponse();
		response.setStatusCode(201);
		response.setDescription("Visitor Added succesfully");
		response.setVisitors(visitor1);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@PutMapping(value = "/modify")
	public ResponseEntity<VisitorModifyResponse> f2(@RequestBody VisitorUpdateRequest request) throws Exception {
		Visitor visitor1 = this.service.searchVisitor(request.getVisitor());
		VisitorModifyResponse response = new VisitorModifyResponse();
		if (visitor1 != null) {
			Visitor visitor2 = this.service.updateVisitor(request.getVisitor());
			response.setStatusCode(200);
			response.setDescription("Visitor updated succesfully");
			response.setVisitors(visitor2);
			return ResponseEntity.ok(response);
		} else {
			Exception exception = new VisitorNotFoundException("Visitor Not Found");
			throw exception;
//			response.setStatusCode(404);
//			response.setDescription("Visitor updated failed");
//			response.setVisitors(visitor1);
//			return new ResponseEntity(response , HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(value = "/find/{vid}")
	public ResponseEntity<VisitorSearchResponse> f3(@PathVariable(name = "vid") int vid) throws Exception {
		Visitor visitor1 = this.service.searchVisitor(vid);
		VisitorSearchResponse response = new VisitorSearchResponse();
		if (visitor1 != null) {
			response.setStatusCode(200);
			response.setDiscription("Visitor search Successfully");
			response.setSearchStatus(true);
			return ResponseEntity.ok(response);
		} else {

			Exception exception = new VisitorNotFoundException("Visitor Not Found");
			throw exception;

//			response.setStatusCode(404);
//			response.setDiscription("Visitor Not Found");
//			response.setSearchStatus(false);
//			return new ResponseEntity(response , HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(value = "/showAll", produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<VisitorShowAllResponse> f4() {
		List<Visitor> visitors = this.service.getAllVisitors();
		VisitorShowAllResponse response = new VisitorShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All Visitors Fetched");
		response.setVisitors(visitors);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value="/delete")
	public ResponseEntity<VisitorDeleteResponse>  f5(@RequestBody VisitorDeleteRequest request) throws Exception{
		VisitorDeleteResponse response= new VisitorDeleteResponse();
		Visitor visitor1= this.service.searchVisitor(request.getVisitor());
		if(visitor1 !=null){
			try {	
				this.service.deleteVisitor(request.getVisitor());
				response.setStatusCode(200);
				response.setDiscription("Visitor Deleted Successfully");
				response.setDeleteStatus(true);
				return  ResponseEntity.ok().body(response);

			}catch (Exception e) {
				response.setStatusCode(500);
				response.setDiscription("Visitor Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		}
		else {
			Exception exception = new VisitorNotFoundException("Visitor Not Found");
			throw exception;
		}
	}

//			response.setStatusCode(404);
//			response.setDiscription("Visitor Not Found");
//			response.setDeleteStatus(false);
//			return new ResponseEntity(response , HttpStatus.NOT_FOUND);

	@GetMapping("/showAllByName/{name}")
	public ResponseEntity<VisitorShowAllByNameResponse> f6(@PathVariable(name="name") String name){
		VisitorShowAllByNameResponse response= new VisitorShowAllByNameResponse();
		List<Visitor> visitorBySameName= this.service.getAllVisitorByName(name);
		
		if(visitorBySameName.isEmpty()) {
			response.setStatusCode(200);
			response.setDescription("There is no visitors by same name "+name);
			response.setVisitors(visitorBySameName);
		}
		else {
			response.setStatusCode(200);
			response.setDescription("There are "+ visitorBySameName.size() +"With Same name");
			response.setVisitors(visitorBySameName);
		}
		return ResponseEntity.ok(response);
	}

	@GetMapping("/showAllByCity")
	public ResponseEntity<VisitorShowAllByCityResponse> f7(@RequestParam(name="txt_city") String city){
		VisitorShowAllByCityResponse response= new VisitorShowAllByCityResponse();
		List<Visitor> visitorBySameCity= this.service.getAllVisitorByCity(city);
		
		if(visitorBySameCity.isEmpty()) {
			response.setStatusCode(200);
			response.setDescription("There is no visitors by same City "+city);
			response.setVisitors(visitorBySameCity);
		}
		else {
			response.setStatusCode(200);
			response.setDescription("There are "+ visitorBySameCity.size() +"With Same City");
			response.setVisitors(visitorBySameCity);
		}
		return ResponseEntity.ok(response);
	}
	
	}
