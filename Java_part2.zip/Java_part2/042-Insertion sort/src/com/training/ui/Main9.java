package com.training.ui;

import java.util.Arrays;


import com.training.model.Comparators.AccountCustomerNameComparator;
import com.training.model1.Account;

public class Main9 {
public static void main(String[] args) {
Account accounts[]= new Account[5];
	
	Account acc1= new Account("AHari", 20000.00);
	Account acc2= new Account("CHaran", 30000.00);
	Account acc3= new Account("SMuruga", 1000000.00);
	Account acc4= new Account("AKarthigaya", 20000000.00);
	Account acc5= new Account("CSaravana", 3000000.00);
	
	
	accounts[0]=acc1;
	accounts[1]=acc2;
	accounts[2]=acc3;
	accounts[3]=acc4;
	accounts[4]=acc5;
	int n=accounts.length;
	for(int i=1;i<n;i++) {
		Account key= accounts[i];
		int j=i-1;
AccountCustomerNameComparator comparator= new AccountCustomerNameComparator();
		int r=comparator.compare(accounts[j],key);
		
		while(j>=0 && r > 0) {
			accounts[j+1]=accounts[j];
			j=j-1;
			if(j>=0)
		 r=comparator.compare(accounts[j],key);
		}
		accounts[j+1]=key;
	}
	System.out.println(Arrays.toString(accounts));

}
}
