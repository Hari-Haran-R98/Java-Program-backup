package com.training.ui;

import java.util.Arrays;

import com.training.model.Comparators.EmployeeBasicSalaryDescendingComparator;
import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.SalesEmployee;

public class Main12 {
public static void main(String[] args) {
	Manager manager = new Manager(101, "Hari", "Male", "Mumbai", 10000.00, 12);
	SalesEmployee salesEmp1 = new SalesEmployee(102, "Haran", "Male", "Banglore", 1000.00, 100000.00);
	SalesEmployee salesEmp2 = new SalesEmployee(103, "Haran", "Male", "Banglore", 2000.00, 200000.00);
	Employee employee1 = new Employee(104, "Ram", "Male", "Chennai", 3000.00);
	Employee[] employees = { manager, salesEmp1, salesEmp2, employee1 };

	int n=employees.length;
	for(int i=1;i<n;i++) {
		Employee key= employees[i];
		int j=i-1;
EmployeeBasicSalaryDescendingComparator comparator= new EmployeeBasicSalaryDescendingComparator();
		int r=comparator.compare(employees[j],key);
		while(j>=0 && r > 0) {
			employees[j+1]=employees[j];
			j=j-1;
			if(j>=0)
		 r=comparator.compare(employees[j],key);
		}
		employees[j+1]=key;
	}
	System.out.println(Arrays.toString(employees));
}
}
