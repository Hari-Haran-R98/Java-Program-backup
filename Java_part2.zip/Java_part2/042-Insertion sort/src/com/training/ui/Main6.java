package com.training.ui;

import java.util.Arrays;

import com.training.model.Comparators.BillitemPriceComparator;
import com.training.model1.BillItem;

public class Main6 {
	public static void main(String[] args) {
		BillItem b1 = new BillItem("Redmi", 3, 14000.00);
		BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), new BillItem("Oppo", 4, 20000.00),
				new BillItem("IPhone", 4, 24000.00), b1 };
		int n=billItems.length;
		for(int i=1;i<n;i++) {
			BillItem key= billItems[i];
			int j=i-1;
	BillitemPriceComparator comparator= new BillitemPriceComparator();
			int r=comparator.compare(billItems[j],key);
			
			while(j>=0 && r > 0) {
				billItems[j+1]=billItems[j];
				j=j-1;
				if(j>=0)
			 r=comparator.compare(billItems[j],key);
			}
			billItems[j+1]=key;
		}
		System.out.println(Arrays.toString(billItems));

		
		
	}
}
