package com.training.ui;

import java.util.Arrays;

public class Main1 {
public static void main(String[] args) {
	int[] arr= {12,19,55,2,16};// arr{12,19,55,2,16},--,--,{12,19,55,55,16}
	
	int n=arr.length;
	for(int i=1;i<n;i++) {//i=1,i=2,i=3,4,
		int key= arr[i];//19,55,2,
		int j=i-1;//j=1-1=0,j=1,j=2,j=1-1=0,
		
		
		while(j>=0&&arr[j]>key) {//0>=0 && 12>19,1>=0 && 19>55,55>2,19>2 ,12>2
			arr[j+1]=arr[j];//--,--,(arr[2+1]=2) =(arr[2]=55) arr[3]=55,arr[2]=19,arr[1]=12,
			j=j-1;//--,--,2-1=1,1-1=0,0-1=-1,
		}
		arr[j+1]=key;//arr[1]=19,arr[2]=55,
	}
	System.out.println(Arrays.toString(arr));
}
}
