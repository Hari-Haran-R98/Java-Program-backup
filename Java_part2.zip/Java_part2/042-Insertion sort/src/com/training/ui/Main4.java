package com.training.ui;

import java.util.Arrays;

import com.training.model1.Square;

public class Main4 {
public static void main(String[] args) {
	Square[] square = new Square[4];

	Square s1 = new Square(10);
	Square s2 = new Square(25);
	Square s3 = new Square(15);
	
	square[0]=s1;
	square[1] =s2;
	square[2] =s3;
	square[3] = new Square(20);

	int n=square.length;
	for(int i=1;i<n;i++) {
		Square key= square[i];
		int j=i-1;
		int r=square[j].compareTo(key);
		
		while(j>0&& r > 0) {
			square[j+1]=square[j];
			j=j-1;
			if(j>=0)
			r=square[j].compareTo(key);
		}
		square[j+1]=key;
	}
	System.out.println(Arrays.toString(square));
}
}
