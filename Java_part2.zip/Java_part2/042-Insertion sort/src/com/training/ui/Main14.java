package com.training.ui;

import java.util.Arrays;

import com.training.model.Comparators.PersonNameComparator;
import com.training.model1.Person;

public class Main14 {
public static void main(String[] args) {
	Person p1 = new Person("CHari", 25);
	Person p2 = new Person("BHaran", 26);
	Person p3 = new Person("AMurugan", 22);
	Person p4 = new Person("ASaravana", 21);

	Person person[] = { p1, p2, p3, p4 };
	int n=person.length;
	for(int i=1;i<n;i++) {
		Person key= person[i];
		int j=i-1;
PersonNameComparator comparator= new PersonNameComparator();
		int r=comparator.compare(person[j],key);
		
		while(j>=0 && r > 0) {
			person[j+1]=person[j];
			j=j-1;
			if(j>=0)
		 r=comparator.compare(person[j],key);
		}
		person[j+1]=key;
	}
	System.out.println(Arrays.toString(person));

	

}
}
