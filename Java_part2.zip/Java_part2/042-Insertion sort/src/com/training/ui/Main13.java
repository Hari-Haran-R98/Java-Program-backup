package com.training.ui;

import java.util.Arrays;

import com.training.model1.Person;

public class Main13 {
public static void main(String[] args) {
	Person p1 = new Person("cHari", 25);
	Person p2 = new Person("bHaran", 26);
	Person p3 = new Person("aMurugan", 22);
	Person p4 = new Person("aaSaravana", 21);

	Person person[] = { p1, p2, p3, p4 };
	int n=person.length;
	for(int i=1;i<n;i++) {
		Person key= person[i];
		int j=i-1;
		int r=person[j].compareTo(key);
		
		while(j>=0 && r > 0) {
			person[j+1]=person[j];
			j=j-1;
			if(j>=0)
			r=person[j].compareTo(key);
		}
		person[j+1]=key;
	}
	System.out.println(Arrays.toString(person));

}
}
