package com.training.ui;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.training.model1.BillItem;
import com.training.model1.Circle;

public class Main14 {

	public static void main(String[] args) {
		List l1= new ArrayList<>();
		l1.add("Abcd");
		l1.add(Integer.valueOf(2000));
		l1.add(new Circle(10));
		l1.add(new BillItem("Samsung", 2, 40000.00));
		
		
		for(Object o:l1) {
			if(o instanceof Integer) {
				Integer temp=(Integer)o;
				System.out.println(temp.intValue());
			}
			if(o instanceof String) {
				String temp=(String)o;
				System.out.println(temp.toUpperCase());
			}
			if(o instanceof Circle) {
				Circle temp=(Circle)o;
				System.out.println(temp.getArea());
			}
			if(o instanceof BillItem) {
				BillItem temp=(BillItem)o;
				System.out.println(temp.getItemValue());
			}
			
			List<String> pureList= new LinkedList<>();
		}
	}
	
	
}
