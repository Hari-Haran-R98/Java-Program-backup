package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model1.BillItem;
import com.training.model1.Circle;

public class Main08 {
	public static void main(String[] args) {
		List<BillItem> billItems= new LinkedList<>();

		BillItem b1 = new BillItem("Pen", 5, 5.00);
		billItems.add(new BillItem("Pencil", 5, 2.50));
		billItems.add(new BillItem("Paper", 5, 1.50));
		billItems.add(new BillItem("File", 5, 10.00));
		billItems.add(new BillItem("Bag", 5, 1500.00));
		billItems.add(new BillItem("Note", 5, 50.00));
		int i = 1;
		
		double billAmount = 0;
		System.out.println("=======================================================");
		System.out.println("SI.No\tItem Name\tQut\tPrice\tValue");
		for (BillItem b : billItems) {

			
			billAmount += b.getItemValue();

			System.out
					.println(b + "\t" + b.getIteamName() + "\t\t" + b.getQuantity() + "\t" + b.getPrice() + "\t" + b.getItemValue());

			i++;
			
		}

		System.out.println("Total num of item  =  " +billItems.size() + "                 " + "billAmount  = " + billAmount);
	}
}