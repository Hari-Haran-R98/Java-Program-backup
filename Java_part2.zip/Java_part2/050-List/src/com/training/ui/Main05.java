package com.training.ui;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Main05 {

	public static void main(String[] args) {
		List<Integer> list= new LinkedList<>();
		
		System.out.println(list);
		System.out.println(list.size());
		System.out.println(list.isEmpty());
		
		list.add(Integer.valueOf(200));
		list.add(Integer.valueOf(400));
		list.add(Integer.valueOf(100));
		list.add(Integer.valueOf(300));
		list.add(Integer.valueOf(500));
		list.add(1000);
		list.add(1500);
		list.add(2000);
		
//		for(int i=0;i< list.size();i++) {
//			Integer city=list.get(i);
//			System.out.println(list);
//		}
//		System.out.println("=====================================");

		Integer sum=0;
		System.out.println(list);
		for(Integer list1: list) {
			
			//System.out.println(list);
			sum+=list1;
		}
		System.out.println(sum);
		System.out.println("======================================");
		
//		Iterator<String> it=cities.iterator();
//		while(it.hasNext()) {
//		String city=it.next();
//		System.out.println(city+", "+city.length());
//		}

	}
}
