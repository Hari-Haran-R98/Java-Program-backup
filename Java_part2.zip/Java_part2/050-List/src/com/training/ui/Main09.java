package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model1.Person;

public class Main09 {

	public static void main(String[] args) {
		List<Person> persons = new LinkedList();
		
		Person p= new Person("Hari", 25);
		persons.add(p);
		persons.add(new Person("Karthick", 27));
		persons.add(new Person("Bhavya", 26));
		persons.add(new Person("Keerthi", 22));
		persons.add(new Person("Jai", 24));
		System.out.println("========================================");
		System.out.println("SI.No\tPerson Name\tPerson Age");
		System.out.println("========================================");
		int i=1;
		Person maxPerson=persons.get(0);
		Person minPerson=persons.get(0);
//		Integer max1=Integer.MIN_VALUE;
//		Integer min1=Integer.MAX_VALUE;
		
		
		for(Person p1:persons) {
			
			System.out.println(i+1 + "\t" + p1.getName() + "\t\t" + p1.getAge());
			

			int r=p1.compareTo(minPerson);
			if(r<0)
			minPerson=p1;
			r=p1.compareTo(maxPerson);
			if(r>0)
				maxPerson=p1;
		
		}
		System.out.println("Younger person  "+minPerson +"  "+"Elder person  "+maxPerson );
		
	}
}
