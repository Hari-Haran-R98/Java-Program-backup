package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model1.Account;

public class Main10 {
public static void main(String[] args) {
	List<Account> accounts = new LinkedList<>();
	accounts.add(new Account("Ram", 100000.00));
	accounts.add(new Account("Mamta", 2000.00));
	accounts.add(new Account("Dinesh", 3000.00));
	accounts.add(new Account("Kiran", 4000.00));
	accounts.add(new Account("Hari", 5000.00));
	accounts.add(new Account("Haran", 6000.00));
	
	System.out.println(accounts.contains(new Account("Kiran", 4000.00)));
	
}
}
