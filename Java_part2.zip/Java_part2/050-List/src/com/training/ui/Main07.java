package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model1.Circle;

public class Main07 {

	public static void main(String[] args) {
		List<Circle> circle= new LinkedList<>();
		
		Circle c1= new Circle(20);
		circle.add(c1);
		circle.add(new Circle(40));
		circle.add(new Circle(50));
		circle.add(new Circle(70));
		circle.add(new Circle(86));
		circle.add(new Circle(92));
		
		System.out.println(circle);
		System.out.println("======================");
		
		System.out.println(circle.contains(new Circle(40)));
		
		circle.set(1, new Circle(1000));
		
		circle.remove(new Circle(50));
		
		//System.out.println(circle);
		
		Circle max= new Circle(Integer.MIN_VALUE);
		Circle min= new Circle(Integer.MAX_VALUE);
		
//		for(int i=0;i<circle.size();i++) {
//			circle.co
//		
//			if(maxcircle.get(i))
//				max=circle.get(i);
//			if(min>circle.get(i))
//				min=circle.get(i);
//		}
		for(Circle c:circle) {
			int r=c.compareTo(min);
			if(r<0)
			min=c;
			r=c.compareTo(max);
			if(r>0)
				max=c;
		}
		
		System.out.println(min +" "+ max);
		
	}
}
