package com.training.ui;

import com.training.model1.Department;

public class Main12 {

	public static void main(String[] args) {
		
		Department department= new Department("IT" , "Leela");
		department.addEmployee(101, "Deepa", "Female", "Mumbai", 1000.00);
		department.addEmployee(102, "Sri", "Female", "Cochin", 2000.00);
		department.addEmployee(103, "Karin", "Female", "Ooty", 3000.00);
		department.addEmployee(104, "Hari", "Male", "Ooty", 4000.00);
		department.addEmployee(105, "Jai", "Male", "Cbe", 5000.00);
		
		department.printReport();
		
		System.out.println(department.isEmployeePresent(102));
		System.out.println(department.findByEmployeeId(102));
		department.updateEmployee(102, "pooja", "Male", "Cbe", 2500.00);
		department.printReport();
		
		department.deleteEmployee(103);
		
		department.printReport();
	}
}
