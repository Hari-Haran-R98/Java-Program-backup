package com.training.ui;

import java.util.ArrayList;
import java.util.List;

public class Main06 {

	public static void main(String[] args) {
		List<Float> prices= new ArrayList<>();
		
		prices.add(Float.valueOf(200.0f));
		prices.add(Float.valueOf(200.0f));
		prices.add(Float.valueOf(200.0f));
		prices.add(Float.valueOf(200.0f));
		prices.add(Float.valueOf(200.0f));
		prices.add(Float.valueOf(200.0f));
		prices.add(Float.valueOf(500.0f));
		prices.add(Float.valueOf(600.0f));
		prices.add(700.0f);
		prices.add(900.0f);
		
		Float max= Float.MIN_VALUE;
		Float min= Float.MAX_VALUE;

		for(int i=0;i< prices.size();i++) {
			if(max<prices.get(i))
				max=prices.get(i);
			if(min>prices.get(i))
				min=prices.get(i);
		}
		
		System.out.println(max +", "+min);
		
	}
}
