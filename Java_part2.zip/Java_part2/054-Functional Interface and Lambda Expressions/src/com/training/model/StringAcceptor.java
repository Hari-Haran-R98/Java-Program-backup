package com.training.model;

public class StringAcceptor implements Acceptor<String> {

	@Override
	public void accept(String obj) {
		// TODO Auto-generated method stub
		System.out.println(obj.toUpperCase());
	}

}
