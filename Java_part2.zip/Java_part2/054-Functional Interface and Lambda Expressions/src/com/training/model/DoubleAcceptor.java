package com.training.model;

public class DoubleAcceptor implements Acceptor<Double> {

	@Override
	public void accept(Double obj) {
		// TODO Auto-generated method stub
		System.out.println(obj.intValue()*obj.intValue()*obj.intValue());
	}

}
