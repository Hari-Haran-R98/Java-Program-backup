package com.training.model;

public interface Tester<T> {
	boolean test(T obj);
	
	
}
