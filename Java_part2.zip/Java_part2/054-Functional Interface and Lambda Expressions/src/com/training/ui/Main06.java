package com.training.ui;

import com.training.model.Acceptor;
import com.training.model.Account;
import com.training.model.BillItem;
import com.training.model.Circle;
import com.training.model.Employee;

public class Main06 {

	public static void main(String[] args) {
		Acceptor<Circle> acceptor1;
		acceptor1=c->System.out.println(c.getRadius()+", "+c.getArea());
		acceptor1.accept(new Circle(90));
		
		Acceptor<Account> acceptor2;
		acceptor2=acc->System.out.println(acc.customerName.toUpperCase()+", "+acc.balance);
		acceptor2.accept(new Account("Hari", 200000.00));
		
		
		Acceptor<BillItem> acceptor3;
		acceptor3=bill->System.out.println(bill.toString());
		acceptor3.accept(new BillItem("Ipad",5, 200000.00));
		
		Acceptor<Employee> acceptor4;
		acceptor4=emp->System.out.println(emp.name+", "+emp.cityName.toUpperCase()+" "+emp.gender.toUpperCase()+" "+emp.getNetSalary());
		acceptor4.accept(new Employee(0, null, null, null, 0));
		
	}
}
