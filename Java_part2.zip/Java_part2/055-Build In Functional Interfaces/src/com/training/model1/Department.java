package com.training.model1;

import java.util.LinkedList;
import java.util.List;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class Department {

	String name;
	String managerName;
	List<Employee> employees;

	public Department(String name, String managerName) {
		super();
		this.name = name;
		this.managerName = managerName;
		this.employees = new LinkedList<>();
	}

	public void addEmployee(int id, String name, String gender, String city, double basic) {
		Employee e = new Employee(id, name, gender, city, basic);
		this.employees.add(e);
	}

	public void printReport() {

		int i = 1;
		double totalNetSalary = 0;
		int female = 0;
		int male = 0;
		System.out.println("Departmen Name : " + this.name);
		System.out.println("Manager Name : " + this.managerName);
		System.out.println("===========================================================================");
		System.out.println("slno       ID   Name    Gender    City         Basic Salary      NetSalary ");
		System.out.println("===========================================================================");

		for (Employee e : this.employees) {
			System.out.println(i + "\t" + e.getId() + "\t" + e.getName() + "\t" + e.getGender() + "\t" + e.getCityName()
					+ "\t\t" + e.getBasic() + "\t\t" + e.getNetSalary());
			i++;
			totalNetSalary += e.getNetSalary();
			if (e.getGender().equals("Female")) {
				female++;
			} else
				male++;
		}
		System.out.println("===========================================================================");

		System.out.println("Totol NetSalary : " + totalNetSalary);
		System.out.println("Female Count    : " + female);
		System.out.println("Male Count      : " + male);

	}

	public boolean isEmployeePresent(int id) {
		Employee emp = new Employee();
		emp.setId(id);
		boolean result = this.employees.contains(emp);
		return result;
	}

	public Employee findByEmployeeId(int id) {
		Employee emp = new Employee();
		emp.setId(id);
		int result = this.employees.indexOf(emp);
		if (result == -1)
			return null;
		else
			return this.employees.get(result);
	}

	public void updateEmployee(int id, String name, String gender, String city, double basic) {
		Employee emp = new Employee();
		emp.setId(id);
		int indexResult = this.employees.indexOf(emp);
		if (indexResult == -1) {
			System.out.println("Employee Not Found....");
		} else {
			Employee temp = new Employee(id, name, gender, city, basic);
			this.employees.set(indexResult, temp);
		}
	}

	public void deleteEmployee(int id) {
		Employee emp = new Employee();
		emp.setId(id);
		this.employees.remove(emp);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
}
