package com.training.model1;

public class Payment implements Comparable<Payment>{
String month;
double paymentAmount;
@Override
public int compareTo(Payment o) {
	if(this.paymentAmount<o.paymentAmount)
	return -1;

	if(this.paymentAmount>o.paymentAmount)
	return 1;
	
	return 0;
}
public String getMonth() {
	return month;
}
public void setMonth(String month) {
	this.month = month;
}
public double getPaymentAmount() {
	return paymentAmount;
}
public void setPaymentAmount(double paymentAmount) {
	this.paymentAmount = paymentAmount;
}
public Payment(String month, double paymentAmount) {
	super();
	this.month = month;
	this.paymentAmount = paymentAmount;
}

}
