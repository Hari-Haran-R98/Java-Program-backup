package com.training.model1;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Course  {
private String courseName;
private Set<CourseItem> courseItems;
public Course(String courseName) {
	super();
	this.courseName = courseName;
	this.courseItems= new HashSet<>();
	
}

public void addCourseItem(String subjectName, int duration, double fees) {
	CourseItem courItem= new CourseItem(subjectName, duration, fees);
	this.courseItems.add(courItem);
}

public void printCourseDetail() {
	System.out.println("--------------------------------------------------------------------");
	System.out.println("Course Number : "+ this.courseName );
	System.out.println("--------------------------------------------------------------------");
	System.out.println("Slno    Subject Name        Duration    Fees  ");
	
	int slno=1;
	
	for(CourseItem c:this.courseItems) {
		System.out.printf("\n %d%15SSs\t%7d\t%13.2f",
				slno,
				c.getSubjectName(),
				c.getDurationInHours(),
				c.getFees());
		slno++;
	}
	System.out.println("   ");
	System.out.println("--------------------------------------------------------------------");

	
}

public String getCourseName() {
	return courseName;
}

public void setCourseName(String courseName) {
	this.courseName = courseName;
}

public Set<CourseItem> getCourseItems() {
	return courseItems;
}

public void setCourseItems(Set<CourseItem> courseItems) {
	this.courseItems = courseItems;
}


}
