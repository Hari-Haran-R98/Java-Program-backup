package com.training.ui;

import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

import com.training.model1.BillItem;
import com.training.model1.Circle;
import com.training.model1.Course;
import com.training.model1.CourseItem;
import com.training.model1.Department;
import com.training.model1.Employee;

public class Main02 {

	static void process(Consumer<Circle> c) {
		Circle circle = new Circle(10);
		c.accept(circle);
	}

	static void process1(Consumer<Department> d) {
		Department department = new Department("It", "Bhavya");
		department.addEmployee(101, "Hariharan", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Harshit", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Ajith", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Arun", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Kishor", "male", "Delhi", 10000.00);
		d.accept(department);
	}

	static void process2(Consumer<Course> c) {
		Course course = new Course("Diploma in Web Development");

		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("JQuery", 35, 3500.00);
		course.addCourseItem("Knockout js", 15, 5500.00);
		course.addCourseItem("Angular", 50, 8600.00);
		c.accept(course);
	}

	public static void main(String[] args) {
		Consumer<BillItem> consumer1;
		consumer1 = bi -> System.out.println(bi.getIteamName() + ", " + bi.getItemValue());
		consumer1.accept(new BillItem("Samsung", 5, 500000.00));

		Consumer<Department> consumer2;
		consumer2 = dep -> System.out.println(dep.getName() + ", " + dep.getManagerName());
		consumer2.accept(new Department("Hari", "Murugan"));

		Department department = new Department("It", "Bhavya");
		department.addEmployee(101, "Hariharan", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Harshit", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Ajith", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Arun", "male", "Delhi", 10000.00);
		department.addEmployee(101, "Kishor", "male", "Delhi", 10000.00);

		Consumer<Department> consumer3;
		consumer3 = d -> {
			List<Employee> empList = d.getEmployees();
			double sum = 0.0;
			for (Employee e : empList) {
				sum = sum + e.getBasic();
			}
			System.out.println("Total Salary : " + sum);
		};

		consumer3.accept(department);

		Consumer<Department> consumer4;

		consumer4 = d -> d.printReport();
		consumer4.accept(department);

		Course course = new Course("Diploma in Web Development");

		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("JQuery", 35, 3500.00);
		course.addCourseItem("Knockout js", 15, 5500.00);
		course.addCourseItem("Angular", 50, 6500.00);

		Consumer<Course> consumer5;
		consumer5 = c -> c.printCourseDetail();

		consumer5.accept(course);

		Consumer<Circle> consumer6;
		consumer6 = c -> System.out.println(c.getRadius() + ", " + c.getArea());
		process(consumer6);

		process1((d) -> d.printReport());

		process2(crs -> {
			int total = 0;
			Set<CourseItem> itemSet = crs.getCourseItems();
			for (CourseItem cit : itemSet) {
				total += cit.getDurationInHours();
			}
			System.out.println("Total Duration : " + total);

		});
	}

}
