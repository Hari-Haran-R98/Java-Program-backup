package com.training.ui;

import java.util.function.Function;

import com.training.model1.Circle;
import com.training.model1.Employee;
import com.training.model1.Payment;
import com.training.model1.Person;
import com.training.model1.Square;

public class Main05 {

	public static void main(String[] args) {
		Function<Integer, Circle> function1;
		function1=(Integer i)->{
			return new Circle(i.intValue());
		};
		Circle c=function1.apply(5);
		System.out.println(c);
		
		
		Function<Integer, Square> function2;
		function2=i->new Square(i.intValue());
		Square s=function2.apply(6);
		System.out.println(s);
		
		Function<Employee, String> function3;
		function3=(e)->e.getName();
		
		Employee e= new Employee(101, "Hariharan", "Male", "Delhi", 99000.00);
		String ename=function3.apply(e);
		System.out.println(ename);
		
		Function<Employee, String> function4;
		function4=(emp)->emp.getCityName();
		String ecity=function4.apply(e);
		System.out.println(ecity);
		
		Function<Employee, Double> function5;
		function5=(emp)->emp.getBasic();
		Double ebasic=function5.apply(e);
		System.out.println(ebasic);
		
		Payment payment= new Payment("Jan", 300000.00);
		Function<Payment, String> function6;
		function6=(p)->p.getMonth();
		String month= function6.apply(payment);
		System.out.println("Payment month"+month);
		
		
		Function<Payment, Double> function7;
		function7=(p)->p.getPaymentAmount();
		Double pay=function7.apply(payment);
		System.out.println("Payment Amount"+pay);

		Person person = new Person("Hari", 26);
		Function<Person, String> function8;
		function8=(p)->p.getName();
		String name= function8.apply(person);
		System.out.println("Person Name"+name);
		
		
		Function<Person, Integer> function9;
		function9=(p1)->p1.getAge();
		Integer age=function9.apply(person);
		System.out.println("Person age :"+age);

		
	}
}
