package com.training.ui;

import java.util.function.Predicate;

import com.training.model1.Circle;
import com.training.model1.Course;
import com.training.model1.Department;
import com.training.model1.Square;

public class Main03 {

	static void process1(Predicate<Circle> predicate) {
		Circle c= new Circle(20);
		System.out.println(predicate.test(c));
	}
	
	public static void main(String[] args) {
		process1(circle->circle.getRadius()>10);
		process2(s->s.getSize()>=50);
		process3(dept->dept.getEmployees().size()>=10);
		process4(course-> course.getCourseItems().size()>=3);
	}
	
	static void process2(Predicate<Square> predicate) {
		Square square= new Square(100);
		System.out.println(predicate.test(square));
	}
	static void process3(Predicate<Department>predicate) {
		Department department= new Department("It", "Bhavya");
		department.addEmployee(101, "Hariharan", "male", "Delhi", 10000.00);
		department.addEmployee(102, "Harshit", "male", "Delhi", 10000.00);
		department.addEmployee(103, "Ajith", "male", "Delhi", 10000.00);
		department.addEmployee(104, "Arun", "male", "Delhi", 10000.00);
		department.addEmployee(105, "Kishor", "male", "Delhi", 10000.00);
		System.out.println(predicate.test(department));
	}
	static void process4(Predicate<Course>predicate) {
		Course course = new Course("Diploma in Web Development");

		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("JQuery", 35, 3500.00);
		course.addCourseItem("Knockout js", 15, 5500.00);
		course.addCourseItem("Angular", 50, 8600.00);
		
		System.out.println(predicate.test(course));
		
	}
}
