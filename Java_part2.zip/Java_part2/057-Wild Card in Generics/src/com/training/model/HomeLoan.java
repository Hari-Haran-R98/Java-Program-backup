package com.training.model;

public class HomeLoan extends Loan {

	
}
