package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.CarLoan;
import com.training.model.CollegeEducationLoan;
import com.training.model.EducationLoan;
import com.training.model.HomeLoan;
import com.training.model.Loan;

public class Main01 {

	static void print1(List<? extends Loan> loans) {
		System.out.println(loans);
	}
	
	static void print2(List<? extends CarLoan> loans) {
		System.out.println(loans);
	}
	static void print3(List<? extends EducationLoan> loans) {     //? extends --> this is used for wild card 
		System.out.println(loans);
	}
	static void print4(List<? super EducationLoan> loans) {
		
	System.out.println(loans);
	}
		static void print5(List<?> loans) {
		System.out.println(loans);	
		}
		static void print6(List<? extends HomeLoan> loans) {
			System.out.println(loans);	
			}
	public static void main(String[] args) {
		List<Loan> loans = new LinkedList<>();
		print1(loans);
		
		List<CarLoan> cloans= new LinkedList<>();
		print2(cloans);
		

		List<EducationLoan> eloans= new LinkedList<>();
		print3(eloans);
		
		
		List<CollegeEducationLoan> collegeloans= new LinkedList<>();
		print3(collegeloans);
		
		List<CollegeEducationLoan> celoan = new LinkedList<>();
		print1(celoan);
		
		print4(loans);

		print5(collegeloans);
		print5(eloans);
		print5(cloans);
		print5(loans);
		print5(celoan);
		
		List<Integer> ilist= new LinkedList<>();
		print5(ilist);
		
		List<HomeLoan> hloans= new LinkedList<>();
		print1(hloans);
		print2(hloans);
		print3(hloans);
		print4(hloans);
		print5(hloans);
		print6(hloans);
		
		
		
	}
}
