package com.training.ui;

import java.util.Set;
import java.util.TreeSet;

import com.training.model.Comparators.BillitemPriceComparator;
import com.training.model.Comparators.BillitemQuantityComparator;
import com.training.model1.BillItem;

public class Main06 {

	public static void main(String[] args) {
		Set<BillItem> billItemSet = new TreeSet<>();

		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Iphone", 12, 60000.00));
		billItemSet.add(new BillItem("Oppo", 8, 17000.00));
		billItemSet.add(new BillItem("Dell Laptop", 3, 15000.00));
		billItemSet.add(new BillItem("Samsung", 15, 810000.00));
		billItemSet.add(new BillItem("Nokia", 10, 10000.00));

		billItemSet.stream().sorted().forEach(b->System.out.println(b));
		
	System.out.println("========================================================");	
		
	billItemSet.stream().mapToInt(b-> b.getQuantity()).forEach(q->System.out.println(q));
	
	System.out.println("========================================================");	

	billItemSet.stream().sorted(new BillitemPriceComparator()).forEach(p->System.out.println(p));
	

	System.out.println("========================================================");	

	billItemSet.stream().sorted(new BillitemPriceComparator().reversed()).forEach(p->System.out.println(p));
	

	System.out.println("========================================================");	

	billItemSet.stream().sorted(new BillitemPriceComparator()).forEach(p->System.out.println(p));
	
	System.out.println("========================================================");	

	billItemSet.stream().sorted(new BillitemQuantityComparator()).forEach(p->System.out.println(p));

	}
}
