package com.training.ui;

import java.util.LinkedList;
import java.util.List;

public class Main07 {

	public static void main(String[] args) {
		List<Integer> ilist= new LinkedList<>();
		
		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(150));
		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(140));
		ilist.add(Integer.valueOf(210));
		ilist.add(Integer.valueOf(100));
		ilist.add(Integer.valueOf(15));
		ilist.add(Integer.valueOf(1800));
		ilist.add(Integer.valueOf(14));
		
		ilist.stream().limit(5).forEach(i->System.out.println(i));
		System.out.println("==================================================");
		
		ilist.stream()
		.distinct()
		.forEach(i->System.out.println(i));
		
		
	}
}
