package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;

public class Main11 {

	public static void main(String[] args) {

		List<Integer> ilist = new LinkedList<>();

		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(150));
		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(140));
		ilist.add(Integer.valueOf(210));
		ilist.add(Integer.valueOf(100));
		ilist.add(Integer.valueOf(15));
		ilist.add(Integer.valueOf(180));
		ilist.add(Integer.valueOf(14));

		Predicate<Integer> pr = (i -> i >= 100);
		boolean result1 = ilist.stream().anyMatch(i -> i >= 500);
		System.out.println(result1);

		boolean result2 = ilist.stream().allMatch(i -> i >= 100);
		System.out.println(result2);

		boolean result3 = ilist.stream().noneMatch(i -> i == 58);
		System.out.println(result3);

	}
}
