package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model1.Circle;

public class Main02 {

	public static void main(String[] args) {
List<Integer> ilist= new LinkedList<>();
		
		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(10));
		ilist.add(Integer.valueOf(50));
		ilist.add(Integer.valueOf(80));
		ilist.add(Integer.valueOf(140));
		
		
		ilist
		.stream()
		.sorted()
		.filter(i->i>100)
		.forEach(i->System.out.println(i));
		
		List<String> cities= new LinkedList<>();
		cities.add("Pune");
		cities.add("Patna");
		cities.add("Kolkatta");
		cities.add("Cochin");
		
		cities
		.stream()
		.sorted().filter(i->i.length()>=6)
		.forEach(i->System.out.println(i));
		
		List<Circle> circles= new LinkedList<>();
		circles.add(new Circle(10));
		circles.add(new Circle(200));
		circles.add(new Circle(30));
		circles.add(new Circle(400));
	
		circles.stream().sorted().filter(i-> i.getRadius()>=100).forEach(i-> System.out.println(i));
		
	}
}
