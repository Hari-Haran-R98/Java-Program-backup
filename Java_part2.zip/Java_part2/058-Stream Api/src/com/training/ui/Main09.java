package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import com.training.model.Comparators.PersonNameComparator;
import com.training.model1.Person;

public class Main09 {

	public static void main(String[] args) {
		List<Person> allPersons= new LinkedList<>();
		allPersons.add(new Person("Hari", 26));
		allPersons.add(new Person("Haran", 29));
		allPersons.add(new Person("Krishna", 36));
		allPersons.add(new Person("Radha", 30));
		allPersons.add(new Person("Murugar", 25));
		allPersons.add(new Person("Vali", 23));
		allPersons.add(new Person("Ashwin", 29));
		allPersons.add(new Person("Lakshmi", 35));
		
		Optional<Person> optionalResult= allPersons.stream().min(new PersonNameComparator());
		if(optionalResult.isPresent()) {
			System.out.println(optionalResult.get());
		}
		else {
		System.out.println("Collection is empty");}
	
		Optional<Person> optionalResult1= allPersons.stream()
		.min((p1,p2)->p1.getAge()-p2.getAge());
		
		if(optionalResult1.isPresent()) {
			System.out.println(optionalResult1.get());
		}
		else {
		System.out.println("Collection is empty");}
		
		Optional<Person> optionalResult3= allPersons.stream().max((p1,p2)->p1.getAge()-p2.getAge());

		System.out.println(optionalResult3);
	
		Optional<Person> optionalResult4= allPersons.stream().max(new PersonNameComparator());
		System.out.println(optionalResult4);
		
	}
}
