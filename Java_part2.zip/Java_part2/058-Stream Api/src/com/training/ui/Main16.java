package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import com.training.model1.Payment;

public class Main16 {
	public static void main(String[] args) {

		List<Payment> allPayments = new LinkedList<>();
		allPayments.add(new Payment("Jan", 100.00));
		allPayments.add(new Payment("Feb", 1200.00));
		allPayments.add(new Payment("Jan", 250.00));
		allPayments.add(new Payment("Feb", 350.00));
		allPayments.add(new Payment("Jan", 260.00));
		allPayments.add(new Payment("Mar", 206.0));
		allPayments.add(new Payment("Feb", 350.00));
		allPayments.add(new Payment("Mar", 350.00));
		allPayments.add(new Payment("Feb", 206.0));

		Map<String, Long> byMonth = allPayments.stream()
				.collect(Collectors.groupingBy(Payment::getMonth, Collectors.counting()));

		System.out.println(byMonth);

		Map<String, Double> totalMonthdue = allPayments.stream()
				.collect(Collectors.groupingBy(Payment::getMonth, Collectors.summingDouble(Payment::getPaymentAmount)));

		System.out.println(totalMonthdue);

		Map<String, List<Payment>> bydueMonth = allPayments.stream().collect(Collectors.groupingBy(Payment::getMonth));

		System.out.println(bydueMonth);
	}
}
