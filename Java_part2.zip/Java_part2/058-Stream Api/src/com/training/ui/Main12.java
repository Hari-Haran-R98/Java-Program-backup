package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;

import com.training.model1.Circle;

public class Main12 {

	public static void main(String[] args) {
		List<Circle> circles = new LinkedList<>();
		circles.add(new Circle(5));
		circles.add(new Circle(7));
		circles.add(new Circle(3));
		circles.add(new Circle(8));
		circles.add(new Circle(2));

		boolean result1 = circles.stream().anyMatch(i -> i.getRadius() > 10);
		System.out.println(result1);

		boolean result2 = circles.stream().allMatch(i -> i.getRadius() > 2);
		System.out.println(result2);

		boolean result3 = circles.stream().noneMatch(i -> i.getRadius() == 2);
		System.out.println(result3);

	}
}
