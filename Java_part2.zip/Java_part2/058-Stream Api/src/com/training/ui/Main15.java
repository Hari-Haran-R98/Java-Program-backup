package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model1.BillItem;

public class Main15 {

	public static void main(String[] args) {
		List<BillItem> billitems= new LinkedList<>();
		billitems.add(new BillItem("Redmi", 10, 100.00));
		billitems.add(new BillItem("Iphone", 12, 60.00));
		billitems.add(new BillItem("Oppo", 8, 170.00));
		billitems.add(new BillItem("Dell Laptop", 3, 150.00));
		billitems.add(new BillItem("Samsung", 15, 810.00));
		billitems.add(new BillItem("Redmi", 10, 100.00));

		double r= billitems.stream().map(e->e.getItemValue()).reduce(0.0, (b1,b2)->b1+b2);
		System.out.println(r);
	}
}
