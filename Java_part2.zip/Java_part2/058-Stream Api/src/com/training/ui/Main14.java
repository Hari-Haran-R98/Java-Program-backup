package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.training.model1.Employee;

public class Main14 {

	public static void main(String[] args) {
		Map<Integer, Employee> empMap = new TreeMap<>();
		Employee e1 = new Employee(101, "Muruga", "Male", "Banglore", 100000.00);
		Employee e2 = new Employee(102, "Saravana", "Male", "Chennai", 200000.00);
		Employee e3 = new Employee(103, "Bala", "Male", "Cochin", 300000.00);
		Employee e4 = new Employee(104, "Kumari", "female", "Banglore", 40000.00);
		Employee e5 = new Employee(105, "Harini", "female", "Chennai", 10000.00);
		Employee e6 = new Employee(106, "Haran", "Male", "Cochin", 10000.00);
		Employee e7 = new Employee(107, "Ashwini", "female", "Chennai", 20000.00);
		Employee e8 = new Employee(108, "Gopika", "female", "Cochin", 300000.00);
		Employee e9 = new Employee(109, "Ram", "Male", "Cochin", 100000.00);
		Employee e10 = new Employee(110, "Krishna", "Male", "Banglore", 10000.00);
		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);


		double r= allEmployees.stream().map(e->e.getBasic()).reduce(0.0, (b1,b2)->b1+b2);
		System.out.println(r);
	}
}
