package com.training.ds;

public class QueueImpl<T> implements Queue<T> {

	@Override
	public void enQueue(T object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}

}
