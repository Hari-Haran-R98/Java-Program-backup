package com.training.ds;

public class StringQueueImpl implements Queue<String>{

	@Override
	public void enQueue(String object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}

}
