package com.training.ds;

import com.training.model1.Circle;

public class CircleQueueImpl implements Queue<Circle>{

	@Override
	public void enQueue(Circle object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Circle deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}


}
