package com.training.ds;

import com.training.model1.Square;

public class SquareQueueImpl implements Queue<Square>{

	@Override
	public void enQueue(Square object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Square deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}

}
