package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Course;

public class CourseFeesComparator implements Comparator<Course>{

	@Override
	public int compare(Course o1, Course o2) {

		if(o1.getFees()<o2.getFees())
			return -1;
		
		
		if(o1.getFees()>o2.getFees())
			return 1;
		// TODO Auto-generated method stub
		
		
		return 0;
	}

}
