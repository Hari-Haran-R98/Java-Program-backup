package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.BillItem;

public class BillitemPriceComparator implements Comparator<BillItem> {
	
	
	@Override
	public int compare(BillItem o1, BillItem o2) {
		
		if(o1.getPrice()<o2.getPrice())
			return -1;
		
		
		if(o1.getPrice()>o2.getPrice())
			return 1;
		// TODO Auto-generated method stub
		
		
		return 0;
	}

	
}
