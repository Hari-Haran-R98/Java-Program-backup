package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.BillItem;

public class BillitemQuantityComparator 
	implements Comparator<BillItem> {
		
		
		@Override
		public int compare(BillItem o1, BillItem o2) {
			
			if(o1.getQuantity()<o2.getQuantity())
				return -1;
			
			
			if(o1.getQuantity()>o2.getQuantity())
				return 1;
			// TODO Auto-generated method stub
			
			
			return 0;
		}
}
