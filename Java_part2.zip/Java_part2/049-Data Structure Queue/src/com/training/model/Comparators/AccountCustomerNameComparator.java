package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Account;

public class AccountCustomerNameComparator implements Comparator<Account> {

	@Override
	public int compare(Account o1, Account o2) {
		
		
		int r= o1.getCustomerName().compareTo(o2.getCustomerName());
		
		
		// TODO Auto-generated method stub
		return r;
	}
	

}
