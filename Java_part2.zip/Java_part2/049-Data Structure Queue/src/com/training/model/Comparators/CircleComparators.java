package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Circle;

public class CircleComparators implements Comparator<Circle> {

	@Override
	public int compare(Circle o1, Circle o2) {
		// TODO Auto-generated method stub
		if(o1.getRadius()<o2.getRadius())
			return -1;
		
		
		if(o1.getRadius()>o2.getRadius())
			return 1;
		// TODO Auto-generated method stub
		
		
		
		return 0;
	}

}
