package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Course;

public class CourseNameComparator implements Comparator<Course>{

	@Override
	public int compare(Course o1, Course o2) {
		// TODO Auto-generated method stub
		int r= o1.getCourseName().compareTo(o2.getCourseName());
		return r;
	}

}
