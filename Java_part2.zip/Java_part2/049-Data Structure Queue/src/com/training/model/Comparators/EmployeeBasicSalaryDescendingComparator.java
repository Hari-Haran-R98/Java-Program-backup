package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Employee;

public class EmployeeBasicSalaryDescendingComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		
		if(e1.getBasic()<e2.getBasic())
			return 1;
		
		
		if(e1.getBasic()>e2.getBasic())
			return -1;
		// TODO Auto-generated method stub

		return 0;
	}

}
