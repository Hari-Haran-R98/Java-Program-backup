package com.training.model;

import java.io.IOException;

public class D extends C{

	@Override
	public void test1() {
		
	}
	@Override
public void test2()throws IOException {
		
	}
	@Override
	public void test3()throws InterruptedException{
			
		}
	@Override
	public void test4() throws ArrayIndexOutOfBoundsException,ArithmeticException,NullPointerException{
		
	}
	@Override
	public void test5() throws Exception{
		
	}

	@Override
	public void test6() throws ArrayIndexOutOfBoundsException,RuntimeException{
	}
	
}
