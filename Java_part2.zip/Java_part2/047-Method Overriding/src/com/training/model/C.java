package com.training.model;

import java.io.IOException;
import java.sql.SQLException;

public class C {

	public void test1()throws IOException,ArrayIndexOutOfBoundsException,ArithmeticException {
		
	}
	public void test2() throws IOException,SQLException{
		
	}
	public void test3()throws IOException,SQLException {
		
	}
	public void test4() throws ArrayIndexOutOfBoundsException,RuntimeException{
		
	}
public void test5() throws ArrayIndexOutOfBoundsException,RuntimeException{
		
	}
public void test6() throws Exception{
	
}
}
