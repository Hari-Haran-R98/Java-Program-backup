package com.training.model;

public class J extends I{

	@Override
	public Car create() {
		return new Car();
	}
	
}
