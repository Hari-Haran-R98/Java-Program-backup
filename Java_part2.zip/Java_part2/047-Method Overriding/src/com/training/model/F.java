package com.training.model;

public class F extends E{
	@Override
	public void print(int n)  {
if(n<0);
Exception e=new Exception("Invalid Value");
try {
throw e;
}
catch (Exception e1) {
	// TODO: handle exception
System.out.println(e1);
}
	}

}
