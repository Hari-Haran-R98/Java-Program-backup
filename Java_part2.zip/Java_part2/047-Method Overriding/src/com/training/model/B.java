package com.training.model;

import java.sql.SQLException;

public class B extends A{
	@Override
	public void test1() throws SQLException {
		
	}

	public void test2()throws Exception{
		
	}
}
