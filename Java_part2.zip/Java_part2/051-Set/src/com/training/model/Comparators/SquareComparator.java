package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Square;

public class SquareComparator implements Comparator<Square>{

	@Override
	public int compare(Square o1, Square o2) {
		// TODO Auto-generated method stub
		return o2.getSize()-o1.getSize();
	}

	
}
