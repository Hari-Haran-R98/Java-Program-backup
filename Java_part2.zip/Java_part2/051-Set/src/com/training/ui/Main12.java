package com.training.ui;

import com.training.model1.Course;

public class Main12 {

	public static void main(String[] args) {
		
		Course course= new Course("Diploma in Web Development");
		
		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("JQuery", 35, 3500.00);
		course.addCourseItem("Knockout js", 15, 5500.00);
		course.addCourseItem("Angular", 50, 6500.00);
		
		course.printCourseDetail();
	}
}
