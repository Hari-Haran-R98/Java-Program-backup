package com.training.ui;

import java.util.Set;
import java.util.TreeSet;

import com.training.model.Comparators.SquareComparator;
import com.training.model1.Square;

public class Main13 {

	public static void main(String[] args) {
		
		SquareComparator comparator= new SquareComparator();
		
		Set<Square> squares= new TreeSet<>(comparator);
		
		squares.add(new Square(30));
		squares.add(new Square(40));
		squares.add(new Square(10));
		squares.add(new Square(20));
		
		System.out.println(squares);
		
		System.out.println(squares.contains(new Square(20)));
	}
}
