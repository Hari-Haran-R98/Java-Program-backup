package com.training.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.training.model.Comparators.BillitemPriceComparator;
import com.training.model.Comparators.BillitemQuantityComparator;
import com.training.model1.BillItem;

public class Main09 {

	public static void main(String[] args) {

		BillitemQuantityComparator comparator= new BillitemQuantityComparator();
		
		Set<BillItem> billItemSet = new TreeSet<>(comparator);

		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Iphone", 12, 60000.00));
		billItemSet.add(new BillItem("Oppo", 8, 17000.00));
		billItemSet.add(new BillItem("Dell Laptop", 3, 15000.00));
		billItemSet.add(new BillItem("Samsung", 15, 810000.00));
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));

		System.out.println(billItemSet.size());
		System.out.println(billItemSet);

	}
}
