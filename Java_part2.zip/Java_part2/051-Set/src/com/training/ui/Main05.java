package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.training.model.Comparators.BillitemPriceComparator;
import com.training.model1.BillItem;

public class Main05 {
	public static void main(String[] args) {
		Set<BillItem> billItemSet = new HashSet<>();

		billItemSet.add(new BillItem("Redmi", 10, 10000.00));
		billItemSet.add(new BillItem("Iphone", 12, 60000.00));
		billItemSet.add(new BillItem("Oppo", 8, 17000.00));
		billItemSet.add(new BillItem("Dell Laptop", 3, 15000.00));
		billItemSet.add(new BillItem("Samsung", 15, 810000.00));
		billItemSet.add(new BillItem("Redmi", 10, 10000.00));

		System.out.println(billItemSet);

		BillItem searchBillItem = new BillItem("Oppo", 1, 1000.00);

		System.out.println(billItemSet.contains(searchBillItem));

		billItemSet.remove(new BillItem("Redmi", 20, 200000.00));

		System.out.println(billItemSet);

		double total = 0.0;

		Iterator<BillItem> it = billItemSet.iterator();
		while (it.hasNext()) {
			BillItem bill = it.next();
			total = total + bill.getItemValue();
		}
		System.out.println("The total value if the bill is : " + total);

		BillitemPriceComparator comparator = new BillitemPriceComparator();
		BillItem lowestPriceBillItem = new BillItem("", Integer.MAX_VALUE, Double.MAX_VALUE);
		for (BillItem b : billItemSet) {
			int r = comparator.compare(b, lowestPriceBillItem);
			if (r < 0)
				lowestPriceBillItem = b;
		}
		System.out.println(lowestPriceBillItem);
		
		billItemSet.clear();
		System.out.println(billItemSet.isEmpty());
	}
	

}
