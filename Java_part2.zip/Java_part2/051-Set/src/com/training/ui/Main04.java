package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.training.model1.Account;

public class Main04 {
public static void main(String[] args) {
	Set<Account> accSet= new HashSet<>();
	
	accSet.add(new Account("Murugan", 6000.00));
	accSet.add(new Account("Saravana", 6500.00));
	accSet.add(new Account("Ram", 1000.00));
	accSet.add(new Account("Hello", 1000.00));
	accSet.add(new Account("Hari", 900.00));
	accSet.add(new Account("Haran", 900.00));
	accSet.add(new Account("Hari", 1000.00));
	
	
	System.out.println(accSet);
	
	Account searchAcc= new Account("Hari", 1200.00);
	System.out.println(accSet.contains(searchAcc));

	Account searchAcc1= new Account("Hello", 1200.00);

	accSet.remove(searchAcc1);
	
	System.out.println(accSet);
	
	double sum=0.0;
	
	Iterator<Account> it= accSet.iterator();
	while(it.hasNext()) {
		Account acc= it.next();
		sum=sum+acc.getBalance();
	}
	System.out.println(sum);
	accSet.clear();
	System.out.println(accSet.isEmpty());
	
	System.out.println(accSet.size());
}
}
