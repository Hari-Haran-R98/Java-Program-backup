package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Main03 {

	public static void main(String[] args) {

		Set<String> set = new HashSet<>();
		set.add("Murugan");
		set.add("Saravana");
		set.add("Hari");
		set.add("Akash");
		set.add("Amisha");
		set.add("Ashwini");
		set.add("Hari");

		System.out.println(set);

		System.out.println(set.contains("Hari"));

		set.remove("Hari");

		Iterator<String> it = set.iterator();
		while (it.hasNext()) {
			String str = it.next();
			System.out.println(str.toUpperCase()+","+str.length());
		}
		set.clear();

		System.out.println(set.isEmpty());
		System.out.println(set.size());
	}
}
