package com.training.ui;

import java.util.Comparator;

import com.training.model.Comparators.AccountCustomerNameComparator;
import com.training.model1.Account;

public class Main7 {
	
	private static int NameSearch(Account[] arr, Account searchObject) {
		   Comparator comparator = new AccountCustomerNameComparator();
				for(int i=0;i<arr.length;i++) {
					int r=comparator.compare(arr[i], searchObject);
					if(r==0)
						return i;
					
				}
				return -1;
				
			}
			
			private static int balanceSearch(Account[] arr,Account searchObject) {
				//position if found ,
				//-1 if not found
				for(int i=0;i<arr.length;i++) {
					if(searchObject instanceof Comparable) {
						Comparable searchData=searchObject;
						int r=arr[i].compareTo(searchData);
						if(r==0)
							return i;
					}
					}
						return -1;}
			
	
public static void main(String[] args) {
	
	
	
	Account accounts[]= new Account[5];
	
	Account acc1= new Account("AHari", 20000.00);
	Account acc2= new Account("CHaran", 30000.00);
	Account acc3= new Account("SMuruga", 1000000.00);
	Account acc4= new Account("AKarthigaya", 200000.00);
	Account acc5= new Account("CSaravana", 3000000.00);
	
	
	accounts[0]=acc1;
	accounts[1]=acc2;
	accounts[2]=acc3;
	accounts[3]=acc4;
	accounts[4]=acc5;
	
	Account searchObject= new Account("AKarthigaya", 30000.00);
	
	System.out.println("============================ Name Search======================");
	int searchResult=NameSearch(accounts,searchObject);
	if(searchResult==-1)
		System.out.println("The search object was not found and the search result is "+searchResult);
	else 
		System.out.println("Search data "+searchObject+" is present at position "+searchResult);

System.out.println("============================ Price Search======================");
int balance=balanceSearch(accounts,searchObject);
if(balance==-1)
	System.out.println("The search object was not found and the search result is "+balance);
else 
	System.out.println("Search data "+searchObject+" is present at position "+balance);




}
}
