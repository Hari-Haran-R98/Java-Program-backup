package com.training.ui;

import java.util.Comparator;

import com.training.model.Comparators.EmployeeBasicSalaryAscendingComparator;
import com.training.model.Comparators.EmployeeBasicSalaryDescendingComparator;
import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.SalesEmployee;

public class Main8 {
	static Comparator comparator;
	private static int basicSalaryAscendingSearch(Employee[] arr, Employee searchObject) {
		    comparator = new EmployeeBasicSalaryAscendingComparator();
				for(int i=0;i<arr.length;i++) {
					int r=comparator.compare(arr[i], searchObject);
					if(r==0)
						return i;
					
				}
				return -1;
				
			}
	private static int basicSalaryDescendingSearch(Employee[] arr, Employee searchObject) {
	    comparator = new EmployeeBasicSalaryDescendingComparator();
			for(int i=0;i<arr.length;i++) {
				int r=comparator.compare(arr[i], searchObject);
				if(r==0)
					return i;
				
			}
			return -1;
			
		}
			
			private static int idSearch(Employee[] arr,Employee searchObject) {
				//position if found ,
				//-1 if not found
				for(int i=0;i<arr.length;i++) {
					if(searchObject instanceof Comparable) {
						Comparable searchData=searchObject;
						int r=arr[i].compareTo(searchData);
						if(r==0)
							return i;
					}
					}
						return -1;}
			


	public static void main(String[] args) {
		Manager manager = new Manager(103, "Hari", "Male", "Mumbai", 12000.00, 12);
		SalesEmployee salesEmp1 = new SalesEmployee(104, "Haran", "Male", "Banglore", 2000.00, 100000.00);
		SalesEmployee salesEmp2 = new SalesEmployee(101, "Haran", "Male", "Banglore", 1000.00, 200000.00);
		Employee employee1 = new Employee(102, "Ram", "Male", "Chennai", 10000.00);
		Employee[] employees = { manager, salesEmp1, salesEmp2, employee1 };

		Employee searchObject= new SalesEmployee(101, "Haran", "Male", "Banglore", 1000.00, 200000.00);
		System.out.println("============================ ID Search======================");
		int searchResult=idSearch(employees,searchObject);
		if(searchResult==-1)
			System.out.println("The search object was not found and the search result is "+searchResult);
		else 
			System.out.println("Search data "+searchObject+" is present at position "+searchResult);

	System.out.println("============================ basicASalary Search======================");
	searchObject= new SalesEmployee(101, "Haran", "Male", "Banglore", 12000.00, 200000.00);
	int basicASearch=basicSalaryAscendingSearch(employees,searchObject);
	if(basicASearch==-1)
		System.out.println("The search object was not found and the search result is "+basicASearch);
	else 
		System.out.println("Search data "+searchObject+" is present at position "+basicASearch);

	System.out.println("============================ basicDSalary Search======================");
	searchObject= new SalesEmployee(101, "Haran", "Male", "Banglore", 10000.00, 200000.00);
	int basicDSearch=basicSalaryDescendingSearch(employees,searchObject);
	if(basicDSearch==-1)
		System.out.println("The search object was not found and the search result is "+basicDSearch);
	else 
		System.out.println("Search data "+searchObject+" is present at position "+basicDSearch);



	}
}
