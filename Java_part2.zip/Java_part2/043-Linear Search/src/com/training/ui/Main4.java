package com.training.ui;

import com.training.model1.Square;

public class Main4 {
	private static int search(Square[] arr,Square searchObject) {
		//position if found ,
		//-1 if not found
		for(int i=0;i<arr.length;i++) {
			if(arr[i].equals(searchObject))
				return i;
		}
		return -1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square[] square = new Square[4];

		Square s1 = new Square(10);
		Square s2 = new Square(25);
		Square s3 = new Square(15);
		
		square[0]=s1;
		square[1] =s2;
		square[2] =s3;
		square[3] = new Square(20);

		Square searchObject= new Square(25);
		int searchResult=search(square,searchObject);
		if(searchResult==-1)
			System.out.println("The search object was not found and the search result is "+searchResult);
		else 
			System.out.println("Search data "+searchObject+" is present at position "+searchResult);

	}

}
