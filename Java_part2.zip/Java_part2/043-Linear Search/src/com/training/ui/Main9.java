package com.training.ui;

import java.util.Comparator;

import com.training.model.Comparators.BillitemPriceComparator;
import com.training.model.Comparators.PersonNameComparator;
import com.training.model1.BillItem;
import com.training.model1.Person;

public class Main9 {

	private static int NameSearch(Person[] arr, Person searchObject) {
		   Comparator comparator = new PersonNameComparator();
				for(int i=0;i<arr.length;i++) {
					int r=comparator.compare(arr[i], searchObject);
					if(r==0)
						return i;
					
				}
				return -1;
				
			}
			
			private static int ageSearch(Person[] arr,Person searchObject) {
				//position if found ,
				//-1 if not found
				for(int i=0;i<arr.length;i++) {
					if(searchObject instanceof Comparable) {
						Comparable searchData=searchObject;
						int r=arr[i].compareTo(searchData);
						if(r==0)
							return i;
					}
					}
						return -1;}
			
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("cHari", 25);
		Person p2 = new Person("bHaran", 26);
		Person p3 = new Person("aMurugan", 22);
		Person p4 = new Person("aaSaravana", 21);

		Person person[] = { p1, p2, p3, p4 };

		Person searchObject = new Person("aMurugan", 26);
		
		System.out.println("============================ Name Search======================");
		int searchResult=NameSearch(person,searchObject);
		if(searchResult==-1)
			System.out.println("The search object was not found and the search result is "+searchResult);
		else 
			System.out.println("Search data "+searchObject+" is present at position "+searchResult);

	System.out.println("============================ Age Search======================");
	int ageSearchvalue=ageSearch(person,searchObject);
	if(ageSearchvalue==-1)
		System.out.println("The search object was not found and the search result is "+ageSearchvalue);
	else 
		System.out.println("Search data "+searchObject+" is present at position "+ageSearchvalue);


	}

}
