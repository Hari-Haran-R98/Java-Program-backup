package com.training.ui;

public class Main5$1 {
	
public static void main(String[] args) {
	
}
}
