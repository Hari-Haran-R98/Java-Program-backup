package com.training.ui;

import com.training.model1.Circle;

public class Main3 {
	private static int search(Circle[] arr,Circle searchObject) {
		//position if found ,
		//-1 if not found
		for(int i=0;i<arr.length;i++) {
			if(arr[i].equals(searchObject))
				return i;
		}
		return -1;
	}
public static void main(String[] args) {
	Circle[] circles = new Circle[4];

	Circle c1 = new Circle(10);
	Circle c2 = new Circle(25);
	Circle c3 = new Circle(15);
	
	circles[0]=c1;
	circles[1] = c2;
	circles[2] = c3;
	circles[3] = new Circle(20);
	
	Circle searchObject= new Circle(25);
	int searchResult=search(circles,searchObject);
	if(searchResult==-1)
		System.out.println("The search Data was not found and the search result is "+searchResult);
	else 
		System.out.println("Search data "+searchObject+" is present at position "+searchResult);


}
}
