package com.training.ui;

import java.util.Comparator;

import com.training.model.Comparators.BillitemPriceComparator;
import com.training.model1.BillItem;

public class Main7Price {
	private static int priceSearch(BillItem[] arr, BillItem searchObject) {
		   Comparator comparator = new BillitemPriceComparator();
				for(int i=0;i<arr.length;i++) {
					int r=comparator.compare(arr[i], searchObject);
					if(r==0)
						return i;
					
				}
				return -1;
				
			}
			
			private static int search(BillItem[] arr,BillItem searchObject) {
				//position if found ,
				//-1 if not found
				for(int i=0;i<arr.length;i++) {
					if(searchObject instanceof Comparable) {
						Comparable searchData=searchObject;
						int r=arr[i].compareTo(searchData);
						if(r==0)
							return i;
					}
					}
						return -1;}
			
		public static void main(String[] args) {
			BillItem b1 = new BillItem("Redmi", 3, 14000.00);
			BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), new BillItem("Oppo", 3, 20000.00),
					new BillItem("IPhone", 4, 24000.00), b1 };

			BillItem searchObject= new BillItem("Samsung", 4, 23000.00);
			System.out.println("============================ Name Search======================");
			int searchResult=search(billItems,searchObject);
			if(searchResult==-1)
				System.out.println("The search object was not found and the search result is "+searchResult);
			else 
				System.out.println("Search data "+searchObject+" is present at position "+searchResult);

		System.out.println("============================ Price Search======================");
		int priceSearch=priceSearch(billItems,searchObject);
		if(priceSearch==-1)
			System.out.println("The search object was not found and the search result is "+priceSearch);
		else 
			System.out.println("Search data "+searchObject+" is present at position "+priceSearch);


		}

}
