package com.training.ui;

import java.util.Arrays;

import com.training.model1.Account;

public class Main8 {
public static void main(String[] args) {
	
	Account accounts[]= new Account[5];
	
	Account acc1= new Account("AHari", 20000.00);
	Account acc2= new Account("CHaran", 30000.00);
	Account acc3= new Account("SMuruga", 1000000.00);
	Account acc4= new Account("AKarthigaya", 20000000.00);
	Account acc5= new Account("CSaravana", 3000000.00);
	
	
	accounts[0]=acc1;
	accounts[1]=acc2;
	accounts[2]=acc3;
	accounts[3]=acc4;
	accounts[4]=acc5;
	
	for (int i = 0; i < accounts.length; i++) {
		for (int j = 0; j < accounts.length - i - 1; j++) {
			int r = accounts[j].compareTo(accounts[j + 1]);    //compareTo(billItems[j + 1]);
			if (r < 0) {
				Account temp;
				temp = accounts[j];
				accounts[j] = accounts[j + 1];
				accounts[j + 1] = temp;
			}
		}
	}
	System.out.println(Arrays.toString(accounts));

	
}
}
