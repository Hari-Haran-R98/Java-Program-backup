package com.training.ui;

import java.util.Arrays;

import com.training.model1.BillItem;

public class Main5 {
	public static void main(String[] args) {
		BillItem b1 = new BillItem("Redmi", 3, 14000.00);
		BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), new BillItem("Oppo", 4, 20000.00),
				new BillItem("IPhone", 4, 24000.00), b1 };
		for (int i = 0; i < billItems.length; i++) {
			for (int j = 0; j < billItems.length - i - 1; j++) {
				int r = billItems[j].compareTo(billItems[j + 1]);
				if (r > 0) {
					BillItem temp;
					temp = billItems[j];
					billItems[j] = billItems[j + 1];
					billItems[j + 1] = temp;
				}
			}
		}
		System.out.println(Arrays.toString(billItems));
	}
}