package com.training.ui;

import java.util.Arrays;

import com.training.model.Comparators.EmployeeBasicSalaryAscendingComparator;
import com.training.model.Comparators.PersonNameComparator;
import com.training.model1.Person;

public class Main13 {
	public static void main(String[] args) {

		Person p1 = new Person("cHari", 25);
		Person p2 = new Person("bHaran", 26);
		Person p3 = new Person("aMurugan", 22);
		Person p4 = new Person("aaSaravana", 21);

		Person person[] = { p1, p2, p3, p4 };
		for (int i = 0; i < person.length; i++) {
			for (int j = 0; j < person.length - i - 1; j++) {
				int r = person[j].compareTo(person[j + 1]);
				if (r > 0) {
					Person temp;
					temp = person[j];
					person[j] = person[j + 1];
					person[j + 1] = temp;
				}
			}
		}
		System.out.println(Arrays.toString(person));

	}
}
