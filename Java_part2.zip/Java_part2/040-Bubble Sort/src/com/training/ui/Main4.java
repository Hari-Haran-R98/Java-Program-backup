package com.training.ui;

import java.util.Arrays;

import com.training.model1.Square;

public class Main4 {
	public static void main(String[] args) {
		Square[] square = new Square[4];

		Square s1 = new Square(10);
		Square s2 = new Square(5);
		Square s3 = new Square(15);
		
		square[0]=s1;
		square[1] =s2;
		square[2] =s3;
		square[3] = new Square(20);
		
		for(int i=0;i<square.length;i++) {
			
			for(int j=0;j<square.length-i-1;j++ ) {
		int r=square[j].compareTo(square[j+1]);
				
				if(r>0) {
					
					Square temp;
				temp=square[j];
				square[j]=square[j+1];
				square[j+1]=temp;
			}}}
		System.out.println(Arrays.toString(square));

	}

}
