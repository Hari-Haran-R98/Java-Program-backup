package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Circle;

public class CircleComparators implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Circle c1= (Circle) o1;
		Circle c2= (Circle) o2;
		if(c1.getRadius()<c2.getRadius())
			return -1;
		
		
		if(c1.getRadius()>c2.getRadius())
			return 1;
		// TODO Auto-generated method stub
		
		
		
		return 0;
	}

}
