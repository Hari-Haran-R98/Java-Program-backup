package com.training.ui;

public class Main1 {

	public static void main(String[] args) {
		System.out.println("Program Beigns...");
		try {
		System.out.println(Integer.parseInt("abcd"));
		}
		catch(NumberFormatException e) {
			System.out.println(e);
		}
//		catch(RuntimeException e) {
//			System.out.println(e);  //----> also can be used 
//		}
//		catch(Exception e) {
//			System.out.println(e);
//		}
		finally {
			System.out.println("Bye bye");
		}
		System.out.println("Program ends...");
	}
}
