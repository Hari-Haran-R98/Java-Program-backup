package com.training.ui;

public class Main2 {
static void printLength(String str) {
	
	try {
	System.out.println(str.length());
	}
	catch (NullPointerException e) {
		// TODO: handle exception
		System.out.println(e);
	}
}
	public static void main(String[] args) {
		String s1="Welcome";
		String s2=null;
		String s3="UST";
		
		printLength(s1);
		printLength(s2);
		printLength(s3);
	}
}
