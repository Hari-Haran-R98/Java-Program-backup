package com.training.ui;

import java.util.Arrays;

public class Main4 {
	
	static void createArray(int size) {
		
		try {
			double[]arr= new double[size];
		System.out.println(Arrays.toString(arr));
		}
		catch (NegativeArraySizeException e) {
			// TODO: handle exception
		}
		catch (RuntimeException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Program beigins....");
		createArray(10);
		createArray(5);
		createArray(0);
		createArray(-40);
		createArray(25);
		System.out.println("Program ends...");

	}

}
