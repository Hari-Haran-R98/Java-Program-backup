package com.training.ui;

import com.training.model.InvalidCustomerName;
import com.training.model.InvalidLoanAmount;
import com.training.model.InvalidLoanId;
import com.training.model.InvalidTenure;
import com.training.model.Loan;

public class Main05 {
public static void main(String[] args) throws Exception{
//	Loan loan= new Loan();
//	try {
//	loan.setLoanId(99);
//	}
//	catch (InvalidLoanId e) {
//
//	// TODO: handle exception
//	e.printStackTrace();
//	}
//	try {
//		loan.setCustomerName(null);
//		}
//		catch (InvalidCustomerName e) {
//
//		// TODO: handle exception
//		e.printStackTrace();
//		}
//	
//	try {
//		loan.setLoanAmount(100.00);
//		}
//		catch (InvalidLoanAmount e) {
//
//		// TODO: handle exception
//		e.printStackTrace();
//		}
//
//	try {
//		loan.setTenure(99);
//		}
//		catch (InvalidTenure e) {
//
//		// TODO: handle exception
//		e.printStackTrace();
//		}

	try {
		Loan loan1= new Loan(98, null, 100.00, 10);
	}
		catch (Exception e) {

			System.out.println(e);
		// TODO: handle exception
		e.printStackTrace();
		}

	
	
	
	}
}
