package com.training.model;

public class Loan {

	private int loanId;
	private String customerName;
	private double loanAmount;
	private int tenure;
	
	
	
	public Loan() {
		super();
	}
	public Loan(int loanId, String customerName, double loanAmount, int tenure) throws Exception {
		super();
		setLoanId(loanId);
		setCustomerName(customerName);;
		setLoanAmount(loanAmount);;
		setTenure(tenure);
	}
	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) {
		if(loanId<=100) {
			InvalidLoanId invalidLoanId = new InvalidLoanId("Invalid Id "+loanId);
			throw invalidLoanId;
		}
		this.loanId = loanId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) throws InvalidCustomerName {
		if(customerName == null || customerName.length()<=0 ) {
			InvalidCustomerName invalidCustomerName = new InvalidCustomerName("InvalidCustomerName "+ customerName);
			throw invalidCustomerName;
		}
		this.customerName = customerName;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) throws InvalidLoanAmount {
		if(loanAmount<=10000.00) {
		InvalidLoanAmount invalidLoanAmount = new InvalidLoanAmount("InvalidLoanAmount "+loanAmount);
		throw invalidLoanAmount;}
		this.loanAmount = loanAmount;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) throws InvalidTenure {
		if(tenure <100 ) {
			InvalidTenure invalidTenure= new InvalidTenure("InvalidTenure "+ tenure);
			throw invalidTenure;
		}
		this.tenure = tenure;
	}
	
	
}
