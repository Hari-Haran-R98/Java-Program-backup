package com.training.model;

public class D implements A,X{

	@Override
	public void f1() {
		// TODO Auto-generated method stub
		System.out.println("F1 in B class");
	}

	public void f2() {
		System.out.println("f2 in D class");
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		System.out.println("M3 in D class abstract method");

	}
	public void m1() {
		System.out.println("M1 in D class default method");

	}
}
