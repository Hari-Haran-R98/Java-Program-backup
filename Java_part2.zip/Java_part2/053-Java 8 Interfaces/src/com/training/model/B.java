package com.training.model;

public interface B {

	void f1();
	default void f2() {
		System.out.println("F2 in B interface");
	}
	default void f4() {
		System.out.println("F4 in B interface");
	}
}
