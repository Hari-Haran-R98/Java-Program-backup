package com.training.model;

public interface X {

	default void m1() {
		System.out.println("m1 in X interface");
	}
	static void m2() {
		System.out.println("m2 static method from X");	
	}
	void m3();
}
