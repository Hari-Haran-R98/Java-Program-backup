package com.training.model;

public class E implements A,X{

	@Override
	public void f1() {
		// TODO Auto-generated method stub
		System.out.println("F1 in E class");
	}
	
	public void f2() {
		System.out.println("f2 in E class");
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		System.out.println("M3 in E class abstract method");
	}

}
