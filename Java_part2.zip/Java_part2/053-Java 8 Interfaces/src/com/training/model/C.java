package com.training.model;

public class C implements A,B,X{

	@Override
	public void f1() {
		// TODO Auto-generated method stub
		System.out.println("F1 implemented in C class");
		}
	@Override
public void f2() {
	System.out.println("F2 in C class");
}
@Override
public void f4() {
	System.out.println("f4 in C class");
}
@Override
public void m3() {
	// TODO Auto-generated method stub
	System.out.println("M3 in C class abstract method");
}
public void m1() {
	System.out.println("M1 in C class default method");

}

}
