package com.training.ui;

import com.training.model.A;
import com.training.model.D;
import com.training.model.E;
import com.training.model.X;

public class Main01 {

	public static void main(String[] args) {
		A obj;
		
		obj= new E();
		obj.f1();
		obj.f2();
		obj.f3();
		A.f5();
	
	
		X obj1;
	obj1= new D();
	obj1.m1();
	obj1.m3();
		X.m2();
	}
	
	
}
