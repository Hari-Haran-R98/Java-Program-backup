package com.training.ui;

public class Main2 {
	private static int search(double[] arr,double searchData) {
		int low =0,high = arr.length-1;
		while(low <= high) {
			int mid=low+(high-low)/2;
			if(arr[mid]==searchData)
				return mid;
			else if(arr[mid]<searchData)
				low=mid+1;
			else
				high=mid-1;
		}	
		return -1;
	}
	public static void main(String[] args) {
		double[] arr= {2.0,4.4,6.3,8.7,10.0,11.0,12.2};
		
		double searchData=8.7;
		
		int searchResult= search(arr, searchData);
		if(searchResult==-1) {
			System.out.println(searchData+" not found in the array and result is "+searchResult);
		}
		else 
			System.out.println(searchData+" found in the array and pos is "+searchResult);
	}

}
