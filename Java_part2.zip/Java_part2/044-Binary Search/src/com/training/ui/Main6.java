package com.training.ui;

import java.util.Arrays;
import java.util.Comparator;

import com.training.model.Comparators.BillitemQuantityComparator;
import com.training.model1.BillItem;

public class Main6 {
	private static int search(BillItem[] arr,BillItem billItem) {
		int low =0,high = arr.length-1;
		while(low <= high) {
			int mid=low+(high-low)/2;
			Comparator comparator = new BillitemQuantityComparator();
				int r=comparator.compare(arr[mid], billItem);
			if(r==0)
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}	
		return -1;
	}
	
	
public static void main(String[] args) {
	BillItem b1 = new BillItem("Redmi", 3, 14000.00);
	BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), new BillItem("Oppo", 4, 20000.00),
			new BillItem("IPhone", 4, 24000.00), b1 };
	
	BillItem searchObject= new BillItem("Oppo", 3, 20000.00);
	
	Arrays.sort(billItems, new BillitemQuantityComparator());
	
	System.out.println(Arrays.toString(billItems));

	int searchResult =search(billItems, searchObject);
	System.out.println("========================================");
	
	if(searchResult==-1) {
		System.out.println(searchObject+" not found in the array and result is "+searchResult);
	}
	else 
		System.out.println(searchObject+" found in the array and pos is "+searchResult);


}
}
