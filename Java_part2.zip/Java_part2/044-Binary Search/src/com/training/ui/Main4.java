package com.training.ui;

import com.training.model1.Square;

public class Main4 {
	private static int search(Square[] arr,Square searchData) {
		int low =0,high = arr.length-1;
		while(low <= high) {
			int mid=low+(high-low)/2;
					int r=arr[mid].compareTo(searchData);
			if(r==0)
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}	
		return -1;
	}
	
public static void main(String[] args) {
	Square[] squares = new Square[4];

	Square c1 = new Square(10);
	Square c2 = new Square(15);
	Square c3 = new Square(20);
	
	squares[0]=c1;
	squares[1] = c2;
	squares[2] = c3;
	squares[3] = new Square(25);

	Square searchObject = new Square(20);
	
	int searchResult= search(squares, searchObject);
	if(searchResult==-1) {
		System.out.println(searchObject+" not found in the array and result is "+searchResult);
	}
	else 
		System.out.println(searchObject+" found in the array and pos is "+searchResult);

	
	
}
}
