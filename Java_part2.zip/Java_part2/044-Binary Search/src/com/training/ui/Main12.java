package com.training.ui;

import java.util.Arrays;
import java.util.Comparator;

import com.training.model.Comparators.EmployeeBasicSalaryAscendingComparator;
import com.training.model.Comparators.EmployeeBasicSalaryDescendingComparator;
import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.SalesEmployee;

public class Main12 {
	private static int search(Employee[] arr, Employee employee) {
		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			Comparator comparator = new EmployeeBasicSalaryDescendingComparator();
			int r = comparator.compare(arr[mid], employee);
			if (r == 0)
				return mid;
			else if (r < 0)
				low = mid + 1;
			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		Manager manager = new Manager(103, "Hari", "Male", "Mumbai", 100000.00, 12);
		SalesEmployee salesEmp1 = new SalesEmployee(104, "Haran", "Male", "Banglore", 20000.00, 100000.00);
		SalesEmployee salesEmp2 = new SalesEmployee(101, "Haran", "Male", "Banglore", 130000.00, 200000.00);
		Employee employee1 = new Employee(102, "Ram", "Male", "Chennai", 11200.00);
		Employee[] employees = { manager, salesEmp1, salesEmp2, employee1 };

		Employee searchObject = new Employee(102, "Ram", "Male", "Chennai", 130000.00);

		Arrays.sort(employees,new EmployeeBasicSalaryDescendingComparator());

		System.out.println(Arrays.toString(employees));

		int searchResult = search(employees, searchObject);
		System.out.println("========================================");

		if (searchResult == -1) {
			System.out.println(searchObject + " not found in the array and result is " + searchResult);
		} else
			System.out.println(searchObject + " found in the array and pos is " + searchResult);



	}

}
