package com.training.ui;

import java.util.Arrays;

import com.training.model1.Account;
import com.training.model1.BillItem;

public class Main8 {
	
	private static int search(Account[] arr,Account account) {
		int low =0,high = arr.length-1;
		while(low <= high) {
			int mid=low+(high-low)/2;
					int r=arr[mid].compareTo(account);
			if(r==0)
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}	
		return -1;
	}
	
public static void main(String[] args) {
	Account accounts[]= new Account[5];
	
	Account acc1= new Account("AHari", 2010000.00);
	Account acc2= new Account("CHaran", 30000.00);
	Account acc3= new Account("SMuruga", 1000000.00);
	Account acc4= new Account("AKarthigaya", 200000.00);
	Account acc5= new Account("CSaravana", 3000000.00);
	
	
	accounts[0]=acc1;
	accounts[1]=acc2;
	accounts[2]=acc3;
	accounts[3]=acc4;
	accounts[4]=acc5;
	
	Account searchObject=new Account("SMuruga", 2010000.0);
	
	Arrays.sort(accounts);

	System.out.println(Arrays.toString(accounts));

	int searchResult =search(accounts, searchObject);
	System.out.println("========================================");
	
	if(searchResult==-1) {
		System.out.println(searchObject+" not found in the array and result is "+searchResult);
	}
	else 
		System.out.println(searchObject+" found in the array and pos is "+searchResult);


}
}
