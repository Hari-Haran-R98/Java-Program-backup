package com.training.ui;

import java.util.Arrays;

import com.training.model1.BillItem;

public class Main5 {
	
	private static int search(BillItem[] arr,BillItem billItem) {
		int low =0,high = arr.length-1;
		while(low <= high) {
			int mid=low+(high-low)/2;
					int r=arr[mid].compareTo(billItem);
			if(r==0)
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}	
		return -1;
	}
	
public static void main(String[] args) {
	BillItem b1 = new BillItem("Redmi", 3, 14000.00);
	BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), new BillItem("Oppo", 4, 20000.00),
			new BillItem("IPhone", 4, 24000.00), b1 };
	
	BillItem searchObject= new BillItem("Oppo", 3, 20000.00);
	
	Arrays.sort(billItems);
	System.out.println(Arrays.toString(billItems));
	
	int searchResult =search(billItems, searchObject);
	System.out.println("========================================");
	
	if(searchResult==-1) {
		System.out.println(searchObject+" not found in the array and result is "+searchResult);
	}
	else 
		System.out.println(searchObject+" found in the array and pos is "+searchResult);


}
}
