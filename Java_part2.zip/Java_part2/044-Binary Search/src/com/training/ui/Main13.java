package com.training.ui;

import java.util.Arrays;
import java.util.Comparator;

import com.training.model.Comparators.AccountCustomerNameComparator;
import com.training.model.Comparators.PersonNameComparator;
import com.training.model1.Account;
import com.training.model1.Person;

public class Main13 {

	private static int search(Person[] arr, Person person) {
		int low = 0, high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			int r=arr[mid].compareTo(person);
			if (r == 0)
				return mid;
			else if (r < 0)
				low = mid + 1;
			else
				high = mid - 1;
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p1 = new Person("cHari", 25);
		Person p2 = new Person("bHaran", 26);
		Person p3 = new Person("aMurugan", 22);
		Person p4 = new Person("aaSaravana", 21);

		Person persons[] = { p1, p2, p3, p4 };

		Person searchObject = new Person("CHaran", 35);

		Arrays.sort(persons);

		System.out.println(Arrays.toString(persons));

		int searchResult = search(persons, searchObject);
		System.out.println("========================================");

		if (searchResult == -1) {
			System.out.println(searchObject + " not found in the array and result is " + searchResult);
		} else
			System.out.println(searchObject + " found in the array and pos is " + searchResult);


	}

}
