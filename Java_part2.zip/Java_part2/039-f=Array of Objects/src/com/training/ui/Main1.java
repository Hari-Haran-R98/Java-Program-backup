package com.training.ui;

import com.training.model1.Circle;

public class Main1 {

	// Array of ref
	public static void main(String[] args) {

		int a = 100;
		int b = 200;
		int c = 300;

		int[] arr = new int[3];

		arr[0] = a;
		arr[1] = b;
		arr[2] = c;

		Circle[] circles = new Circle[4];

		Circle c1 = new Circle(10);
		Circle c2 = new Circle(5);
		Circle c3 = new Circle(15);

		circles[0] = c1;
		circles[1] = c2;
		circles[2] = c3;
		circles[3] = new Circle(20);

		for (Circle e : circles) {
			// System.out.println(e.getRadius()+","+e.getArea() );
			System.out.println(e);
		}
		circles= null;
		c1=c2=c3=null;

	}
}
