package com.training.ui;

import com.training.model1.Square;

public class Main2 {
	public static void main(String[] args) {

		Square[] squares = new Square[4];

		Square s1 = new Square(10);
		Square s2 = new Square(5);
		Square s3 = new Square(15);

		squares[0] = s1;
		squares[1] = s2;
		squares[2] = s3;
		squares[3] = new Square(25);

		for (Square e : squares) {
			System.out.println(e.getSize() + "," + e.getArea());
			System.out.println(e);
		}
		
		squares=null;
		s1=s2=s3=null;

	}

}
