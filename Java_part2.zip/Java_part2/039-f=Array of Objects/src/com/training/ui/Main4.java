package com.training.ui;

import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.SalesEmployee;

public class Main4 {

	public static void main(String[] args) {

		Manager manager = new Manager(101, "Hari", "Male", "Mumbai", 1000.00, 12);
		SalesEmployee salesEmp1 = new SalesEmployee(102, "Haran", "Male", "Banglore", 1000.00, 100000.00);
		SalesEmployee salesEmp2 = new SalesEmployee(103, "Haran", "Male", "Banglore", 1000.00, 200000.00);
		Employee employee1 = new Employee(104, "Ram", "Male", "Chennai", 1000.00);
		Employee[] employees = { manager, salesEmp1, salesEmp2, employee1 };

		for (Employee emp : employees) {
			System.out.println(emp);

			if (emp instanceof Manager) {
				Manager temp = (Manager) emp;
				System.out.println("Employee count :" + temp.getEmployeeCount());
			}

			if (emp instanceof SalesEmployee) {
				SalesEmployee temp = (SalesEmployee) emp;
				System.out.println("Sales Amount :" + temp.getSalesAmount());
			}
		}
		
		manager=null;
		salesEmp1=null;
		salesEmp2=null;
		employee1=null;
		employees=null;
	}
}
