package com.training.ui;

import com.training.model1.BillItem;
import com.training.model1.Circle;
import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.SalesEmployee;
import com.training.model1.Square;

public class Main5 {

	public static void main(String[] args) {
		Object[] arr = new Object[6];

		Circle c = new Circle(10);
		Square s = new Square(20);
		Employee employee1 = new Employee(104, "Ram", "Male", "Chennai", 1000.00);
		BillItem b1 = new BillItem("Redmi", 3, 14000.00);
		SalesEmployee salesEmp1 = new SalesEmployee(102, "Haran", "Male", "Banglore", 1000.00, 100000.00);
		Manager manager = new Manager(101, "Hari", "Male", "Mumbai", 1000.00, 12);

		arr[0] = c;
		arr[1] = s;
		arr[2] = employee1;
		arr[3] = b1;
		arr[4] = salesEmp1;
		arr[5] = manager;

		for (Object obj : arr) {
			System.out.println(obj);

			if (obj instanceof Circle) {
				Circle temp = (Circle) obj;
				System.out.println("Radius and Area of the Circle :" + temp.getRadius() + "," + temp.getArea());
			}

			if (obj instanceof Square) {
				Square temp = (Square) obj;
				System.out.println("Area and Size of Square  :" + temp.getArea() + "," + temp.getSize());
			}

			if (obj instanceof BillItem) {
				BillItem temp = (BillItem) obj;
				System.out.println("ProductName :" + temp.getIteamName() + ",Product price " + temp.getPrice()
						+ ",ProductQuantity : " + temp.getQuantity() + "Total Value " + temp.getItemValue());
			}
			if (obj instanceof Employee) {
				Employee temp = (Employee) obj;
				System.out.println("Employee Id :" + temp.getId());
				System.out.println("Employee Name :" + temp.getName());
				System.out.println("Employee Gender :" + temp.getGender());
				System.out.println("Employee CityName :" + temp.getCityName());
				System.out.println("Employee Basic :" + temp.getBasic());
				System.out.println("Employee NetSalary : " + temp.getNetSalary());
			}

			if (obj instanceof SalesEmployee) {
				SalesEmployee temp = (SalesEmployee) obj;
				System.out.println("Sales Amount :" + temp.getSalesAmount());
			}
			if (obj instanceof Manager) {
				Manager temp = (Manager) obj;
				System.out.println("Employee count :" + temp.getEmployeeCount());
			}

		}
		c=null;
		s=null;
		employee1=null;
		b1=null;
		salesEmp1=null;
		manager=null;

	}
}
