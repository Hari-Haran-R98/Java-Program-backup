package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model1.Person;

public class Main12 {
public static void main(String[] args) {
	try {
	Stack<Person> stack = new StackImpl<>(15);

	stack.push(new Person("Murugan", 21));
	stack.push(new Person("Saravan", 22));
	stack.push(new Person("Ganasha", 23));
	stack.push(new Person("Hari", 20));
	stack.push(new Person("Haran", 19));

	System.out.println(stack);
	Person bill = stack.pop();

	System.out.println(bill.getName() + ", " + bill.getAge() );
	System.out.println(stack);

	Person bill1 = stack.pop();

	System.out.println(bill1.getName() + ", " + bill1.getAge() );
    System.out.println(stack);
	}catch (Throwable e) {
		// TODO: handle exception
		System.out.println(e.getMessage());
	}
}
}
