package com.training.ui;

import com.training.ds.CircleStack;
import com.training.ds.IntegerStack;
import com.training.model1.Circle;

public class Main06 {

	public static void main(String[] args) {

			CircleStack stack= new CircleStack(10);
			stack.push(new Circle(19));
			stack.push(new Circle(30));
			stack.push(new Circle(40));
			stack.push(new Circle(26));
			stack.push(new Circle(45));
			stack.push(new Circle(27));			
			System.out.println(stack);
			
			Circle r=stack.pop();
			System.out.println("["+r+"]");
			System.out.println(stack);
			
			 r=stack.pop();
			System.out.println("["+r+"]");
			System.out.println(stack);
			
			 r=stack.pop();
			System.out.println("["+r+"]");
			System.out.println(stack);

	}
}
