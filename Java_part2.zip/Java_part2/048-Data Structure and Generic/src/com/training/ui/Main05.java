package com.training.ui;

import com.training.ds.IntegerStack;

public class Main05 {

	public static void main(String[] args) {
		IntegerStack stack= new IntegerStack(10);
		stack.push(1000);
		stack.push(200);
		stack.push(300);
		stack.push(3330);
		stack.push(1389);
		stack.push(7893);
		
		System.out.println(stack);
		
		Integer r=stack.pop();
		System.out.println("["+r+"]");
		System.out.println(stack);
		
		 r=stack.pop();
		System.out.println("["+r+"]");
		System.out.println(stack);
		
		 r=stack.pop();
		System.out.println("["+r+"]");
		System.out.println(stack);

		
	}
}
