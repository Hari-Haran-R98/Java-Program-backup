package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model1.BillItem;

public class Main10 {

	public static void main(String[] args) {
		try {
		Stack<BillItem> stack = new StackImpl<>(10);

		stack.push(new BillItem("Pen", 20, 200.00));
		stack.push(new BillItem("Pencle", 20, 300.00));
		stack.push(new BillItem("Paper", 20, 400.00));
		stack.push(new BillItem("Note", 20, 500.00));

		System.out.println(stack);
		BillItem bill = stack.pop();

		System.out.println(
				bill.getIteamName() + ", " + bill.getQuantity() + ", " + bill.getPrice() + ", " + bill.getItemValue());

		BillItem bill1 = stack.pop();

		System.out.println(bill1.getIteamName() + ", " + bill1.getQuantity() + ", " + bill1.getPrice() + ", "
				+ bill1.getItemValue());

		System.out.println(stack);}
		catch (Throwable e) {
			System.err.println(e.getMessage());
		}
	}
}
