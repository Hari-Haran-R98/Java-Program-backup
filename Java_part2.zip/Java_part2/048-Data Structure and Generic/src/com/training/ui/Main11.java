package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model1.Account;
import com.training.model1.BillItem;

public class Main11 {

	public static void main(String[] args) {
		
		try{
			Stack<Account> stack = new StackImpl<>(15);

		stack.push(new Account("Murugan", 110000.00));
		stack.push(new Account("Saravan", 120000.00));
		stack.push(new Account("Ganasha", 130000.00));
		stack.push(new Account("Hari", 10000.00));
		stack.push(new Account("Haran", 11000.00));

		System.out.println(stack);
		Account bill = stack.pop();

		System.out.println(bill.getCustomerName() + ", " + bill.getBalance() );
		System.out.println(stack);

		Account bill1 = stack.pop();

		System.out.println(bill1.getCustomerName() + ", " + bill1.getBalance() );
        System.out.println(stack);
		
        Account bill2 = stack.pop();

		System.out.println(bill2.getCustomerName() + ", " + bill2.getBalance() );

		System.out.println(stack);
	}
		catch (Throwable e) {
			// TODO: handle exception
			System.err.println(e.getMessage());
		}
	}
}
