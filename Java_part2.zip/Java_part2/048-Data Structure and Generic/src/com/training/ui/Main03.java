package com.training.ui;

import com.training.ds.DoubleStack;
import com.training.ds.LongStack;

public class Main03 {
	public static void main(String[] args) {
		DoubleStack stack1= new DoubleStack(11);
		
		stack1.push(20000);
		stack1.push(100000);
		stack1.push(455467);
		stack1.push(65694359);
		
		byte v1=5;
		short v2=15;
		long v3=90;
		int v4=9;
		char v5='A';
		float v7=678.0f;
		double v6=83458.909;
		
		stack1.push(v1);
		stack1.push(v2);
		stack1.push(v3);
		stack1.push(v4);
		stack1.push(v5);
		stack1.push(v6);
		stack1.push(v7);
		
		//stack1.push(v4);
		System.out.println(stack1);
		
		double r=stack1.pop();
		System.out.println("["+r+"]");
		System.out.println(stack1);
		
		 r=stack1.pop();
		System.out.println("["+r+"]");
		System.out.println(stack1);
		
		 r=stack1.pop();
		System.out.println("["+r+"]");
		System.out.println(stack1);
		
		
		r=stack1.pop();
		System.out.println("["+r+"]");
		System.out.println(stack1);
		
		
		r=stack1.pop();
		System.out.println("["+r+"]");
		System.out.println(stack1);
		
		
		r=stack1.pop();
		System.out.println("["+r+"]");
		System.out.println(stack1);

}}
