package com.training.ui;

import com.training.ds.ObjectStack;
import com.training.model1.Account;
import com.training.model1.BillItem;
import com.training.model1.Circle;
import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.Person;
import com.training.model1.SalesEmployee;
import com.training.model1.Square;

public class Main08 {

	public static void main(String[] args) {
		Integer obj1= Integer.valueOf(24);
		String obj2= new String("Welcome");
		Circle obj3=new Circle(14);
		Square obj4= new Square(15);
		BillItem obj5= new BillItem("Iphone", 10, 150000.00);
		Employee emp= new Employee(103, "Muruga", "Male", "Palani", 20000.00);
		Manager manager= new Manager(101,"Hari", "Male", "Ooty", 2000.00, 10);
		SalesEmployee salesemp= new SalesEmployee(104, "Saravana", "Male", "Marudhamalai", 300000.00, 20);
		Account acc= new Account("Haran", 240000.00);
		Person person= new Person("Hari", 25);
		
		ObjectStack stack= new ObjectStack(20);
		stack.push(obj1);
		stack.push(obj2);
		stack.push(obj3);
		stack.push(obj4);
		stack.push(obj5);
		stack.push(emp);
		stack.push(manager);
		stack.push(salesemp);
		stack.push(acc);
		stack.push(person);
		
		
		System.out.println(stack);
		
		Object r= stack.pop();
		System.out.println(r);
		if(r instanceof Person) {
		Person p=(Person) r;
		System.out.println(p.getAge());
		System.out.println("====================");
		}
		if(r instanceof Integer) {
			Integer temp=(Integer) r;
			System.out.println(temp.intValue());
			System.out.println("====================");
			}
		if(r instanceof String) {
			String temp=(String) r;
			System.out.println(temp.toUpperCase());
			System.out.println("====================");
			}

		if(r instanceof Circle) {
			Circle temp=(Circle) r;
			System.out.println(temp.getRadius());
			System.out.println("====================");
			}
		
		if(r instanceof Square) {
			Square temp=(Square) r;
			System.out.println(temp.getSize());
			System.out.println("====================");
			}
		
		if(r instanceof BillItem) {
			BillItem temp=(BillItem) r;
			System.out.println(temp.getIteamName());
			System.out.println("====================");
			}
		
		if(r instanceof Employee) {
			Employee temp=(Employee) r;
			System.out.println(temp.getBasic());
			System.out.println("====================");
			}
		
		if(r instanceof Manager) {
			Manager temp=(Manager) r;
			System.out.println(temp.getEmployeeCount());
			System.out.println("====================");
			}
		
		if(r instanceof SalesEmployee) {
			SalesEmployee temp=(SalesEmployee) r;
			System.out.println(temp.getSalesAmount());
			System.out.println("====================");
			}
		
		if(r instanceof Account) {
			Account temp=(Account) r;
			System.out.println(temp.getBalance());
			System.out.println("====================");
			}
		
		if(r instanceof Person) {
			Person temp=(Person) r;
			System.out.println(temp.getName());
			System.out.println("====================");
		}
	}
}
