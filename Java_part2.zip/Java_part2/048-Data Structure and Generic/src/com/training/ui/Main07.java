package com.training.ui;

import com.training.ds.SquareStack;
import com.training.model1.Square;

public class Main07 {

	public static void main(String[] args) {
        SquareStack stack= new SquareStack(10);
        
		stack.push(new Square(19));
		stack.push(new Square(30));
		stack.push(new Square(40));
		stack.push(new Square(26));
		stack.push(new Square(45));
		stack.push(new Square(27));			
		System.out.println(stack);
		
		Square r=stack.pop();
		System.out.println("["+r+"]");
		System.out.println(stack);
		
		 r=stack.pop();
		System.out.println("["+r+"]");
		System.out.println(stack);
		
		 r=stack.pop();
		System.out.println("["+r+"]");
		System.out.println(stack);

}

	}

