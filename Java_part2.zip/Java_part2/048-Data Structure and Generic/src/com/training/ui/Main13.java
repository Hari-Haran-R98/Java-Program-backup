package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.Person;
import com.training.model1.SalesEmployee;

public class Main13 {
public static void main(String[] args) {
	try {
	Stack<Employee> stack = new StackImpl<>(10);

stack.push(new Employee(103, "Hari", "Male", "Ooty", 23000.00));
	stack.push(new Manager(101, "Muruga", "Male", "Palani", 1000000.00, 10000));
	stack.push(new SalesEmployee(102, "Haran", "Male", "Coimbatore", 20000.00, 2000.00));
	System.out.println(stack);
	
	Employee bill = (Employee) stack.pop();

	System.out.println(bill.getId()+", "+bill.getName()+ ", " + bill.getGender() + ", " + bill.getCityName()+ ", " + bill.getBasic() + ", " + bill.getNetSalary());
	System.out.println(stack);

	Employee bill1 = stack.pop();

	System.out.println(bill1.getId()+", "+bill1.getName()+ ", " + bill1.getGender() + ", " + bill1.getCityName()+ ", " + bill1.getBasic() + ", " + bill1.getNetSalary());
    System.out.println(stack);
	}catch (Throwable e) {
		// TODO: handle exception
		System.err.println(e.getMessage());
	}
}
}
