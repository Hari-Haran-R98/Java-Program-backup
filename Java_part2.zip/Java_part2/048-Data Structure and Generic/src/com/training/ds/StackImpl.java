package com.training.ds;

import com.training.exceptions.InvalidStackSizeException;
import com.training.exceptions.StackIsEmptyExceptions;
import com.training.exceptions.StackIsFullException;

public class StackImpl<T> implements Stack<T>{
	Object[]arr;
	int index=0;
	
	public  StackImpl(int size) throws Exception{
		
		if(size<0) {
		Exception e= new InvalidStackSizeException("Stack Size Cannot be Negative Value");
	throw e;
		}
		this.arr=new Object[size];}
public void push(T data) throws Exception{
	if(index==arr.length) {
		Exception e= new StackIsFullException("Stack Already full");
		throw e;
	}
	this.arr[index]=data;
	index++;
	
}

public T pop() throws Exception {
	if(index==0) {
		Exception e= new StackIsEmptyExceptions("Index is already empty");
	throw e;
		}
	index--;
	Object r=this.arr[index];
	return (T)r;
}
public String toString() {
	String str="[";
	for(int i=0;i<index; i++) {
		if(i==index-1)
		str=str+this.arr[i];
		else
			str=str+this.arr[i]+",";
	}
	str=str+"]";
	return str;
}



	
	
}
