package com.training.ui;

import com.training.model.InvalidGradeException;
import com.training.model.InvalidMarkException;
import com.training.model.InvalidNameException;
import com.training.model.Student;

public class Main10 {
	public static void main(String[] args) throws Exception {
		
		Student student = new Student();
	
		try {
			student.setMark(150);
		} 
		catch (InvalidMarkException e) {
		//System.out.println(e);
			e.printStackTrace();
		}
		
		System.out.println("Exception is handeled "+student.getMark());
	try {
		student.setName(null);
	}
	catch (InvalidNameException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	System.out.println(student.getName());
	
	try {
	student.setGrade('E');
	}
	catch (InvalidGradeException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	System.out.println("Program end....");
	}

}
