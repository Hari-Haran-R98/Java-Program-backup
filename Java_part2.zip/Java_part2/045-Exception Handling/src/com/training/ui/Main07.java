package com.training.ui;

public class Main07 {

	public static void main(String[] args) {
		try {
		System.out.println(100/1);
		int[] arr= {1,2,3,4};
		System.out.println(arr[2]);
		System.out.println(Integer.parseInt("125"));

		String str="125abcd";
		System.out.println(str.length());
	}
	catch(ArithmeticException e) {
		System.out.println(e);
		System.out.println("Continuing....");
	}
	catch (ArrayIndexOutOfBoundsException e) {
		// TODO: handle exception
		System.out.println(e);
		System.out.println("Continuing....");
	}	
		catch (NumberFormatException e) {
			// TODO: handle exception
			System.out.println(e);
			System.out.println("Continuing....");
		}	
		catch (NullPointerException e) {
			// TODO: handle exception
			System.out.println(e);
			System.out.println("Continuing....");
		}	
		catch (Throwable e) {
			// TODO: handle exception
			System.out.println("Some error occured");
			System.out.println("Continuing....");
		}
		finally {
			System.out.println("Good bye");
		}
		System.out.println("Program end.....");
	}
}
