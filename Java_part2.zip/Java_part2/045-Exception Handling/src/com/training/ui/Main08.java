package com.training.ui;

public class Main08 {

	public static void main(String[] args) {
		try {
			System.out.println(100/0);
			int[] arr= {1,2,3,4};
			System.out.println(arr[200]);
			System.out.println(Integer.parseInt("125abcd"));

			String str="125abcd";
			System.out.println(str.length());
		}
		catch(NumberFormatException | NullPointerException | ArrayIndexOutOfBoundsException | ArithmeticException e) {
		if(e instanceof NumberFormatException) {
			
		System.out.println("NumberFormat invalid "+e);
		}
		if(e instanceof NullPointerException) {
			
			System.out.println("Null value encountered "+e);
			}
		if(e instanceof ArrayIndexOutOfBoundsException) {
			
			System.out.println("Array Index Out Of Bounds "+e);
			}
		if(e instanceof ArithmeticException) {
			
			System.out.println("ArithmeticException "+e);
			}
	}
		
				
	}
}
