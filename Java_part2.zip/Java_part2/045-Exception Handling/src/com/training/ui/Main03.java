package com.training.ui;

public class Main03 {

	public static void main(String[] args) {
		System.out.println("Program Begins....");
		try {
		String str="125abc";
		
		int x=Integer.parseInt(str);
		
		System.out.println(++x);}
		catch(NumberFormatException e) {
			System.out.println(e);
		}

		System.out.println("Program Ends....");

	}
}
