package com.training.ui;

import com.training.model.Employee;

public class Main09 {

	public static void main(String[] args) {
		//System.out.println(100/0);
		
		Employee emp = new Employee();
		//try {
		try {
			emp.setBasicSalary(-1000.00);
		} catch (Exception e) {
			System.out.println(e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		}
//		catch(RuntimeException e) {
//			System.out.println(e.getMessage());
//		}
		System.out.println(emp.computeAllowance());
		
	}
}
