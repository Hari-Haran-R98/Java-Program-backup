package com.training.model;

public class Employee {
	private double basicSalary;

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary)throws Exception {
		if(basicSalary<0) {
			Exception e= new Exception("Incorrect basicSalary "+basicSalary);
		//try {
			throw e;
////		catch (Exception e1) {
////			// TODO: handle exception
////			e1.printStackTrace();
		}
		this.basicSalary = basicSalary;
	}
	
public double computeAllowance() {
	return this.basicSalary*0.35;
}
}
