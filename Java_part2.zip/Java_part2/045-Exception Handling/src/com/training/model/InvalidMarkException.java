package com.training.model;

public class InvalidMarkException extends RuntimeException {

	public InvalidMarkException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidMarkException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidMarkException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidMarkException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidMarkException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
