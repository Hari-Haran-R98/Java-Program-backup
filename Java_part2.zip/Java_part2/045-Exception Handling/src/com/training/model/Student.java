package com.training.model;

public class Student {
private int mark;
private String name;
private char grade;

{
	
}

public int getMark() {
	return mark;
}

public void setMark(int mark) throws InvalidMarkException{
	if(mark < 0 || mark >100) {
		InvalidMarkException e= new InvalidMarkException("Incorrect mark "+mark);
		throw e;
		}
	this.mark = mark;
}

public String getName() {
	return name;
}

public void setName(String name)throws InvalidNameException {
	if(name==null || name.length()==0) {
		InvalidNameException e1= new InvalidNameException("name is invalid "+name);
		throw e1;
	}
	this.name = name;
}

public char getGrade() {
	return grade;
}

public void setGrade(char grade) throws InvalidGradeException {
	if(grade != 'A' || grade != 'B') {
		InvalidGradeException e2= new InvalidGradeException("invalid grade "+grade);
		throw e2;
	}

	this.grade = grade;
}

}
