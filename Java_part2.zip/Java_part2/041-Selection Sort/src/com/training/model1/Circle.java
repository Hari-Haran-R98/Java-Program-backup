package com.training.model1;

public class Circle implements Comparable  {

	private int radius;

	public Circle(int radius) {
		super();
		this.radius = radius;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public double getArea() {
		return 3.14*this.radius*this.radius;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + radius;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Circle))
			return false;
		Circle other = (Circle) obj;
		if (radius != other.radius)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "\nCircle [radius=" + radius + "]";
	}

	@Override
	public int compareTo(Object obj) {
		Circle other= (Circle) obj;
		if(this.radius < other.radius)
			return -1;
		
		if(this.radius>other.radius)
			return 1;
		
		return 0;
	}
	
	
	
}
