package com.training.ui;

import java.util.Arrays;

import com.training.model1.BillItem;

public class Main5 {
	public static void main(String[] args) {
		BillItem b1 = new BillItem("Redmi", 3, 14000.00);
		BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), new BillItem("Oppo", 4, 20000.00),
				new BillItem("IPhone", 4, 24000.00), b1 };
		int imin;
		for (int i = 0; i < billItems.length; i++) {
			imin=i;
			for (int j = i+1; j < billItems.length ; j++) {
				int r = billItems[j].compareTo(billItems[imin]);
				if (r < 0) 
					imin=j;}
					BillItem temp;
					temp = billItems[i];
					billItems[i] = billItems[imin];
					billItems[imin] = temp;
			}
		System.out.println(Arrays.toString(billItems));

	}
}
