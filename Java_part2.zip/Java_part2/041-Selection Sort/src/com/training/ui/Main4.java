package com.training.ui;

import java.util.Arrays;

import com.training.model1.Square;

public class Main4 {
public static void main(String[] args) {
	Square[] square = new Square[4];

	Square s1 = new Square(10);
	Square s2 = new Square(25);
	Square s3 = new Square(15);
	
	square[0]=s1;
	square[1] =s2;
	square[2] =s3;
	square[3] = new Square(20);
	int imin;
	for(int i=0;i<square.length;i++) {
		imin=i;
		for(int j=i+1;j<square.length-i-1;j++ ) {
	int r=square[j].compareTo(square[imin]);
			
			if(r<0) 
				imin=j;
		}
				Square temp;
			temp=square[i];
			square[i]=square[imin];
			square[imin]=temp;
		}
	System.out.println(Arrays.toString(square));
}
}
