package com.training.ui;

import java.util.Arrays;

import com.training.model.Comparators.PersonNameComparator;
import com.training.model1.Person;

public class Main14 {
public static void main(String[] args) {
	Person p1 = new Person("CHari", 25);
	Person p2 = new Person("BHaran", 26);
	Person p3 = new Person("AMurugan", 22);
	Person p4 = new Person("ASaravana", 21);

	Person person[] = { p1, p2, p3, p4 };
	int imin;
	for (int i = 0; i < person.length; i++) {
		imin=i;
		for (int j = i+1; j < person.length ; j++) {
			PersonNameComparator comparator= new PersonNameComparator();
			int r = comparator.compare(person[j], person[imin]);
			if (r < 0) 
				imin=j;
		}
				Person temp;
				temp = person[i];
				person[i] = person[imin];
				person[imin] = temp;
			}
	System.out.println(Arrays.toString(person));
}
}