package com.training.ui;

import java.util.Arrays;

import com.training.model1.Employee;
import com.training.model1.Manager;
import com.training.model1.SalesEmployee;

public class Main10 {
public static void main(String[] args) {
	
	Manager manager = new Manager(103, "Hari", "Male", "Mumbai", 1000.00, 12);
	SalesEmployee salesEmp1 = new SalesEmployee(104, "Haran", "Male", "Banglore", 1000.00, 100000.00);
	SalesEmployee salesEmp2 = new SalesEmployee(101, "Haran", "Male", "Banglore", 1000.00, 200000.00);
	Employee employee1 = new Employee(102, "Ram", "Male", "Chennai", 1000.00);
	Employee[] employees = { manager, salesEmp1, salesEmp2, employee1 };

	int imin;
	for (int i = 0; i < employees.length; i++) {
		imin=i;
		for (int j = i+1; j < employees.length ; j++) {
			int r = employees[j].compareTo(employees[imin]);    //compareTo(billItems[j + 1]);
			if (r < 0) 
				imin=j;
			}
				Employee temp;
				temp = employees[i];
				employees[i] = employees[imin];
				employees[imin] = temp;
			}
	System.out.println(Arrays.toString(employees));

}
}
