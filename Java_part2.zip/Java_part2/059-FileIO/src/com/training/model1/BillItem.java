package com.training.model1;

import java.io.Serializable;

public class BillItem implements Comparable<BillItem>, Serializable{

	private String iteamName;
	private int quantity ;
	private double price;
	public String getIteamName() {
		return iteamName;
	}
	public void setIteamName(String iteamName) {
		this.iteamName = iteamName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getItemValue() {
		return this.price*this.quantity;
	}
	
	
	public BillItem(String iteamName, int quantity, double price) {
		super();
		this.iteamName = iteamName;
		this.quantity = quantity;
		this.price = price;
	}
	@Override
	public int compareTo(BillItem o) {
		// TODO Auto-generated method 

		
		
		int r=this.iteamName.compareTo(o.iteamName);
		
		return r;
	}
	@Override
	public String toString() {
		return "\nBillItem [iteamName=" + iteamName + ", quantity=" + quantity + ", price=" + price + ", getItemValue()="
				+ getItemValue() + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((iteamName == null) ? 0 : iteamName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof BillItem))
			return false;
		BillItem other = (BillItem) obj;
		if (iteamName == null) {
			if (other.iteamName != null)
				return false;
		} else if (!iteamName.equals(other.iteamName))
			return false;
		return true;
	}
	public BillItem() {
		super();

	}
	
	
	
	
}
