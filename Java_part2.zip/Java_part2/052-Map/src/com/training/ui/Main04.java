package com.training.ui;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.training.model1.Circle;

public class Main04 {

	public static void main(String[] args) {
		Map<Circle, String> map;
		map = new HashMap<>();

		Circle c1 = new Circle(100);
		Circle c2 = new Circle(50);
		Circle c3 = new Circle(5);

		map.put(c1, "Larg");
		map.put(c2, "Medium");
		map.put(c3, "Small");

		for (Entry<Circle, String> entry : map.entrySet()) {
			System.out.println(entry.getKey() + "-" + entry.getValue());
		}

	}
}
