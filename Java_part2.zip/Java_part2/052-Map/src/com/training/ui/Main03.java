package com.training.ui;

import java.util.Map;
import java.util.TreeMap;

import com.training.model1.Employee;

public class Main03 {

	public static void main(String[] args) {
		Map<Integer, Employee> empMap = new TreeMap<>();

		Employee e1 = new Employee(101, "Muruga", "Male", "Palani", 1000000.00);
		Employee e2 = new Employee(102, "Saravana", "Male", "Chennai", 2000000.00);
		Employee e3 = new Employee(103, "Bala", "Male", "Coimbator", 3000000.00);
		Employee e4 = new Employee(104, "Kumara", "Male", "Salem", 4000000.00);
		Employee e5 = new Employee(105, "Hari", "Male", "Ooty", 10000.00);
		empMap.put(2, e4);
		empMap.put(Integer.valueOf(1), e5);

		empMap.put(Integer.valueOf(3), e3);
		empMap.put(Integer.valueOf(4), e2);
		empMap.put(Integer.valueOf(5), e1);

		System.out.println(empMap);

		for (Map.Entry<Integer, Employee> entry : empMap.entrySet()) {
			System.out.println(entry.getKey());
			Employee emp = entry.getValue();
			System.out.println(emp.getName() + "-" + emp.getNetSalary());
		}
	}
}
