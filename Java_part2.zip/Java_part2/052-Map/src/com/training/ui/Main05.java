package com.training.ui;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.training.model1.Employee;

public class Main05 {

	public static void main(String[] args) {
		Map<Integer, Employee> empMap = new TreeMap<>();

		Employee e1 = new Employee(101, "Muruga", "Male", "Banglore", 1000000.00);
		Employee e2 = new Employee(102, "Saravana", "Male", "Chennai", 2000000.00);
		Employee e3 = new Employee(103, "Bala", "Male", "Cochin", 3000000.00);
		Employee e4 = new Employee(104, "Kumara", "Male", "Banglore", 4000000.00);
		Employee e5 = new Employee(105, "Hari", "Male", "Chennai", 10000.00);
		Employee e6 = new Employee(106, "Haran", "Male", "Cochin", 1000000.00);
		Employee e7 = new Employee(107, "Ashwini", "Femail", "Chennai", 2000000.00);
		Employee e8 = new Employee(108, "Gopi", "Male", "Cochin", 3000000.00);
		Employee e9 = new Employee(109, "Ram", "Male", "Cochin", 4000000.00);
		Employee e10 = new Employee(110, "Krishna", "Male", "Banglore", 10000.00);

		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);

		Map<String, Integer> citywiseCountMap = new HashMap<>();

		for (Employee employee : allEmployees) {
			String cityName = employee.getCityName();
			if (citywiseCountMap.containsKey(cityName)) {
				citywiseCountMap.put(cityName, citywiseCountMap.get(cityName) + 1);
			} else {
				citywiseCountMap.put(cityName, 1);
			}
		}

		for (Map.Entry<String, Integer> entry : citywiseCountMap.entrySet()) {
			System.out.println(entry.getKey() + "--" + entry.getValue());
		}

	}
}
