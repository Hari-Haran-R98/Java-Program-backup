package com.training.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.training.model1.Employee;

public class Main08 {

	public static void main(String[] args) {
		Map<Integer, Employee> empMap = new TreeMap<>();
		Employee e1 = new Employee(101, "Muruga", "Male", "Banglore", 100000.00);
		Employee e2 = new Employee(102, "Saravana", "Male", "Chennai", 200000.00);
		Employee e3 = new Employee(103, "Bala", "Male", "Cochin", 300000.00);
		Employee e4 = new Employee(104, "Kumari", "female", "Banglore", 40000.00);
		Employee e5 = new Employee(105, "Harini", "female", "Chennai", 10000.00);
		Employee e6 = new Employee(106, "Haran", "Male", "Cochin", 10000.00);
		Employee e7 = new Employee(107, "Ashwini", "female", "Chennai", 20000.00);
		Employee e8 = new Employee(108, "Priya", "female", "Cochin", 300000.00);
		Employee e9 = new Employee(109, "Ram", "Male", "Cochin", 100000.00);
		Employee e10 = new Employee(110, "Krishna", "Male", "Banglore", 10000.00);
		List<Employee> allEmployees = new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);

		Map<String, List<Employee>> map = new HashMap<>();

		for (Employee e : allEmployees) {
			String cityName = e.getCityName();
			if (map.containsKey(cityName)) {
				List<Employee> empList = map.get(cityName);
				empList.add(e);

			} else {
				map.put(cityName, new ArrayList<>());
				List<Employee> empList = map.get(cityName);
				empList.add(e);

			}
		}
		for (Map.Entry<String, List<Employee>> entry : map.entrySet()) {
			System.out.println("City Name : " + entry.getKey());
			System.out.println("---------------------------------------------------------------------------");
			System.out.println("Slno     ID      NAME    GENDER        BASIC SALARY        NET SALARY");
			System.out.println("---------------------------------------------------------------------------");
			List<Employee> empList = entry.getValue();

			double totalBasicSalary = 0;
			double totalNetSalary = 0;

			int slno = 1;
			for (Employee e : empList) {
				totalBasicSalary += e.getBasic();
				totalNetSalary += e.getNetSalary();
				System.out.printf("%3d \t %-5d\t %-4s \t %6s \t%10.2f \t% 10.2f \n", slno++, e.getId(), e.getName(),
						e.getGender(), e.getBasic(), e.getNetSalary());
			}
			System.out.println();
			System.out.println("------------------------------------------------------------------------------");
			System.out.println("Total Employee Count : " + empList.size());
			System.out.println("Total Basic Salary : " + totalBasicSalary);
			System.out.println("Total Net Salary : " + totalNetSalary);
			System.out.println("  ");
			System.out.println("---------------------------------------------------------------------------------");

		}

	}
}
