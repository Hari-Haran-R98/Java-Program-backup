package com.training.model.pack2;

public interface Hello {

	void doIt();
}
