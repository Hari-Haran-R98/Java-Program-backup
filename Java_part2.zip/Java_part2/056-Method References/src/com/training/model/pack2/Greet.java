package com.training.model.pack2;

public class Greet {

	public void gret() {
		System.out.println("Hi.. how are u");
	}
}
