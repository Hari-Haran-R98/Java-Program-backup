package com.training.model.pack3;

public interface Factory<T> {

	T creat(int data);
}
