package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

public class Main04 {
public static void main(String[] args) {
	List<String> names = new LinkedList<>();
	names.add("Prabhu");
	names.add("Hariharan");
	names.add("hari");
	names.add("Haran");
	names.add("Ashwini");
	
	
	Function<String, Integer> fn;
	fn=String::length;
	Integer r=fn.apply(names.get(1));
	
	System.out.println(r);
	
	Function<String, String> fn1;
	fn1=String::toUpperCase;
	String r1=fn1.apply(names.get(1));
	
	System.out.println(r1);
}
}
