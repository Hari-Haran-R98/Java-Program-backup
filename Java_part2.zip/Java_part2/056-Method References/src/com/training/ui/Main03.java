package com.training.ui;

import com.training.model.pack3.Circle;
import com.training.model.pack3.Employee;
import com.training.model.pack3.Factory;

public class Main03 {

	public static void main(String[] args) {
		
		Factory<Circle> factory;
		//factory= r->new Circle(r);
		factory=Circle::new; // method referance to a constractor method
		Circle c= factory.creat(10);
		System.out.println(c);
		
		
		Factory<Employee> factory1;
		//factory1=i-> new Employee(i);
		
		factory1=Employee::new;
		Employee e=factory1.creat(1601);
		System.out.println(e);
	}
}
