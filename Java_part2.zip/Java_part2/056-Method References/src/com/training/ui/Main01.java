package com.training.ui;

import com.training.model.pack1.Addition;
import com.training.model.pack1.Multiplication;
import com.training.model.pack1.Subtraction;
import com.training.model.pack1.Task;

public class Main01 {
public static void main(String[] args) {

	Task task;
	
	//task=(x,y)->x+y;
	
	task=Addition::add;
	System.out.println(task.execute(10, 20));
	
	task=Subtraction::subtract;
	System.out.println(task.execute(50, 20));
	
	task=Multiplication:: multiply;
	System.out.println(task.execute(10, 30));
	
}
	
}
