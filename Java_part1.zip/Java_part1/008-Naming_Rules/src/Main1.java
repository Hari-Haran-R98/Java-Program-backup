
public class Main1 {
public static void main(String[] args) {
	int a;// name min 1 char max no limit
	int b10;// name can contain digits
	int 2b;// name no starting with digits
	int ?.;// no character allowed except $ and _
	int B10; // names are case sensitive 
	int a b;// no space allowed 
	int \u006110; // can contain Unicode character 
	
	a10=100;
	System.out.println(a10);
	
}
	// naming have to be followed in class and methods as well
void test$123() {
	
}
}
