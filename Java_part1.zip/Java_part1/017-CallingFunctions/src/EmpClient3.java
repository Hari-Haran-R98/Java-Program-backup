
public class EmpClient3 {
public static void test3(Employee e) {
	System.out.println();
	e.id=1002;
	e.name="Haran";
	e.age=55;
	}
public static void main(String[] args) {
	Employee emp= new Employee();
	emp.id=1001;
	emp.name="Hari";
	emp.age=50;
	
	System.out.println("In main before function called ");
	emp.display();
	
	EmpClient3.test3(emp);
	
	System.out.println("In main after function called ");
	emp.display();
	
}
}
