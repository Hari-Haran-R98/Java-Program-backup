
public class Employee {

	int id;
	String name;
	int age;
	
	
	void display() {
		System.out.print("Id = "+id);
		System.out.print("=========================");
		System.out.print("Name = "+name);
		System.out.print("=========================");
		System.out.print("Age = "+age);
		
	}
}
