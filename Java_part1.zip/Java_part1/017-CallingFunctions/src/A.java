public class A {
 
	int x; // instance variable 
	static int y;// global or static variable
	
	void printX() {// instance method
		System.out.println(this.x);
		this.printWelcome();
		System.out.println(y);
		printGoodBye();
		A obj=new A();
	}
	void printWelcome() {// instance method
		System.out.println("Welcome");
	}
	
	static void prinY() {// static variable 
		//System.out.println(x); // cannot call instance variable
		//printWelcome();// static method cannot call instance method
		A obj1=new A();
		System.out.println();
	}
	static void printGoodBye() {
		System.out.println("Good Bye");
	}
	A(){
		this(10);
		System.out.println("A obj created");
		System.out.println(this.x);
		printWelcome();
		System.out.println(y);
		printGoodBye();
		
	}
	A(int x){
		System.out.println("A obj created "+ x);
		this.x=x;
	}
}
