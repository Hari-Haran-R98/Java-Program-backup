
public class EmpClient1 {

	public static void test1(int a) {
		System.out.println("test1 inside "+a);
		a++;
		System.out.println("Inside test1 after increment "+ a);
	}
	
	public static void main(String[] args) {
		int age=40;
		System.out.println("Before the Functioned called "+age);
		test1(age);
		System.out.println("After the Functioned called "+age);
		
		
	}
}
