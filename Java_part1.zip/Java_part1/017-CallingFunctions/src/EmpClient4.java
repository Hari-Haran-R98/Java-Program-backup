import java.util.Arrays;

public class EmpClient4 {

	// parameter can receive only array variable
	public static void test1(int[] x) {
		System.out.println(Arrays.toString(x));
	}
	
	//  Parameter var-args can receive a array variable and also array vales directly 
	public static void test2(int...y) {
		System.out.println(Arrays.toString(y));
	}
	public static void main(String[] args) {
	int[] arr1= {1,2,3};
	test1(arr1);
	int[] arr2= new int[] {10,20,30,40,50};
	test1(arr2);
	int[]arr3= {};
	test1(arr3);

	test2(10,20,30,40,50,60,70,33);
	test2(arr1);
	test2();
	
}
}
