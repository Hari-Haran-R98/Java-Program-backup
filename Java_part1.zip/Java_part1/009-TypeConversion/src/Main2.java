
public class Main2 {
public static void main(String[] args) {
	int v1=100;
	short v2=(short)v1;//explicit, narrow conversion
	byte v3=(byte)v2;//explicit, narrow conversion
	
	double v4=90.0;//explicit, narrow conversion
	
	short v5=(short)v4;//explicit, narrow conversion
	
	byte v6=(byte)v4;//explicit, narrow conversion
	
	int v7=(int)v4;//explicit, narrow conversion
	
	float v11=(float) v4; //explicit, narrow conversion
	
	long v8=(long)v4;//explicit, narrow conversion
	
	char v9=(char)v4;//explicit, narrow conversion
	//boolean v10=(boolean)v4;// not possible to type cast in boolean
}
}
