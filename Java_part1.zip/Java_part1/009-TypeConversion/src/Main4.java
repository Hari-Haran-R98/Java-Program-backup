
public class Main4 {
public static void main(String[] args) {
	int v1=40;
	long v2=900;
	
	long result1=v1+v2+100; // mixed mode expression
	
	float result2=v1+v2+10.0f;  // mixed mode expression
	
	byte v3=88;
	
	short v4=99;
	
	double result3=v3+v4+10.0; // mixed mode expression
	
	int result4=v3+10+20*40; // mixed mode expression
	
	
}
}
