
public class Main3 {
public static void main(String[] args) {
	int v1=30;
	int v2=40;
	long v3=50;
	double v4=60;
	
	int result=v1+v2;// single mode expression 
	
	long result1=v1+v3+v2;// mixed mode expression 
	
	double result2 = v1+v2+v3+v4;//mixed mode expression 
	
	byte v5=6;
	short v6=7;
	
	int result3=v5+v6;//mixed mode expression in byte and short it cannot be stored in byte 
	//or short insted we use int 
	
	
	int result4=(int)(v1+v2+v3);// narrow conversion 
	float result5=(float)(v1+v2+v3+v4);// narrow conversion
	
	
	
	
}
}
