
public class Main1 {
public static void main(String[] args) {
	
	byte v1=100;// 1 byte
	short v2= v1;// 2 byte // type conversion, implicity, widening conversion
	int v3=v2;// type conversion, implicity, widening conversion
	long v4=v3;// type conversion, implicity, widening conversion
	float v5=v4; // // type conversion, implicity, widening conversion
	double v6=v5;// type conversion, implicity, widening conversion

	int v9=v2;// type conversion, implicity, widening conversion
	char v7=v2; // // type conversion, implicity, widening conversion
	int v8=v7;// type conversion, implicity, widening conversion
	
}
}
