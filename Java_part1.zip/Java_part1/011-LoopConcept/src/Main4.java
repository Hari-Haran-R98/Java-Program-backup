import java.util.Scanner;

public class Main4 {
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	int input;
	do {
		System.out.println("1.Add Employee");
		System.out.println("2.Search Employee");
		System.out.println("3.Display All Employee");
		System.out.println("4.Delete an Employee");
		System.out.println("5.Exit");
		System.out.println("Enter the menu");
		input = sc.nextInt();
		System.out.println(input);
		
	}
	
	while(input!=5);

}
}
