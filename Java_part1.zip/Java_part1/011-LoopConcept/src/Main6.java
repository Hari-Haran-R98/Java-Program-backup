
public class Main6 {
public static void main(String[] args) {
	for(int count=500;count<=1000;count++) {
			if(count%10==0) {
			System.out.println(count);
			}
		}
	System.out.println("==================");
	System.out.println("  ");

	for(int count1=2000;count1>=1000;count1--) {
		if(count1 % 5==0) {
			System.out.println(count1);
		}
	}
	
	}
}
