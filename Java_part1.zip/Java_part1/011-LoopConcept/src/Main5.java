
public class Main5 {
public static void main(String[] args) {
	for(int count=1;count<=10;count++) {
		System.out.print("Welcome ");
		System.out.print("to ");
		System.out.println("Training "+ count);
	}
	System.out.println("Thank you");
}
}
