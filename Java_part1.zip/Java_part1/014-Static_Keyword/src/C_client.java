
public class C_client {
	public static void main(String[] args) {
		C c1 = new C();
		C.count = 0;
		C.count++;
		c1.name="Ramesh";
		//System.out.println(C.count + " Count variable using className ");
		c1.printName();
		C.printCount();
		

		//System.out.println();

		//System.out.println("Using Obj");
		C.count++;
		C c2 = new C();
		c2.name = "Hari";
		c2.printName();
		C.printCount();
	

		//System.out.println("Combained Both cls name and obj");
		//.out.println(++C.count + "  " + c1.name);
		
		C c3= new C();
		C.count++;
		c3.name="haran";
		c3.printName();
		C.printCount();
		

	}
}
