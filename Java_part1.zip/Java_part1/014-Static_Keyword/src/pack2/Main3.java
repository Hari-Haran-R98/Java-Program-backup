package pack2;

import pack1.E;

public class Main3 {
public static void main(String[] args) {
	E obj= new E();
}
}
