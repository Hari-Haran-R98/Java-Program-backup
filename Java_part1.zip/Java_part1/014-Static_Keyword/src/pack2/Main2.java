package pack2;

import pack1.C;

public class Main2 {
public static void main(String[] args) {
	C obj= new C(1,2,3);
	System.out.println("=========================");
	C obj1= new C(10,20);
	System.out.println("==========================");
	C obj2= new C(20);
	
	System.out.println("==========================");
	C obj3= new C();
}
}
