
public class C {
static int count= 0;
String name;
static void printCount() {
	System.out.println("Num of obj "+count );
}

void printName() {
	System.out.println(name);
}
}
