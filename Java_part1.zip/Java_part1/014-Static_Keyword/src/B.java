public class B {
static String companyName="Ust";
String location="trivandram ";

static void greet() {
	System.out.println("How are you");
}
void goodbye() {
	System.out.println("Thank you goodbye ");
}

}
