public class A {
int x;
static int y= 10;
void display1() {
	System.out.println(x);
	System.out.println(y);
}
static void welcome() {// cannot access instance
System.out.println("Welcome");
System.out.println(y);
//System.out.println(x);// this will throw error
}
}
