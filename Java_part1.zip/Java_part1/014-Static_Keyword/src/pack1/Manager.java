package pack1;

public class Manager extends Employee{

	private int employeeCount;

	public Manager(int id, String name, double basic, String gender, int employeeCount) {
		super(id, name, basic, gender);
		this.employeeCount = employeeCount;
	}

	public Manager(int id, String name, double basic, String gender) {
		super(id, name, basic, gender);
	}

	public Manager(int id, String name, double basic) {
		super(id, name, basic);
	}

	public Manager(int id, String name) {
		super(id, name);
	}

	public Manager(int id) {
		super(id);
	}

	public Manager() {
		super();
	}
	
	
	
}
