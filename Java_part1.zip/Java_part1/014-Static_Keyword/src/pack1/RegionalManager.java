package pack1;

public class RegionalManager extends Manager {

	private String regionName;

	public RegionalManager(int id, String name, double basic, String gender, int employeeCount,
			String regionName) {
		super(id, name, basic, gender, employeeCount);
		this.regionName = regionName;
	}

	public RegionalManager(int id, String name, double basic, String gender, String regionName) {
		super(id, name, basic, gender);
		this.regionName = regionName;
	}

	public RegionalManager(int id, String name, double basic, String regionName) {
		super(id, name, basic);
		this.regionName = regionName;
	}

	public RegionalManager(int id, String name, String regionName) {
		super(id, name);
		this.regionName = regionName;
	}

	public RegionalManager(int id, String regionName) {
		super(id);
		this.regionName = regionName;
	}

	public RegionalManager(String regionName) {
		super();
		this.regionName = regionName;
	}
	public RegionalManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RegionalManager(int id, String name, double basic, String gender, int employeeCount) {
		super(id, name, basic, gender, employeeCount);
	}
	
	
	
}
