package pack1;

public class E extends D {

	public E() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("E constructor");
	}
	
}
