package pack1;

public class B {

	private int x,y;
	
	public B(){
		System.out.println("B constructor not arguments");
		}
		
		public B(int x) {
			this();
			//this();// should be in the first line 
			System.out.println("B constructor with 1 arg "+x);
			this.x=x;
		}
		public B(int x,int y) {
			this(x);// should be in the first line 
			System.out.println("B constructor with 2 arg "+x+","+y);
			this.y=y;
		}
}
