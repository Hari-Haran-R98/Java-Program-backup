package pack1;

public class C extends B {

	int z;
	
	public C(int x,int y,int z) {
		// TODO Auto-generated constructor stub
		super(x,y);
	//this.x=x;
	//this.y=y;
	//this.z=z;
	System.out.println("C Constructor with 3 arg "+ x+","+y+","+z);
	}
	
	public C(int x,int y) {
		super(x,y);
		System.out.println("C constructor with 2 arg"+x+","+y);
	}
	public C(int x) {
		super(x);
		System.out.println("C constructor with 2 arg "+x);
	}
	public C() {
		super();
		System.out.println("C constructor with no arg ");
	}
}
