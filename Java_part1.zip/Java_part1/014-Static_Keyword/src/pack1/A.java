package pack1;

public class A {

	int x,y,z;
	
	public A(){
	System.out.println("A obj created not arguments");
	}
	
	public A(int x) {
		this();// should be in the first line 
		System.out.println("A obj created with one arg "+x);
		this.x=x;
	}
	public A(int x,int y) {
		this(x);
		System.out.println("A obj created with two arg "+x +","+y);
		//this.x=x;
		this.y=y;
	}
	public A(int x,int y,int z) {
		this(x,y);// Recommended 
		System.out.println("A obj created with 3 arg "+x +","+y+","+z);
		//this.x=x;// not a good practice 
		//this.y=y;//
		
		this.z=z;
	}
	
	public void display() {
		System.out.println(this.x+","+this.y +","+this.z);
	}
}
