
public class Circle {
int radius;
static double PI=4.0;

double getArea() {
double area=PI*radius*radius;
return area;
}
}
