public class Employee {
	
private double basic;
private String cityName;
private char grade;
private int id;
private String name;
public double getBasic() {
	return basic;
}
public void setBasic(double basic) {
	if(basic<0) {
		System.out.println("Invalid basic");
	}
	this.basic = basic;
}
public String getCityName() {
	return cityName;
}
public void setCityName(String cityName) {
	if(cityName == null) {
		System.out.println("Invalid City name");
		return;
	}
	this.cityName = cityName;
}
public char getGrade() {
	return grade;
}
public void setGrade(char grade) {
	this.grade = grade;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	
	return name;
}
public void setName(String name) {
	if(name == null) {
		System.out.println("Invalid City name");
		return;
	}
	this.name = name;
}




}
