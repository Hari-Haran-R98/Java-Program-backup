
public class StudentClient {
public static void main(String[] args) {
	Student s1= new Student();
	
	s1.setName("Hari");
    s1.setRollNumber(06);
	s1.setGender("male");
	s1.setMark1(98);
	s1.setMark2(93);
	
	System.out.println(s1.getName());
	System.out.println(s1.getRollNumber());
	System.out.println(s1.getMark1());
	System.out.println(s1.getMark2());
	System.out.println(s1.getGender());
}
}
