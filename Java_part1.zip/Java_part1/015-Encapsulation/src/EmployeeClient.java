public class EmployeeClient {
public static void main(String[] args) {
	Employee employee = new Employee();
	employee.setId(106);
	employee.setName("Hari");
	employee.setBasic(0);
	employee.setGrade('A');
	employee.setCityName("CBE");


}
}
