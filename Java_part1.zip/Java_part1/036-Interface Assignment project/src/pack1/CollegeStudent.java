package pack1;

public class CollegeStudent implements Student{

	@Override
	public void enroll() {
		System.out.println("College Student Enrolled");
	}

	@Override
	public void takeExam() {
		System.out.println("College Student Take Exam");

	}

	@Override
	public void leave() {
		System.out.println("College Student Taken Leave");

	}

}
