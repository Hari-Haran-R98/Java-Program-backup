package pack1;

public class UniversityStudent implements Student{

	@Override
	public void enroll() {
		System.out.println("UniversityStudent Student Enrolled");
	}

	@Override
	public void takeExam() {
		System.out.println("UniversityStudent Student Taken Exam");
	}

	@Override
	public void leave() {
		System.out.println("UniversityStudent Student Taken Leave");
	}
}
