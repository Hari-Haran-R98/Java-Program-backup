package pack1;

public class SchoolStudent implements Student{
	
	//inherit Student interface
	//override methods

	@Override
	public void enroll() {
		System.out.println("School Student Enrolled");
	}

	@Override
	public void takeExam() {
		System.out.println("School Student Taken Exam");
	}

	@Override
	public void leave() {
		System.out.println("School Student Taken Leave");
	}

}
