
public class Employee {

	double basicSalary;
	double getNetSalary() {
	double allowance= this.basicSalary*0.30;
	double tax= this.basicSalary*0.10;
	double net=this.basicSalary+allowance-tax;
	return net;
}
	double getNetSalary(double incentive) {
		double allowance= this.basicSalary*0.30;
		double tax= this.basicSalary*0.10;
		double net=this.basicSalary+allowance-tax+incentive;
		return net;
	}
	double getNetSalary(int extraHours) {
		double allowance= this.basicSalary*0.30;
		double tax= this.basicSalary*0.10;
		double net=this.basicSalary+allowance-tax+(extraHours*1000);
		return net;
	}
	double getNetSalary(boolean isPermanent,int extraHours) {
		double allowance= this.basicSalary*0.30;
		double tax= this.basicSalary*0.10;
		double net;
		if(isPermanent)
		net=this.basicSalary+allowance-tax+(extraHours *2000);
		else
			net=this.basicSalary+allowance-tax+(extraHours *500);
		return net;
	}
	
}