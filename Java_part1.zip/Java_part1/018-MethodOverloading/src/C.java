
public class C {

	void display(int p) {
		System.out.println("display with int "+ p);
	}
	void display(short p) {
		System.out.println("display with short "+ p);
	}
}
