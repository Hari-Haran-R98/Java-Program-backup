public class B {

	int totalMark;
	String subject;
	 String group(String subject) {
		this.subject=subject;
		System.out.println("This is based on subject " + subject);
		return subject;
	}

	int  group(int totalMark) {
		//this.totalMark=totalMark;
		if (totalMark < 0 || totalMark > 500) {
			System.out.println("Mark 1 Invalid");
		} else
			System.out.println("This is based on Mark " + totalMark);
		return totalMark;
	}

	static double group(String subject, int totalMark) {

		double fees = 0;
		if (subject == "CS" && totalMark >=450)
			fees = 1000.00;
		else if (subject == "BE" && totalMark >=400)
			fees = 5000.00;
		else if (subject == "Language"&& totalMark >=300)
			fees = 1100.00;
		else {
			System.out.println(" Invalid");
		}
		return fees;
	}
	double group(int totalMark, int fees) {
		
		return fees;
		
	}
	double group(String subject) {
		double schalarship;
		
	}
	
	double group(String subject, int totalMark,int scalarship) {
		double finalFees = 0;
		if (subject == "CS" && totalMark >=475)
			finalFees= totalMark-scalarship;
		
		else if (subject == "BE" && totalMark >=430)
			finalFees= totalMark-scalarship;
		else if (subject == "Language"&& totalMark >=350)
			finalFees= totalMark-scalarship;
		else {
			System.out.println(" Invalid");
		} 
		
		return finalFees;
		
	}

}
