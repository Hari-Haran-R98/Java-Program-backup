
public class BClient {
public static void main(String[] args) {
	B b= new B();
	String s=b.subject="CS";
	int total =b.totalMark=460;
	System.out.println("fees for the student is "+b.group(s, total));
}
}
