
public class AClient {
public static void main(String[] args) {
	A obj= new A();
	obj.test1();
	obj.test1(true);
	obj.test(10, 10.0f);
	obj.test1(10,20.0f,900.00);
}
}
