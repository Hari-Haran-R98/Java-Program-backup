package pack1;

public class B extends A {
@Override
	public void test1() {
		System.out.println("B test1");
	}

//public void test2() {
//	System.out.println("B test2");
//}

@Override
	public void test3() {
		// TODO Auto-generated method stub
		System.out.println("Abstract method Overriden");
	}
}
