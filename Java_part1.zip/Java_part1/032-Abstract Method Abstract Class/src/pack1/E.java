package pack1;

public class E extends D{

	@Override
	public void test3() {
		// TODO Auto-generated method stub
		System.out.println("E test3");
	}

}
