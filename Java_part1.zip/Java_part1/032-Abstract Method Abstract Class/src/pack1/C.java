package pack1;

public class C  extends A{

	@Override
	public void test3() {
		// TODO Auto-generated method stub
		System.out.println("C test3");
	}

}
