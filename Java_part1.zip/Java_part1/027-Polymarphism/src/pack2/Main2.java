package pack2;

import pack1.Manager;

public class Main2 {
public static void main(String[] args) {
	
	// compile time polymarphism, static bainding early bindinggS
	Manager m1= new Manager(1000.00, 10);
	
	System.out.println(m1.computNetSalary());
	System.out.println(m1.computNetSalary(10));
	System.out.println(m1.computNetSalary(10, 1000));
	}
}
