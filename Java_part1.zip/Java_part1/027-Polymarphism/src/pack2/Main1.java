package pack2;

import pack1.Employee;

public class Main1 {
public static void main(String[] args) {
	Employee emp1= new Employee(1000.00);
	//Employee emp1= new Employee(1000.00);
	
	// compile time polymarphism, static bainding early binding
	System.out.println(emp1.computNetSalary());
	System.out.println(emp1.computNetSalary(10));
	System.out.println(emp1.computNetSalary(10,800));
}
}
