package pack1;

public class Employee {
private double basicSalary;

public Employee(double basicSalary) {
	super();
	this.basicSalary = basicSalary;
}

public double computNetSalary() {
	double allowance = this.basicSalary*0.40;
	double net=this.basicSalary+allowance;
	return net;
	
}

public double computNetSalary(int extraHours) {
	double allowance = this.basicSalary*0.40;
	double net=this.basicSalary+allowance+(extraHours*1000);
	return net;
	
}
public double computNetSalary(int extraHours, double perHourPayment) {
	double allowance = this.basicSalary*0.40;
	double net=this.basicSalary+allowance+(extraHours*perHourPayment);
	return net;
	
}

@Override
public String toString() {
	return "Employee [basicSalary=" + basicSalary + "]";
}


}
