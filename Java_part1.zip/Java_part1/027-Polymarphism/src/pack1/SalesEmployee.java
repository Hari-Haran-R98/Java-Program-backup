package pack1;

public class SalesEmployee extends Employee{

	private double salesAchibed;

	
	
	public SalesEmployee(double basicSalary, double salesAchibed) {
		super(basicSalary);
		this.salesAchibed = salesAchibed;
	}

	@Override
	public double computNetSalary() {
		// TODO Auto-generated method stub
		double net= super.computNetSalary();
		net=net+(salesAchibed*0.25);
		return net;
	}
	
	@Override
	public double computNetSalary(int extraHours) {
		double net= super.computNetSalary(extraHours);
		net=net+(salesAchibed*0.25);
		return net;
	}
	@Override
	public double computNetSalary(int extraHours, double perHourPayment) {
		double net= super.computNetSalary(extraHours,perHourPayment);
		net=net+(salesAchibed*0.25);
		return net;	
		}

	@Override
	public String toString() {
		return "SalesEmployee [salesAchibed=" + salesAchibed + "]";
	}
	
}

