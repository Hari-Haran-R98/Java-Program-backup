package pack1;

public class Manager extends Employee {
	

	public Manager(double basicSalary, int empcount) {
		super(basicSalary);
		this.empcount = empcount;
	}
	private int empcount;
	
	@Override
	public double computNetSalary() {
		// TODO Auto-generated method stub
		double net= super.computNetSalary();
		net = net+(this.empcount*2000.00);
		return net;
	}
	@Override
	public double computNetSalary(int extraHours) {
		// TODO Auto-generated method stub
		double net= super.computNetSalary(extraHours);
		net = net+(this.empcount*2000.00);
		return net;

	}
	@Override
	public double computNetSalary(int extraHours, double perHourPayment) {
		double net= super.computNetSalary(extraHours,perHourPayment);
		net = net+(this.empcount*3000.00);
		net=net+5000.00;
		return net;
		
	}
	@Override
	public String toString() {
		return "Manager [empcount=" + empcount + "]";
	}
	
}
