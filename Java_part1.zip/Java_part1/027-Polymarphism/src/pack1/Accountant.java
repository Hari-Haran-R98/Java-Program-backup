package pack1;

public class Accountant extends Employee {
	boolean auditor;

	public Accountant(double basicSalary, boolean auditor) {
		super(basicSalary);
		this.auditor = auditor;
	}
	@Override
	public double computNetSalary() {
		// TODO Auto-generated method stub
		double net= super.computNetSalary();
		if(auditor) 
		net= net+10000.00;
		return net;
	}
	public double computNetSalary(int extraHours) {
		// TODO Auto-generated method stub
		double net= super.computNetSalary(extraHours);
		if(auditor) 
		net= net+10000.00;
		return net;
	}
	public double computNetSalary(int extraHours, double perHourPayment) {
		// TODO Auto-generated method stub
		double net= super.computNetSalary(extraHours, perHourPayment);
		if(auditor) 
		net= net+10000.00;
		return net;
	}
	
}
