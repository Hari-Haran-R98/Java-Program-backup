package pack1;

public class D extends C {

	@Override
	private void f1() {
		System.out.println("instance method with no return type and perameter ");
	}

	@Override
	public static void f2() {
		System.out.println("normal static method redefined ");
	}

	@Override
	public int f3(int a) {
		System.out.println("return type changed in overriding ");
		return 0;  
	}

	@Override
	public void f4(int a, int a) {
		System.out.println("1 peremeter redefined");
	}

	@Override
	public void f5(int a, int b) {
		System.out.println("static  method redefined");
	}

	@Override

	public static void f6(int a) {
		System.out.println("instance method redefined as static ");
	}

	@Override
	protected void f7() {
		System.out.println("Public access level redefined");
	}

	@Override
	public final void f8() {
		System.out.println("final method redefined");
	}

}
