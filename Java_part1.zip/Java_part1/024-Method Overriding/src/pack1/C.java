package pack1;

public class C {

	protected C() {
		// TODO Auto-generated constructor stub
	}

	private C(int a) {

	}

	private void f1() {
		System.out.println("instance method with no return type and perameter ");
	}

	public void f1(int a) {
		System.out.println("instance method with no return type with perameter ");
	}

	public static void f2() {
		System.out.println("static method");
	}

	public static void f2(int a) {
		System.out.println("Static with 1 parameter ");
	}

	public void f3(int a) {
		System.out.println("no return type");
	}

	public int f3(int a, int b) {
		System.out.println("int as return type");
		return a;
	}

	public void f4(int a) {
		System.out.println("1 peremeter ");
	}

	public void f4(int a, int b) {
		System.out.println("2 peremeter ");
	}

	public static void f5(int a, int b) {
		System.out.println("static  method");
	}

	public void f5(int a) {
		System.out.println("static to no static overloading ");
	}

	public void f6(int a) {
		System.out.println("instance method");
	}

	public static void f6(int a, int b) {
		System.out.println("instance method to static method ");
	}

	public void f7() {
		System.out.println("Public access level");
	}

	protected void f7(int a) {
		System.out.println("Protected access level");
	}

	public final void f8() {
		System.out.println("final method");
	}

	public final void f8(int a) {
		System.out.println("final method overloaded");
	}

}
