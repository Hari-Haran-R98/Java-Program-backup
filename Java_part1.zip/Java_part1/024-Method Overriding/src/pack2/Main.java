package pack2;

import pack1.Employee;
import pack1.Manager;

public class Main {
public static void main(String[] args) {
	
	Employee emp= new Employee();
	emp.basicSalary=1000.00;
	System.out.println(emp.computeNetSalary());
	System.out.println("get tax ="+emp.getTax());
	
	Manager manager= new Manager();
	manager.basicSalary=1000.00;
	manager.empCount=10;
System.out.println(manager.computeNetSalary());
System.out.println("get tax ="+manager.getTax());
}
}
