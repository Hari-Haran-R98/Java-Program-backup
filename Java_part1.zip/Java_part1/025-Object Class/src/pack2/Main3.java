package pack2;

import pack1.Accountant;
import pack1.Circle;
import pack1.Employee;
import pack1.Manager;
import pack1.SalseEmployee;
import pack1.Square;
import pack1.Student;

public class Main3 {
	public static void print1(Circle c) {
		System.out.println(c.getRadius());
	}
	
	public static void  print2(Employee e) {
		if (!(e instanceof Student)||(!(e instanceof Square))) {
		System.out.println(e.getId());
		System.out.println(e.getName());
		System.out.println(e.getBasic());
		}
		if(e instanceof Manager) {
		Manager m= (Manager)e;// Reference casting down casting, explicit
		System.out.println(m.getEmplolyeeCount());}
		if(e instanceof SalseEmployee) {
		SalseEmployee s=(SalseEmployee)e;
		System.out.println(s.getAreaName());}
		
		 if(e instanceof Accountant) {
			Accountant temp=(Accountant)e;
			System.out.println(temp.isAuditor());
		}
		 if(e instanceof Student) {
			 Student temp =(Student)e;
			 System.out.println(temp.getRollNo());
			 System.out.println(temp.getName());
			 System.out.println(temp.getMark1());
			 System.out.println(temp.getMark2());
			 System.out.println(" total mark is :"+temp.getTotal());
		 }
		 
		 if(e instanceof Square) {
			 Square temp=(Square)e;
			 System.out.println("Area of the Square :"+temp.getArea());
		 }
	}
	
	public static void print3(Object o) {
		if(o instanceof Circle) {
			Circle temp=(Circle)o;
			System.out.println(temp.radius);
		}

		if(o instanceof Employee) {
			Employee temp=(Employee)o;
			System.out.println(temp.getId());
			System.out.println(temp.getName());
			System.out.println(temp.getBasic());
		}
		
		if(o instanceof Manager) {
			Manager temp=(Manager)o;
			System.out.println(temp.getEmplolyeeCount());
		}
		if(o instanceof Square) {
			Square temp=(Square)o;
			System.out.println("The area of the square is :"+temp.getArea());
		}
	}
public static void main(String[] args) {
	
	
	
	Circle c1 = new Circle();
	c1.radius=90;
	//print1(c1);
	
	Employee e= new Employee(101,"Ram",3000);
	//print2(e);
	
	Manager m= new Manager(102,"Hari",4000.00,10);
	//print2(m);
	
	SalseEmployee s= new SalseEmployee();
	s.setId(103);
	s.setName("Haran");
	s.setBasic(5000.00);
	s.setAreaName("Bamglore");
	
	//print2(s);
	
	Accountant a= new Accountant();
	a.setId(104);
	a.setName("Nanjan");
	a.setBasic(4000.00);
	a.setAuditor(false);
	
//	print2(a);
//	print2(e);
//	print2(m);

//	System.out.println("===========================");
//	System.out.println("Student Details");
	Student s1= new Student(101, "Hariharan", 95, 100);
	//print2(s1);
	
	Square sq = new Square(30);
	print2(sq);
	print3(sq);
	

}
}
