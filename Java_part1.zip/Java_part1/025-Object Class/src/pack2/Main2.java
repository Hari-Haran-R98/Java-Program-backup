package pack2;

import pack1.Circle;
import pack1.Employee;
import pack1.Manager;
import pack1.SalseEmployee;

public class Main2 {
public static void main(String[] args) {
	
	byte b=90;
	int i=b;
	// Reference casting subclass Obj is stored in Super class referance
	
	
	Object obj;
	     obj =new Employee(); 
	   
	    obj= new SalseEmployee();
	    
	    obj= new Manager();
	    
	    obj= new Circle();
	    
}
}
