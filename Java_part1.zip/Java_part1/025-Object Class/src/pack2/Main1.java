package pack2;

import pack1.Circle;
import pack1.Employee;
import pack1.Manager;

public class Main1 {
	public static void main(String[] args) {
		
	Circle cr= new Circle();
	
	Employee e= new Employee();
	
	Manager m= new Manager();
	
	
	
}
}