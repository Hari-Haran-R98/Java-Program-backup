package pack1;

public class Square extends Employee{
public int size;

public Square(int size) {
	super();
	this.size = size;
}
public Square() {
	// TODO Auto-generated constructor stub
}
public int getSize() {
	return size;
}
public void setSize(int size) {
	this.size = size;
}
public int getArea() {
	return this.size* this.size;
}

	}
