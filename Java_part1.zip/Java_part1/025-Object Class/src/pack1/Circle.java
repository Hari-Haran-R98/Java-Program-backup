package pack1;

public class Circle {

	public int radius;
	
	public int getRadius() {
		return radius;
	}

}
