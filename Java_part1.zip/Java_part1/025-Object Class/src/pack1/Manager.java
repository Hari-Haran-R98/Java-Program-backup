package pack1;

public class Manager extends Employee{
	int emplolyeeCount;

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Manager(int id, String name, double basic) {
		super(id, name, basic);
		// TODO Auto-generated constructor stub
	}
	

	public Manager(int id, String name, double basic, int emplolyeeCount) {
		super(id, name, basic);
		this.emplolyeeCount = emplolyeeCount;
	}

	public int getEmplolyeeCount() {
		return emplolyeeCount;
	}

	public void setEmplolyeeCount(int emplolyeeCount) {
		this.emplolyeeCount = emplolyeeCount;
	}
	
	
	
}
