package pack2;

public class C implements A{

}
