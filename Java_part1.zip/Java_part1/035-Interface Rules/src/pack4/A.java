package pack4;

public interface A {

}
