package pack1;

public interface A {

	void test1();
	void test2();
	
}
