package pack5;

public interface A {

	int x=100;
	void test1();
	void test2();
}
