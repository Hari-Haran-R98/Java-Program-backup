package pack1;

public class Main1 {
public static void main(String[] args) {

	int a= 100;
	Integer iobj1=new Integer(a);// wrapper class 
	Integer iobj2= Integer.valueOf(10000);
	//System.out.println(iobj2);
	
	byte v1=iobj2.byteValue();
	System.out.println(v1);
	
	short v2=iobj2.shortValue();
	System.out.println(v2);
	
	int v3=iobj2.intValue();
	System.out.println(v3);
	
	long v4=iobj2.longValue();
	System.out.println(v4);
	
	float v5=iobj2.longValue();
	System.out.println(v5);
	
	double v6=iobj2.longValue();
	System.out.println(v6);

	System.out.println(Integer.toBinaryString(665));
	System.out.println(Integer.toOctalString(665));
	System.out.println(Integer.toHexString(665));
	System.out.println(Integer.toString(665, 2));
	System.out.println(Integer.toString(665, 8));
	System.out.println(Integer.toString(665, 16));

	int x=Integer.parseInt("125");
	System.out.println(++x);
	
	Integer obj1= Integer.valueOf(100);
	Integer obj2= Integer.valueOf(100);
	Integer obj3= Integer.valueOf(200);
	
	System.out.println(obj1.equals(obj2));
	System.out.println(obj1.equals(obj3));
	
	int r=obj1.compareTo(obj2);
	if(r<0)
		System.out.println("Invoking obj is less then parameter obj");
	if(r==0)
		System.out.println("Invoking obj is same as parameter obj");
	if(r>0)
		System.out.println("Invoking object higher then parameter obj");

	Integer obj4=128;   // auto boxing 
	Integer obj5=128;
	
	System.out.println(obj4==obj5);

	System.out.println(obj4.equals(obj5));
	
}
}
