package pack1;

public class Main6 {
	public static void main(String[] args) {
		
		double d=1000.00;
		
		Double d1=Double.valueOf(d);//Boxing 
		
		double  v1=d1.doubleValue();// Unboxing 
		System.out.println(v1);
		
		byte v2= d1.byteValue();
		
		System.out.println(v2);
		
		short v3=d1.shortValue();
		System.out.println(v3);
		
		int  v4=d1.intValue();
		System.out.println(v4);
		
		long  v5=d1.longValue();
		System.out.println(v5);
		
		float  v6=d1.floatValue();
		System.out.println(v1);
	
		
		String str="980.00";
		Double x=Double.parseDouble(str);
		System.out.println(++x);
		
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);
}}
