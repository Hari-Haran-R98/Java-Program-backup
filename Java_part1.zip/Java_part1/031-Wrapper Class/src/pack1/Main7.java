package pack1;

public class Main7 {

	public static void main(String[] args) {
		Integer obj1= Integer.valueOf(200);
		int x=500;
		Integer obj2=x;// AutoBoxing 
		
		int y=obj2;// AutoUnboxing 
		
		System.out.println(obj2);
		
		obj2++;// obj2.intValur(), increment the extracted value ,Integer.valueOf(incremented data)
		//obj2 will refer to a new object.
		
		System.out.println(obj2);
		
	}
}
