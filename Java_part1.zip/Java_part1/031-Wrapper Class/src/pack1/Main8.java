package pack1;

public class Main8 {

	public static void main(String[] args) {
		double d=100.00;
		
		Double obj1=d;// AutoBoxing
		
		System.out.println(obj1+" AutoBoxing");
		
		double d1=obj1;//AutoUnboxing
		
		System.out.println(d1+" AutoUnBoxing");
		obj1--;
		System.out.println(obj1);
		
		obj1++;
		
		System.out.println(obj1);
		
	
	}
}
