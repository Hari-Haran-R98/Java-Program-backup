package pack1;

public class Main3 {
public static void main(String[] args) {
	short s=100;
	
	Short s1=Short.valueOf(s); // Boxing 
	
	short v1=s1.shortValue();// Unboxing 
	
	
	System.out.println(v1);
	
	
	byte v2= s1.byteValue();
	
	System.out.println(v2);
	
	int  v3=s1.intValue();
	System.out.println(v3);
	
	long  v4=s1.longValue();
	System.out.println(v4);
	
	float  v5=s1.floatValue();
	System.out.println(v5);
	
	double  v6=s1.doubleValue();
	System.out.println(v6);
	
	String str="98";
	short x=Short.parseShort(str);
	System.out.println(++x);
	
	System.out.println(Short.MIN_VALUE);
	System.out.println(Short.MAX_VALUE);
}
}
