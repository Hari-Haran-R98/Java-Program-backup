package pack1;

public class Main5 {
public static void main(String[] args) {
	
	float f=100.0f;
	
	Float f1=Float.valueOf(f);// Boxing 
	
	float  v1=f1.floatValue();// Unboxing 
	System.out.println(v1);
	
	byte v2= f1.byteValue(); 
	
	System.out.println(v2);
	
	short v3=f1.shortValue();
	System.out.println(v3);
	
	int  v4=f1.intValue();
	System.out.println(v4);
	
	long  v5=f1.longValue();
	System.out.println(v5);
	
	double  v6=f1.doubleValue();
	System.out.println(v6);
	
	String str="98.00";
	Float x=Float.parseFloat(str);
	System.out.println(++x);
	
	System.out.println(Float.MIN_VALUE);
	System.out.println(Float.MAX_VALUE);
}

}
