package pack1;

public class Main2 {
public static void main(String[] args) {
	byte b=100;
	Byte b1= Byte.valueOf(b);// Boxing 
	
	byte v1= b1.byteValue();// unboxing 
	
	System.out.println(v1);
	
	short v2=b1.shortValue();
	System.out.println(v2);
	
	int  v3=b1.intValue();
	System.out.println(v3);
	
	long  v4=b1.longValue();
	System.out.println(v4);
	
	float  v5=b1.floatValue();
	System.out.println(v5);
	
	double  v6=b1.doubleValue();
	System.out.println(v6);
	
	String str="98";
	byte x=Byte.parseByte(str);
	System.out.println(++x);
	
	System.out.println(Byte.MIN_VALUE);
	System.out.println(Byte.MAX_VALUE);
}
}
