package pack1;

public class Main4 {
	public static void main(String[] args) {
		
		long l=100;
		
		Long l1=Long.valueOf(l); // Boxing 
		
		long  v1=l1.longValue();// Unboxing 
		System.out.println(v1);
		
		byte v2= l1.byteValue();
		
		System.out.println(v2);
		
		short v3=l1.shortValue();
		System.out.println(v3);
		
		int  v4=l1.intValue();
		System.out.println(v4);
		
		float  v5=l1.floatValue();
		System.out.println(v5);
		
		double  v6=l1.doubleValue();
		System.out.println(v6);
		
		String str="98";
		Long x=Long.parseLong(str);
		System.out.println(++x);
		
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MAX_VALUE);
	}
}
