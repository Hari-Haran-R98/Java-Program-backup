package pack1;

public class Main10 {

	public static void main(String[] args) {
		boolean auditor=true;
		
		Boolean obj=Boolean.valueOf(auditor);//Boxing
		
		boolean b= obj.booleanValue();//UnBoxing
		
	}
}
