package pack1;

public class Square implements Shape {

	private int size;

	public Square(int size) {
		super();
		this.size = size;
	}

	public Square() {
		super();
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	
	public double computerArea() {
		return this.size*this.size;
	}

	@Override
	public String toString() {
		return "Squre [getSize()=" + getSize() + ", computerArea()=" + computerArea() + "]";
	}

	@Override
	public double getArea() {
		return computerArea();
	}
	
}
