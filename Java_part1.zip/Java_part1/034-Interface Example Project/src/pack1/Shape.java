package pack1;

public interface Shape {

	double PI=3.14; // public static final by default
	
	//methods are public abstract by default
	void setSize(int size);
	int getSize();
	double getArea();
}
