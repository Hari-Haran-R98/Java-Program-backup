package pack2;

import pack1.Circle;

public class Main1 {

	public static void main(String[] args) {
		Circle c= new Circle();
	
		c.setRadius(10);
		
		System.out.println(c.getRadius());
		System.out.println(c.calculateArea());
	}
}
