
public class SalesEmployee extends Employee {
private String salesAreaName;

public String getSalesAreaName() {
	return salesAreaName;
}

public void setSalesAreaName(String salesAreaName) {
	this.salesAreaName = salesAreaName;
}

	
}
