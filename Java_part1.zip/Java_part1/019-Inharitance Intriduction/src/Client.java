
public class Client {
	public static void main(String[] args) {
		Manager manager = new Manager();
		manager.setId(101);
		manager.setName("Hariharan");
		manager.setGender("Male");
		manager.setBasicSalary(1000.00);
		manager.setEmpCount(50);

		System.out.println("Id :" + manager.getId());
		System.out.println("Name :" + manager.getName());
		System.out.println("Gender :" + manager.getGender());
		System.out.println("Basic Salary :" + manager.getBasicSalary());
		System.out.println("Employee count :" + manager.getEmpCount());
		System.out.println("Net Salary :" + manager.getNetsalary());

		SalesEmployee sales = new SalesEmployee();
		sales.setId(102);
		sales.setName("Haran");
		sales.setGender("Male");
		sales.setBasicSalary(4000.00);
		sales.setSalesAreaName("Banglore");

		System.out.println("Id :" + sales.getId());
		System.out.println("Name :" + sales.getName());
		System.out.println("Gender :" + sales.getGender());
		System.out.println("Basic Salary :" + sales.getBasicSalary());
		System.out.println("Sales Area :" + sales.getSalesAreaName());
		System.out.println("Net Salary :" + sales.getNetsalary());

	}

}
