public class Manager extends Employee{
	private int empCount;
	
	
public int getEmpCount() {
		return empCount;
	}


	public void setEmpCount(int empCount) {
		this.empCount = empCount;
	}


public static void main(String[] args) {
	
}

//double cmputeAllowance() {
//	return getBasicSalary()*0.40;
//}

double computeAllowance() {
	return basicSalary*0.40;
}

}
