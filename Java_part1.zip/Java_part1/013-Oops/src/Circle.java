
public class Circle {

int radius;
//double computeArea() {
//}



}

