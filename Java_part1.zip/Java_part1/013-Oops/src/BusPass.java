
public class BusPass {
	int distance;

	char getPassType() {
		char buspasstype = 0;
		if (distance >= 50)
			buspasstype = 'A';
		else if (distance >= 30)
			buspasstype = 'B';
		else if (distance >= 15)
			buspasstype = 'C';
		else if (distance >= 10)
			buspasstype = 'D';
		return buspasstype;
	}

	double getPassPrice() {
		double price;
		switch (getPassType()) {
		case 'A':
			price = distance * 5;
			break;
		case 'B':
			price = distance * 7;
			break;
		case 'C':
			price = distance * 10;
			break;
		default:
			price = 15;
			break;
		}
		return price;
	}

	String passDetails() {
		String details = "Pass type " + getPassType() + " " + "Pass Price " + getPassPrice();

		return details;
	}
}
