
public class BankAccount {
double balance;

void deposit(double amt) {
	balance=balance+amt;}
void Withdraw(double amt) {
	balance=balance-amt;
}
void printBalance() {
	System.out.println("The Balance is "+ balance);
}
double getbalance() {
	return balance;
}
}
