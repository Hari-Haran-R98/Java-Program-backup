public class SquareClient {
public static void main(String[] args) {
	Square s1= new Square();
	s1.size=2;
	System.out.println(s1.getArea());
	
	Square s2= new Square();
	s2.size=5;
	System.out.println(s2.getArea());
	
	Square s3= new Square();
	s3.size=10;
	System.out.println(s3.getArea());
}
}
