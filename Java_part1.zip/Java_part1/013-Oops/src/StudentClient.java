
public class StudentClient {
public static void main(String[] args) {
	
	Student s1= new Student();

	s1.name= "Hari";
	s1.mark1=95;
	s1.mark2=98;
	
	System.out.println("Name ="+s1.name+" "+"Mark 1 ="+s1.mark1+"Mark 2 ="+s1.mark2+"total ="
	+ s1.computeTotal()+"Average ="+s1.getAverage()+"Grade ="+s1.getGrade());
	
	Student s2= new Student();

	s2.name= "Kavin";
	s2.mark1=60;
	s2.mark2=65;
	
	System.out.println("Name ="+s2.name+" "+"Mark 1 ="+s2.mark1+"Mark 2 ="+s2.mark2+"total ="
	+ s2.computeTotal()+"Average "+s2.getAverage()+"Grade "+s2.getGrade());
	
	Student s3= new Student();

	s3.name= "Goku";
	s3.mark1=45;
	s3.mark2=52;
	
	System.out.println("Name "+s3.name+" "+"Mark 1 "+s3.mark1+"Mark 2 "+s3.mark2+"total "
	+ s3.computeTotal()+"Average "+s3.getAverage()+"Grade "+s3.getGrade());
	

}
}
