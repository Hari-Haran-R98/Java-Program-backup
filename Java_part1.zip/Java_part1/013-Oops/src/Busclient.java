
public class Busclient {
	public static void main(String[] args) {

		BusPass b1 = new BusPass();

		b1.distance = 46;

		System.out.println(b1.passDetails());
		BusPass b2 = new BusPass();

		b2.distance = 75;

		System.out.println(b2.passDetails());
		BusPass b3 = new BusPass();

		b3.distance = 15;
		
		System.out.println(b3.passDetails());
	}
}
