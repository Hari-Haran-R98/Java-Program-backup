
public class Student {
String name;
int mark1, mark2;
int computeTotal() {
	int total;
	total=mark1+mark2;
	return total;
}
int getAverage() {
	int average;
	average=computeTotal()/2;
	
	return average;
	
}
char getGrade() {
	char grade;
	int avg=getAverage();
	if(avg>=80) 
		grade='A';
		else if(avg>=60) 
			grade='B';
		else if(avg>=40) 
			grade='C';
		else
			grade='D';
	
	return grade;
}

}
