import java.util.Scanner;

public class Main10 {
public static void main(String[] args) {
	
	Scanner sc= new Scanner(System.in);
	int currentQuantity;
	System.out.println("Enter the value");
	currentQuantity = sc.nextInt();
	
	final int a=10;
	final int b=20;
	final int c=30;
	final int d=50;
	
	
	
	
	switch(currentQuantity) {
	case a:System.out.println("Stock Level Very Low");break;
	case b:System.out.println("Stock Level Low");break;
	case c:System.out.println("Stock Level Low");break;
	case d:System.out.println("Stock Level ok");break;
	default:System.out.println("Invalid Stock Level");
	}
}
}
