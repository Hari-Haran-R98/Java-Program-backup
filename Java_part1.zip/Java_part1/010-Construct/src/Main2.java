
public class Main2 {
public static void main(String[] args) {
	int age=44;
	
	// Selection constructed 
	
	if(age>=18) {
		System.out.println("Your age is above 18");
		
		System.out.println("You are Eligable for vote");
	}else {
		System.out.println("Your age is below 18");
		
		System.out.println("You have to wite to become Eligable for vote");
	}
}
}
