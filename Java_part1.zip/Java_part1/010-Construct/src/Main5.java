import java.util.Scanner;

public class Main5 {
public static void main(String[] args) {
	
	Scanner sc= new Scanner(System.in);
	
	int qty;
	System.out.println("Enter the Qty");
	qty= sc.nextInt();
	
	// take input for qty from user at run time 
	//  qty >=90 print *****
	//  >=70 print ****
	// >=50 print ***
	//<50 print **
	
	
	if(qty>=90) {
		System.out.println("*****");
	}
	else if(qty>=70) {
		System.out.println("****");
	}
	else if(qty>=50){
		System.out.println("***");
	}
	else {
		System.out.println("**");
	}
}
}

