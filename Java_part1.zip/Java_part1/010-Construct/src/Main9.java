
public class Main9 {
public static void main(String[] args) {
	String city="Mumbai";
	
	switch(city) {
	case "Chennai": System.out.println(1);break;
	case "Banglore": System.out.println(1);break;
	case "Mumbai": System.out.println(1);break;
	case "Puna": System.out.println(1);break;
	default:System.out.println("Invalid Input");break;
	
	}
}
}
