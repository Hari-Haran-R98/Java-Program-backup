
public class Main1 {
public static void main(String[] args) {
	// Sequencial construct
	
	System.out.println("a");
	
	System.out.println("b");
	
	System.out.println("c");
	
	System.out.println("d");
	
	System.out.println("e");
}
}
