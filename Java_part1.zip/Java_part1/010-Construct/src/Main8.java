
public class Main8 {
public static void main(String[] args) {

	byte size=20;
	
	final int aValue=50;
	
	final int bValue=100;
	
	final int cValue=127;
	
	final int dValue=128;
	
	switch(size) {
	case aValue:System.out.println("Welcome 1");
	
	case bValue:System.out.println("Welcome 2");
	
	case cValue:System.out.println("Welcome 3");
	
	//case cValue:System.out.println("Welcome 1"); ---> case error
	}
}
}
