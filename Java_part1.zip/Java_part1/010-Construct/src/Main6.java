import java.util.Scanner;

public class Main6 {
public static void main(String[] args) {
	int mark1,mark2;
	
	// take input for mark1 and mark2 at run time
	float average;
	char grade;
	//compute the average;
	//agerage 80-100 grade A
	//agerage 60-79 grade B
	//agerage 40-59 grade A
	//agerage 0-39 grade A
	
	//grade==a Scholarship ==rs=5000.00
	//grade==b Scholarship ==rs=4000.00
	//grade==c Scholarship ==rs=3000.00
	//grade==d Scholarship ==rs=0.00
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Mark1 out of 100");
	mark1= sc.nextInt();
	System.out.println("Enter Mark2 out of 100");
	mark2=sc.nextInt();
	
	average = (mark1+mark2)/2.0f;
	
	if(average >= 80 ) {
		grade='A';
		System.out.println("Grade "+grade +" "+"Scholarship Rs=50000.00");}
		else if( average >= 60 ) {
			grade='B';
			System.out.println("Grade "+grade+" "+"Scholarship Rs=40000.00");
		}
		else if(average >= 40) {
			grade='C';
			System.out.println("Grade "+grade+" "+"Scholarship Rs=30000.00");
		}
		else {
			grade='D';
			System.out.println("Grade "+grade+" "+"Scholarship Rs=00.00");
		}
}
}
