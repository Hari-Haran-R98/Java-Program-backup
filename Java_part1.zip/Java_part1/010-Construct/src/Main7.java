
public class Main7 {
public static void main(String[] args) {
	char grade='D';
	
	switch(grade) {
	case 'A':System.out.println("Scholarship amount is Rs=50000.00");
	break;
	case 'B':System.out.println("Scholarship amount is Rs=40000.00");
	break;
	case 'C':System.out.println("Scholarship amount is Rs=30000.00");
	break;
	case 'D':System.out.println("Scholarship amount is Rs=0.00");
	break;
	default: System.out.println("Invalid grade");
	
	}
}
}
// Switch variable/expression are 
//byte
//short
//int 
//char