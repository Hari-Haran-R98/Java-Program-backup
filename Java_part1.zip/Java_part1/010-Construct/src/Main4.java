
public class Main4 {
public static void main(String[] args) {
	int marks;
	marks=66;
	char grade;
	
	if(marks>=90) {
		grade='A';
		System.out.println("Your Elgiable for Scholarship");
	}
	else if(marks>=70) {
		grade='B';
		System.out.println("Your Elgiable for Scholarship");
	}
	else if(marks>=50){
		grade='C';
		System.out.println("Your not Elgiable for Scholaeship");
	}
	else {
		grade='D';
		System.out.println("Your not Elgiable for Scholaeship");
	}
}
}
