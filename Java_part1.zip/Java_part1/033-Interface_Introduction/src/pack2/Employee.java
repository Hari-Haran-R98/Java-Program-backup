package pack2;

import pack1.AGradeEmployeeSalaryCalculation;
import pack1.SalaryCalculation;

public class Employee {

	private int id;
	private String name;
	private double basicSalary;
	private char garde;
	private SalaryCalculation sc;// interface type variable
	public Employee() {
		super();
	}
	public Employee(int id, String name, double basicSalary, char garde) {
		super();
		setId(id);
		setName(name);
		setBasicSalary(basicSalary);
		setGarde(garde);
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public double getBasicSalary() {
		return basicSalary;
	}
	public char getGarde() {
		return garde;
	}
	public SalaryCalculation getSc() {
		return sc;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public void setGarde(char garde) {
		this.garde = garde;
		if(this.garde=='A')
			sc=new AGradeEmployeeSalaryCalculation();
		if(this.garde=='B')
			sc=new AGradeEmployeeSalaryCalculation();
		if(this.garde=='C')
			sc=new AGradeEmployeeSalaryCalculation();
		if(this.garde=='D')
			sc=new AGradeEmployeeSalaryCalculation();
		
	}
	public double computeAllowance() {
		return sc.getAllocation(basicSalary);
	}
	public double computeTax() {
		return sc.getDeduction(basicSalary);
	}
	public double computeNetSalary() {
		return sc.getNetSalary(basicSalary);
	}
	
	@Override
	public String toString() {
		return  "Employee [getId()=" + getId() + ", getName=" + getName() + ", getBasicSalary=" + getBasicSalary() + ", getGarde=" + getGarde()
				+ ", computeAllowance()=" + computeAllowance() + ", computeTax()=" + computeTax()
				+ ", computeNetSalary()=" + computeNetSalary() + ",hashCode()=" +hashCode()+"]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result=prime*result+id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Employee))
			return false;
		Employee other = (Employee) obj;
		if (id != other.id)
			return false;
		
				return true;
	}
	

}
