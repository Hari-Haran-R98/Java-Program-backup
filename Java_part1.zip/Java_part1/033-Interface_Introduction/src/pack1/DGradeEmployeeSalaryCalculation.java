package pack1;

public class DGradeEmployeeSalaryCalculation implements
SalaryCalculation{

	@Override
	public double getAllocation(double basic) {
		return basic*0.1;
	}

	@Override
	public double getDeduction(double basic) {
		// TODO Auto-generated method stub
		return basic*0.05;
	}

	@Override
	public double getNetSalary(double basic) {
		return basic+this.getAllocation(basic)-this.getDeduction(basic);
	}

}
