package pack1;

public class CGradeEmployeeSalaryCalculation implements
SalaryCalculation{

	@Override
	public double getAllocation(double basic) {
		return basic*0.2;
	}

	@Override
	public double getDeduction(double basic) {
		// TODO Auto-generated method stub
		return basic*0.10;
	}

	@Override
	public double getNetSalary(double basic) {
		return basic+this.getAllocation(basic)-this.getDeduction(basic);
	}

}
