package pack1;

public interface SalaryCalculation {

	double getAllocation(double basic);
	double getDeduction(double basic);

	double getNetSalary(double basic);

}