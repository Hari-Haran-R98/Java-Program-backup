package pack3;

import pack1.AGradeEmployeeSalaryCalculation;
import pack1.BGradeEmployeeSalaryCalculation;
import pack1.CGradeEmployeeSalaryCalculation;
import pack1.DGradeEmployeeSalaryCalculation;
import pack1.SalaryCalculation;

public class Main1 {

	public static void main(String[] args) {
		SalaryCalculation sc; //cannot creat object, only references can be created
	
		sc=new AGradeEmployeeSalaryCalculation();
		System.out.println(sc.getAllocation(2000.00));
		System.out.println(sc.getDeduction(2000.00));
		System.out.println(sc.getNetSalary(2000.00));
		
		System.out.println("---------------------------B Grade -----------------------------");

		sc=new BGradeEmployeeSalaryCalculation();
		System.out.println(sc.getAllocation(2000.00));
		System.out.println(sc.getDeduction(2000.00));
		System.out.println(sc.getNetSalary(2000.00));
		
		System.out.println("---------------------------B Grade -----------------------------");

		sc=new CGradeEmployeeSalaryCalculation();
		System.out.println(sc.getAllocation(2000.00));
		System.out.println(sc.getDeduction(2000.00));
		System.out.println(sc.getNetSalary(2000.00));
		
		System.out.println("---------------------------B Grade -----------------------------");

		sc=new DGradeEmployeeSalaryCalculation();
		System.out.println(sc.getAllocation(2000.00));
		System.out.println(sc.getDeduction(2000.00));
		System.out.println(sc.getNetSalary(2000.00));
		
		
	}}
