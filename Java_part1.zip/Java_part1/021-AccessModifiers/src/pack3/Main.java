package pack3;

import pack2.E;
//import pack2.F;

public class Main {
  
	public static void main(String[] args) {
		E e = new E();
		
	}
}
