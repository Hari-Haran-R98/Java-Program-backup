package pack1;

public class A {

	private int v1;// only class level access
	int v2;// default 
	protected int v3;//  accessed by subclasses and friendly classes in side and outside the package 
	public int v4;// accessed by any where 
	
	public void test2() {
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(v3);
		System.out.println(v4);
		
	}
}
