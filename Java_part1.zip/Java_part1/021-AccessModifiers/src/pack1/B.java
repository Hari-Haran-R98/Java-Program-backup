package pack1;

public class B {

	A a= new A();
	public void test2() {
		System.out.println(a.v1);   // private error occur 
		System.out.println(a.v2);   //default
		System.out.println(a.v3);   //protected 
		System.out.println(a.v4);   //public
		
	}
}
