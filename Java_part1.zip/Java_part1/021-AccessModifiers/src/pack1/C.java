package pack1;

public class C extends A{
	
	public void test6() {
		System.out.println(v1);   // private error occur 
		System.out.println(v2);   // default
		System.out.println(v3);   // protected 
		System.out.println(v4);   // public 
	
	}
	public void test7() {
		A a= new A();
		System.out.println(a.v1);   // private error occur 
		System.out.println(a.v2);   // default
		System.out.println(a.v3);   // protected 
		System.out.println(a.v4);   // public 
	
	}
}
