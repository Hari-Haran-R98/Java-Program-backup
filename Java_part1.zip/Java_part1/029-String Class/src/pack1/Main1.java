package pack1;

public class Main1 {
	public static void main(String[] args) {
		
		String s= new String ("Welcome");
		System.out.println(s);
		System.out.println(s.length());
		
		chat[] arr= {a,b,c,d,};
	}

}
