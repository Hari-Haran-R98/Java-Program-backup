package com.training.model;

public class Person implements Comparable{

	String name;
	int age;
	
	
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}




	@Override
	public int compareTo(Object o) {

		Person p1=(Person)o;
		if(this.age<p1.age)
			return -1;
		if(this.age>p1.age)
			return 1;
		
		return 0;
	}

	
}
