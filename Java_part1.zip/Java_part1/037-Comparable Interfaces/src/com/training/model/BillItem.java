package com.training.model;

public class BillItem 
implements Comparable{

	private String itemName;
	private int quantity;
	private double price;
	
	
	
	public BillItem(String itemName, int quantity, double price) {
		super();
		this.itemName = itemName;
		this.quantity = quantity;
		this.price = price;
	}



	public BillItem() {
		super();
	}



	public String getItemName() {
		return itemName;
	}



	public int getQuantity() {
		return quantity;
	}



	public double getPrice() {
		return price;
	}



	public void setItemName(String itemName) {
		this.itemName = itemName;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		BillItem other=(BillItem)o;   
	int r=this.itemName.compareTo(other.itemName);	
		return r;
	}

}
