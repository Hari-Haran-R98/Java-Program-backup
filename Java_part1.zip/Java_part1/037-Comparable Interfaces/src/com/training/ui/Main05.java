package com.training.ui;

import com.training.model.Account;

public class Main05 {

	
	public static void main(String[] args) {
		
		Account a1= new Account("Hari", 20000.00);
		Account a2= new Account("Haran", 23000.00);
		
		int r=a1.compareTo(a2);
		System.out.println("BillItem");
		System.out.println(r);
		
		if(r<0)
			System.out.println("Account a1 is smaller then Account a2");
	
		if(r==0)
			System.out.println("Account a1 and Account a2 same size");
		if(r>0)
			System.out.println("Account a1 is bigger then Account a2");

		
	}
}
