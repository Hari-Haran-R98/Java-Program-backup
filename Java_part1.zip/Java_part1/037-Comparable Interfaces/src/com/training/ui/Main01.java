package com.training.ui;

import com.training.model.Circle;

public class Main01 {

	public static void main(String[] args) {
		Circle c1= new Circle(20);
		Circle c2= new Circle(10);
		
		int r= c1.compareTo(c2);
		System.out.println("Circle");
		System.out.println(r);
		
		if(r<0)
			System.out.println("Circle c1 is smaller then circle c2");
	
		if(r==0)
			System.out.println("Circle c1 and circle c2 same size");
		if(r>0)
			System.out.println("Circle c1 is bigger then circle c2");
	}
}
