package com.training.ui;

import com.training.model.Square;

public class Main02 {

	public static void main(String[] args) {
		Square sq1= new Square(44);
		Square sq2= new Square(24);
		
		int r=sq1.compareTo(sq2);
		System.out.println("Square");
		System.out.println(r);
		
		if(r<0)
			System.out.println("Square s1 is smaller then Square s2");
	
		if(r==0)
			System.out.println("Square s1 and Square s2 same size");
		if(r>0)
			System.out.println("Square s1 is bigger then Square s2");

		
	}
}
