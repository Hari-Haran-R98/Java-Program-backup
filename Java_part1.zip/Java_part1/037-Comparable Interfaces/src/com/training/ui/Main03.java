package com.training.ui;

import com.training.model.Person;

public class Main03 {

	public static void main(String[] args) {
		Person p1= new Person("Hari", 22);
		Person p2= new Person("Haran", 25);
		
		int r=p1.compareTo(p2);
		System.out.println("Person");
		System.out.println(r);
		
		if(r<0)
			System.out.println("Person p1 is smaller then Person p2");
	
		if(r==0)
			System.out.println("Person p1 and Person p2 same size");
		if(r>0)
			System.out.println("Person p1 is bigger then Person p2");

		
	}
}
