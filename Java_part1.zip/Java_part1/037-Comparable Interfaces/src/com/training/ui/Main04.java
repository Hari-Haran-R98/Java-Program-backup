package com.training.ui;

import com.training.model.BillItem;

public class Main04 {

	public static void main(String[] args) {
		
		BillItem b1 = new BillItem("Pen", 10, 50);
		BillItem b2 = new BillItem("Pencle", 20, 40);
		
		
		 
		
		int r=b1.compareTo(b2);
		System.out.println("BillItem");
		System.out.println(r);
		
		if(r<0)
			System.out.println("BillItem b1 is smaller then BillItem b2");
	
		if(r==0)
			System.out.println("BillItem b1 and BillItem b2 same size");
		if(r>0)
			System.out.println("BillItem b1 is bigger then BillItem b2");


	}
	
	
}
