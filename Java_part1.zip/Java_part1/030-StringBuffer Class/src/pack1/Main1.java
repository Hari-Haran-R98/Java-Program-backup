package pack1;

public class Main1 {

	public static void main(String[] args) {
		StringBuffer sb1= new StringBuffer("Welcome");
		sb1.append(" to ");
		sb1.append("UST-Global");
		sb1.append("TVM Center");
		System.out.println(sb1);
		
		sb1.append(50);
		sb1.append('A');
		sb1.append(true);
		sb1.append(50.0);
		
		System.out.println(sb1);
		sb1.insert(5, " Java ");
		System.out.println(sb1);
		
		sb1.insert(10, true);
		sb1.deleteCharAt(10);
		
		sb1.delete(10, 20);
		System.out.println(sb1);
		
	}
}
