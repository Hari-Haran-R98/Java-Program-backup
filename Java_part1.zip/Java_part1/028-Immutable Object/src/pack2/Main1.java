package pack2;

public class Main1 {
public static void main(String[] args) {
	final int a= 100;
	System.out.println(a);
	// a=30; notable to modify the final variable 
	
	System.out.println(a+100);
	System.out.println(100);
 }
}
