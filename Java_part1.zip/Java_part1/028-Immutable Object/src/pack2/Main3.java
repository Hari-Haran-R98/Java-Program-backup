package pack2;

import pack1.Circle;

public class Main3 {
	public static void main(String[] args) {
		Circle c1 = new Circle(10);

		System.out.println(c1);

		Circle c2 = c1.enLarge(20);
		System.out.println(c2);

		Circle c3 = new Circle(110);
		System.out.println(c3);

		Circle c4 = c3.enLarge(210);
		System.out.println(c4);
	}
}
