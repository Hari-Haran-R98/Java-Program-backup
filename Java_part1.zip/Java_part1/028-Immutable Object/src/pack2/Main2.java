package pack2;

import pack1.Square;

public class Main2 {
	public static void main(String[] args) {
		Square s1 = new Square(10);
		System.out.println(s1);

		Square s2 = new Square(20);
		System.out.println(s2);
	

		Square s3= s1.enLarge(30);
		System.out.println(s3);
	
	}
}
