package pack1;

public class Circle {

	final private int radius;

	public Circle(int radius) {
		this.radius = radius;
	}

	public double getArea() {
		return (3.14 * (this.radius * this.radius));
	}

	public int getRadius() {
		return radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + ", getArea()=" + getArea() + ", getRadius()=" + getRadius() + "]";
	}

	public Circle enLarge(int byradius) {
		Circle temp = new Circle(this.radius + byradius);
		return temp;
	}
}
