package pack2;

import pack1.Employee;

public class Main7 {
public static void main(String[] args) {
	Employee emp1 = new Employee(101, "Hari", 5000, "A");
	Employee emp2 = new Employee(102, "Hari", 5000, "A");
	Employee emp3 = new Employee(101, "Hari", 5000, "A");
	
	System.out.println(emp1.equals(emp2));

	System.out.println(emp1.equals(emp3));
}
}
