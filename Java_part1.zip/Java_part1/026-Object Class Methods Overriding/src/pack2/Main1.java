package pack2;

import pack1.Circle;
import pack1.Square;

public class Main1 {
public static void main(String[] args) {
	int a=100;
	Circle c= new Circle(10);
	System.out.println(a);//100
	
	System.out.println(c);// hash String after toString it will give Data in Circle
	
	System.out.println(c.toString());// hash String
	
	
	Square s= new Square(a);
	
	Square s1 = new Square(10);
	System.out.println(s);
	System.out.println(s1);
	
}
}
