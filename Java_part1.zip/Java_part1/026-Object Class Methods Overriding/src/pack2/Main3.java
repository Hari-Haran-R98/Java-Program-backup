package pack2;

import pack1.Employee;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee emp= new Employee(101, "hari", 5000.00, "A");
		System.out.println(emp);
	}

}
