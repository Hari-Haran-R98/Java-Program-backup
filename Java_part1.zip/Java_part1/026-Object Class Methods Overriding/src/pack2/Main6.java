package pack2;

import pack1.Square;

public class Main6 {
public static void main(String[] args) {
	Square s1= new Square(100);
	Square s2= new Square(100);
	Square s3= new Square(100);
	
	System.out.println(s1.equals(s2));
	System.out.println(s1.equals(s3));
	System.out.println(s2.equals(s3));
	
}
}
