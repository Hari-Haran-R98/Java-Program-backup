package pack2;

import pack1.Student;

public class Main8 {
private void Mian() {
	// TODO Auto-generated method stub

	Student s1= new Student(101, "Hari", 95, 94);
	Student s2= new Student(103, "Hari", 95, 94);
	Student s3= new Student(101, "Hari", 95, 94);
	System.out.println(s1.equals(s2));
	System.out.println(s1.equals(s3));
}
}
