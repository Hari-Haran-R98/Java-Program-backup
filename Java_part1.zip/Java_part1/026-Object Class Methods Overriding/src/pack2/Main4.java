package pack2;

import pack1.Student;

public class Main4 {
public static void main(String[] args) {
	Student s1= new Student(101, "Hari", 97, 96);
	System.out.println(s1);
}
}
