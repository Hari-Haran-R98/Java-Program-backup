package pack1;

public class Student {
private int rollNo;
private String name;
private int mark1;
private int mark2;
public Student(int rollNo, String name, int mark1, int mark2) {
	super();
	this.rollNo = rollNo;
	this.name = name;
	this.mark1 = mark1;
	this.mark2 = mark2;
}
public int getRollNo() {
	return rollNo;
}
public void setRollNo(int rollNo) {
	this.rollNo = rollNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getMark1() {
	return mark1;
}
public void setMark1(int mark1) {
	this.mark1 = mark1;
}
public int getMark2() {
	return mark2;
}
public void setMark2(int mark2) {
	this.mark2 = mark2;
}

public int computeTotal() {
	return  mark1+mark2;
}
public double computeAverage() {
	return (computeTotal()/2);
}


public char getGrade() {
	if(computeAverage()>=80) 
		return 'A';
	if(computeAverage()>=60) 
		return 'B';
		if(computeAverage()>=40) 
			return 'C';
			if(computeAverage()<40) 
				return 'D';
			else { System.out.println("Invalid Average");}
			return '-';			     
}
@Override
public String toString() {
	return "Student [computeTotal()=" + computeTotal() + ", computeAverage()=" + computeAverage() + ", getGrade()="
			+ getGrade() + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + rollNo;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (!(obj instanceof Student))
		return false;
	Student other = (Student) obj;
	if (rollNo != other.rollNo)
		return false;
	return true;
}


	}



