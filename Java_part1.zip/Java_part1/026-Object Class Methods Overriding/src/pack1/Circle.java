package pack1;

public class Circle {

	public int radius;
	
	public double getArea() {
		return 3.14*this.radius*this.radius;
	}

	public Circle(int radius) {
		super();
		this.radius = radius;
	}
	@Override
	public String toString() {
		return "Circle[radius = " +this.radius+ "]";
	}
	@Override
	public boolean equals(Object o) {
		Circle obj=(Circle)o;
		
	if(	this.radius == obj.radius) {
		return true;
	}
	else
		return false;
	}
	
	public int hashCode() {
		int result = this.radius*50;
		return result;
	}
	
}
