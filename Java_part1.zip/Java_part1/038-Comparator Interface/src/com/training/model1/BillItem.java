package com.training.model1;

import java.util.Comparator;

public class BillItem implements Comparable{

	private String iteamName;
	private int quantity ;
	private double price;
	public String getIteamName() {
		return iteamName;
	}
	public void setIteamName(String iteamName) {
		this.iteamName = iteamName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	public BillItem(String iteamName, int quantity, double price) {
		super();
		this.iteamName = iteamName;
		this.quantity = quantity;
		this.price = price;
	}
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method 

		
		
		return 0;
	}
	
	
	
	
}
