package com.training.model1;

public class Account implements Comparable{
private String customerName;
private double balance;
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Account(String customerName, double balance) {
	super();
	this.customerName = customerName;
	this.balance = balance;
}
@Override
public int compareTo(Object o) {
	
	return 0;
}


}
