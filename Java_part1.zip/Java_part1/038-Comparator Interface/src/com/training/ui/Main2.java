package com.training.ui;

import com.training.model.Comparators.BillitemPriceComparator;
import com.training.model1.BillItem;

public class Main2  {
public static void main(String[] args) {
	BillItem b1= new BillItem("pen", 20, 3000.00);
	BillItem b2= new BillItem("paper", 40, 300.00);
	
	BillitemPriceComparator c1= new BillitemPriceComparator();
	int r=c1.compare(b1, b2);
	
	if(r<0)
		System.out.println("Billitem1 is less then Billitem2 "+r);
	if(r>0)
		System.out.println("Billitem1 is greater then Billitem2 "+r);
	if(r==0)
		System.out.println("Billitem1 is equal Billitem2 " +r);
}
}
