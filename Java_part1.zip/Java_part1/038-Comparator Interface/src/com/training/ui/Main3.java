package com.training.ui;

import com.training.model.Comparators.PersonNameComparator;
import com.training.model1.Person;

public class Main3 {
public static void main(String[] args) {
	
	PersonNameComparator nc= new PersonNameComparator();
	Person p1= new Person("Hari", 26);
	Person p2= new Person("Haran", 26);
	
	
	int result= nc.compare(p1, p2);
	
	if(result<0)
		System.out.println("The PersonName1 is lessthen PersonName2  "+ result);
	if(result>0)
		System.out.println("The PersonName1 is greaterthen PersonName2 "+ result);
		if(result==0)
		System.out.println("The PersonName1 and PersonName2 is same "+ result);
	
}
}
