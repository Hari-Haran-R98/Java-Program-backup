package com.training.ui;

import com.training.model.Comparators.AccountCustomerNameComparator;
import com.training.model1.Account;

public class Main4 {
public static void main(String[] args) {
	Account a1= new Account("Hari", 300000.00);
	Account a2= new Account("Haran", 300000.00);
	
	AccountCustomerNameComparator cnc= new AccountCustomerNameComparator();
	int result =cnc.compare(a1, a2);
	
	if(result<0)
		System.out.println("The CustomerName1 is lessthen CustomerName2  "+ result);
	if(result>0)
		System.out.println("The CustomerName1 is greaterthen CustomerName2 "+ result);
		if(result==0)
		System.out.println("The CustomerName1 and CustomerName2 is same "+ result);
}
}
