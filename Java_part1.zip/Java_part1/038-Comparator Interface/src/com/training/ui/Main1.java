package com.training.ui;

import com.training.model.Comparators.BillitemQuantityComparator;
import com.training.model1.BillItem;

public class Main1 {
	public static void main(String[] args) {
		BillitemQuantityComparator bq= new BillitemQuantityComparator();
		BillItem b1= new BillItem("pen", 200, 300.00);
		BillItem b2= new BillItem("paper", 20, 500.00);
		
		
		int r= bq.compare(b1, b2);

		if(r<0)
			System.out.println("Billitem1 is less then Billitem2 "+r);
		if(r>0)
			System.out.println("Billitem1 is greater then Billitem2 "+r);
		if(r==0)
			System.out.println("Billitem1 is equal Billitem2 " +r);
	}
	}
