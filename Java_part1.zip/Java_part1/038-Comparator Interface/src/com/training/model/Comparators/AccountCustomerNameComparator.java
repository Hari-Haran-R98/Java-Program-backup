package com.training.model.Comparators;

import java.util.Comparator;

import com.training.model1.Account;

public class AccountCustomerNameComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		Account a1= (Account) o1;
		Account a2= (Account) o2;
		
		int r= a1.getCustomerName().compareTo(a2.getCustomerName());
		
		
		// TODO Auto-generated method stub
		return r;
	}
	

}
