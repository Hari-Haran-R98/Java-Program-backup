
public class SquareClient {
public static void main(String[] args) {
	
}
}
