
public class CircleClient {
public static void main(String[] args) {
	// default constructor 
	Circle c1= new Circle();
	Circle c2= new Circle();
	Circle c3= new Circle();
	Circle c4= new Circle();
	Circle c5= new Circle();
	
	Circle c6= new Circle(10);
	
	
	
}
}
