public class StudentClient {
public static void main(String[] args) {
	
	Student s1= new Student(106, "Hari", 96, 99, "male");
	Student s2= new Student();
	s2.setName("Haran");
	s2.setRollNumber(-3);
	s2.setMark1(95);
	s2.setMark2(98);
	s2.setGender("male");
	
	System.out.println(s2.getName());
	System.out.println(s2.getRollNumber());
	System.out.println(	s2.getMark1());
	System.out.println(	s2.getMark2());
	System.out.println(s2.getGender());
	
	
	System.out.println(s1.getName());
	System.out.println(s1.getRollNumber());
	System.out.println(	s1.getMark1());
	System.out.println(	s1.getMark2());
	System.out.println(s1.getGender());
}
}
