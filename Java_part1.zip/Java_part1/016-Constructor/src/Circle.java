public class Circle {

	private int radius;
	Circle(){
		// constructor method
		System.out.println("Circle Object Created");
	}
	
//	Circle(int radius){
//		this.radius= radius;
//		System.out.println(radius +" Radius value");
//	}
//	
	
	Circle(int radius) {
		this.radius = radius;
	}

	void setRadius(int r) {
		 if(r<0) {
			 System.out.println("Invalid value");
			 return;
		 }
		radius=r;
	}
	
	int getRadius() {
		return radius;
	}
	
	double getArea() {
		return 3.14*radius*radius;
	}
}
