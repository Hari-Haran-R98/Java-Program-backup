public class EmployeeClient {
public static void main(String[] args) {
	Employee emp= new Employee();
	emp.setName("Haran");
	emp.setId(107);
	emp.setBasic(1247890);
	emp.setCityName("Trivandram");
	emp.setGrade('A');

	
	System.out.println(emp.getName());
	System.out.println(emp.getId());
	System.out.println(emp.getBasic());
	System.out.println(emp.getCityName());
	System.out.println(emp.getGrade());

	Employee emp1= new Employee(100000, "CBE", 'A', 106, "Hari");
	
	System.out.println(emp1.getName());
	System.out.println(emp1.getId());
	System.out.println(emp1.getBasic());
	System.out.println(emp1.getCityName());
	System.out.println(emp1.getGrade());


}
}
