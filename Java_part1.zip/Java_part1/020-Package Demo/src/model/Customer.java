package model;

public class Customer {

}
