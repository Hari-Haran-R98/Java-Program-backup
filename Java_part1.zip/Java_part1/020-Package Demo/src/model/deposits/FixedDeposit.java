package model.deposits;

public class FixedDeposit {

}
