package ui;

public class CustomerRegClass {

}
