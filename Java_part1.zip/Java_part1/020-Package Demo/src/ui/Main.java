package ui;
import model.Account;
import model.Customer;
import model.*;
import model.deposits.*;
import db.AccountDAO;
import db.CustomerDAO;
import db.DBConnectionManager;
public class Main {
	public static void main(String[] args) {
		MainScreen ms= new MainScreen();
		
		CustomerRegClass crs= new CustomerRegClass();
		
		Account acc= new Account();
		Customer cs= new Customer();
		FixedDeposit fd= new FixedDeposit();
		
		RecurringDeposit rd= new RecurringDeposit();
		
		AccountDAO ado = new AccountDAO();
		CustomerDAO cdao= new CustomerDAO();
		
		DBConnectionManager dbm= new DBConnectionManager();
		
		
		
		
		
	}

}
