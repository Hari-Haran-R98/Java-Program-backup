import java.util.Scanner;

public class Main5 {
public static void main(String[] args) {
	int[] marks;
	
	int size;
	Scanner sc= new Scanner(System.in);
	size=sc.nextInt();
	marks=new int[size];
	
	for(int element:marks) {
		System.out.println(element);
	}
}
}
