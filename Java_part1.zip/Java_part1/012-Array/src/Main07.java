
public class Main07 {
public static void main(String[] args) {
	int[] array= {14,20,30,10};
	int sum=0;
	for(int e:array) {
		sum+=e;
	}
	System.out.println("Sum of array " + sum);
	float average = sum/array.length;
	System.out.println("Average ="+ average );
	
	
}
}
