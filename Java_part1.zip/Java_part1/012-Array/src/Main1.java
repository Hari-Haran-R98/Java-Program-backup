
public class Main1 {
public static void main(String[] args) {
	int age= 50;
	// 50,60,70
	int years1[];// array  declaration
	
	years1= new int[3];// array creation or initialization
	
	System.out.println(years1.length);
	
	for(int i=0;i<years1.length;i++) {
		System.out.println(years1[i]);
	}

	
}
}


// stack


//heap