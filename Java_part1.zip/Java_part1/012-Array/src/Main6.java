import java.util.Scanner;

public class Main6 {
public static void main(String[] args) {
	long[] profits;
	int size;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the array size");
	size=sc.nextInt();
	profits= new long[size];
	for(int i=0;i<=profits.length-1;i++) {
		System.out.println("Enter the value");
		profits[i]=sc.nextLong();
	}
	System.out.println("  ");

	
	System.out.println("Element in the array");
	for(long element:profits) {
		System.out.println(element);
	}
	
}
}
