
public class Main3 {
public static void main(String[] args) {
	float[] array;
	array= new float[] {5.0f,8.0f,7.0f};
	
	System.out.println(array.length);
	
	for(float element:array) {
		System.out.println(element);
	}
}
}
