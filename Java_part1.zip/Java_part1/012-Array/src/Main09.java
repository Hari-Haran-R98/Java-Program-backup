
public class Main09 {
public static void main(String[] args) {
	int[] array= {14,20,30,10};
	
	for(int i=array.length-1;i>=0;i--) {
		System.out.println(array[i]);
	}
}
}
