import java.util.Arrays;

public class Main11 {
public static void main(String[] args) {
	int[]array=new int[4];
	
	int size=0;
	int[]array1= new int[size];
	
	array[0]=50;
	array[1]=80;
	array[2]=100;
	array[3]=200;
	
	System.out.println(Arrays.toString(array));

	//System.out.println(array[4]);
//out of bound exception
//negaive array exception 
// nullpointer exception
	System.out.println();

	int[] array2= {};//0 size element can be created but not on negative side
	
	array=null;// nullpointer exception
	
	
	
}
}
