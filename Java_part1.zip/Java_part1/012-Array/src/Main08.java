
public class Main08 {
public static void main(String[] args) {
	int[] array= {14,20,30,10};
	
	int max=Integer.MIN_VALUE;
	int min=Integer.MAX_VALUE;
	
	for(int e:array) {
		if(e<min) {
			min = e;
		}
		if(e>max) {
			max=e;
		}
	}
	System.out.println(" min value in array ="+min);
	System.out.println(" min value in array ="+max);
}
}
