package employee;

public class EmpPerfomance {

	int empRating;
	
	public void test1() {
	EmployeeDetails ed= new EmployeeDetails();
	System.out.println(ed.contactNo);
	System.out.println(ed.empId);
	System.out.println(ed.empName);
	System.out.println(ed.currentSalary);
	System.out.println(ed.adress);
	
	}
	public EmpPerfomance() {
		// TODO Auto-generated constructor stub
		System.out.println("Obj created ");
	}
	
}
