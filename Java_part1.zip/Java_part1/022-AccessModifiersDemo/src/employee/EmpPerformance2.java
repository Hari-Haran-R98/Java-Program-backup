package employee;

public class EmpPerformance2 extends EmployeeDetails {
	
	
	protected EmpPerformance2() {
		super();
	}
	public void test3() {
		System.out.println(contactNo);
		System.out.println(empId);
		System.out.println(empName);
		System.out.println(currentSalary);
		System.out.println(adress);

	public void test4() {
		EmployeeDetails ed= new EmployeeDetails();
		System.out.println(ed.contactNo);
		System.out.println(ed.empId);
		System.out.println(ed.empName);
		System.out.println(ed.currentSalary);
		System.out.println(ed.adress);
}
}