package employee;

public class EmployeeDetails {
private int contactNo;
public int empId;
public String empName;
protected double currentSalary;
String adress;

public void test1() {
	System.out.println(contactNo);
	System.out.println(empId);
	System.out.println(empName);
	System.out.println(currentSalary);
	System.out.println(adress);
}
EmployeeDetails(){
	System.out.println("Obj created ");
}
}
