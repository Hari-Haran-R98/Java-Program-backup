package salaryEmp;

import employee.EmployeeDetails;

public class SalaryDetails2 extends EmployeeDetails{
	
	
	
	public SalaryDetails2() {
		System.out.println();
	}

	public void test6() {
		
		System.out.println(contactNo);
		System.out.println(empId);
		System.out.println(empName);
		System.out.println(currentSalary);
		System.out.println(adress);
}
	
	public void test7() {
		EmployeeDetails ed= new EmployeeDetails();
		System.out.println(ed.contactNo);
		System.out.println(ed.empId);
		System.out.println(ed.empName);
		System.out.println(ed.currentSalary);
		System.out.println(ed.adress);

}}
}