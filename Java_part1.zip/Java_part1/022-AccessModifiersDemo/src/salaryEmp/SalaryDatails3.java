package salaryEmp;

public class SalaryDatails3 {

	protected  SalaryDatails3() {
		super();
	}

	
}
