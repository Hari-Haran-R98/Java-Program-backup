package salaryEmp;

import employee.EmployeeDetails;

public class SalaryDetails {

	public void test5() {
		EmployeeDetails ed= new EmployeeDetails();
		System.out.println(ed.contactNo);
		System.out.println(ed.empId);
		System.out.println(ed.empName);
		System.out.println(ed.currentSalary);
		System.out.println(ed.adress);
}
	
	private  SalaryDetails() {
		// TODO Auto-generated constructor stub
		System.out.println("Obj created ");
	}
}
