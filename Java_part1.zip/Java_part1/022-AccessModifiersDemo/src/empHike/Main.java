package empHike;

import employee.EmpPerfomance;
import employee.EmpPerformance2;
import employee.EmployeeDetails;
import salaryEmp.SalaryDetails;

public class Main {
public static void main(String[] args) {
	EmployeeDetails ed= new EmployeeDetails();
	EmpPerfomance ep= new EmpPerfomance();
	EmpPerformance2 ep2= new EmpPerformance();
	SalaryDetails sd = new SalaryDetails();
}
}
