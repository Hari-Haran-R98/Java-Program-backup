
public class Employee {

	int empId; // Instance variable default value is there 
	String name; //Instance variable default value is there
	
	static int count; // Global variable 
	
	void calculateAllowance() {
		double allowance // local variable value not initalized no default value is there
		System.out.println(allowance);// cause error
		System.out.println(empId);
		
	}
	
	void calculateTax() {
		double tax=0;// local variable value initalized not initalized no default value is there
		System.out.println(tax);
		System.out.println(empId);
	}
	void calculateIncentive(int extraHrs) {// perameter variable scope limited to the function 
		System.out.println(extraHrs);
		
	}
	void test() {
		int x=90;
		if(x>50) {
			System.out.println("Qualified");
			int y=100; // local variable scope only inside the if block
		}
		else {
			System.out.println(y); // cause error
		}
	}
}
