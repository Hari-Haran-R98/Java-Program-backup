package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Employee;

@RestController
public class EmployeeController {

	
	@GetMapping("/empList")
	public ResponseEntity<List> f1(){
		
		List<Employee> emp= new LinkedList<>();
		
		Employee e1= new Employee(101, "Hari", 60000);
		Employee e2= new Employee(102, "Haran", 65000);
		Employee e3= new Employee(103, "Harish", 62000);
		Employee e4= new Employee(104, "Haarish", 57000);
		
		emp.add(e1);
		emp.add(e2);
		emp.add(e3);
		emp.add(e4);
		
		
		return ResponseEntity.ok(emp); 
	}
}
