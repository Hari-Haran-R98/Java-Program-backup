use trainingdb7;

create table employees(

id      integer,
name    varchar(50),
salary   double);

describe employees; 

drop table employees;

insert into employees(id,name,salary) values(101,"Hariharan",15000.00);
insert into employees(id,name,salary) values(102,"Nisha",12000.00);
insert into employees(id,name,salary) values(103,"Pooja",12500.00);
insert into employees(id,name,salary) values(104,"Priya",13400.00);
insert into employees(id,name,salary) values(105,"Ramiya",11400.00);
insert into employees(id,name) values(101,"Nirmal");


select * from employees;

select id as "empid", name as "FirstName", salary+100 as "Incremented Salary" from employees;

select * from employees where salary>12000;

select * from employees where name ="Pooja";


select * from employees where salary>13000 and salary<15000;



update employees set name='hari' where id=102;

select * from employees;

update employees set salary=12500 where id=102;
select * from employees;

update employees set name='rahul' , salary=13550 where id=102;

delete from employees where id=106;

delete from employees where salary=null;

