package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.training.model.Employee;
	
@Controller
public class EmployeeController {

	@RequestMapping("/empl")
	public ModelAndView f1() {
		ModelAndView mav=new ModelAndView("empOutput");
		Employee employee=new Employee(101, "Kiran", "Male", "Coimbatore", 120000);
		mav.addObject("empl", employee);
		return mav;
	}
	@RequestMapping("/input")
	public ModelAndView f2() {
		ModelAndView mav=new ModelAndView("empInput");
		Employee employee=new Employee();
		mav.addObject("emp", employee);
		return mav;
	}
	@RequestMapping("/output")
	public String f3(@ModelAttribute(value="emp") @Valid Employee employee, BindingResult result, Map<String, Object> modelmap) {
		if(result.hasErrors()) {
			System.out.println(result.hasErrors());
			return "empInput";
		}
		else {
			modelmap.put("emp", employee);
			return "empOutput";
		}	
}
	@RequestMapping("/allemployess")
	public ModelAndView f4() {
		ModelAndView mav=new ModelAndView("empList");
		Employee employee2= new Employee(102, "Haran", "Male", "Coimbatore", 200000);
		Employee employee3= new Employee(103, "Hari", "Male", "Banglore", 200000);
		Employee employee4= new Employee(104, "Kumar", "Male", "Coimbatore", 200000);
		Employee employee5= new Employee(105, "Gowshi", "Female", "Chennai", 200000);
		Employee employee6= new Employee(106, "Pavi", "Female", "Trivandra,", 200000);
		
		List<Employee> employees= new LinkedList<>();
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		employees.add(employee5);
		employees.add(employee6);
		mav.addObject("emps", employees);
		return mav;	
}

}
