package com.training.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args)throws IOException {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		int fendCount;
		int bendCount;
		fendCount = Integer.parseInt(br.readLine());
		bendCount = Integer.parseInt(br.readLine());
		
		int[] fendCostArray= new int[fendCount];
		String[] arr1=br.readLine().trim().split("");
		
		for(int i=0;i<arr1.length;i++) {
			fendCostArray[i]=Integer.parseInt(arr1[i]);
		}
		int[]bendCostArray= new int[bendCount];
		String[]arr2=br.readLine().trim().split("");
		
		for(int i=0;i<arr2.length;i++) {
			bendCostArray[i]=Integer.parseInt(arr2[i]);
		}
		System.out.println(Arrays.toString(fendCostArray));
		System.out.println(Arrays.toString(bendCostArray));
		
		List<Integer> list1= new LinkedList<>();
		for(int i=0;i<arr1.length;i++) {
			list1.add(Integer.parseInt(arr1[i]));
		}
		System.out.println(list1);
		
		List<Integer> list2= new LinkedList<>();
		for(int i=0;i<arr2.length;i++) {
			list2.add(Integer.parseInt(arr2[i]));
		}
		System.out.println(list2);
		
		int totalCost=0;
		int numberHired=0;
		for(int i=0;i<fendCount;i++) {
			Integer findmin=0;
			
			if(list1.size()>0) {
				findmin=Collections.min(list1);
				totalCost+=findmin;
				numberHired++;
				System.out.println("Front End Select "+findmin);
				System.out.println("Hired "+numberHired);
				
				int position=list1.indexOf(findmin);
				list1.remove(Integer.valueOf(findmin));
				list1.remove(position);
			}
		}
		for(int i=0;i<bendCount;i++) {
			Integer bindmin=0;
			
			if(list1.size()>0) {
				bindmin=Collections.min(list1);
				totalCost+=bindmin;
				numberHired++;
				System.out.println("Front End Select "+bindmin);
				System.out.println("Hired "+numberHired);
				
				int position=list2.indexOf(bindmin);
				list2.remove(Integer.valueOf(bindmin));
				list2.remove(position);
			}
	}
		System.out.println(numberHired);
		System.out.println(totalCost);
}
}