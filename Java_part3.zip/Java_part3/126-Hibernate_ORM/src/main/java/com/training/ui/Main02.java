package com.training.ui;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.training.model.Product;

public class Main02 {

	private static void insert() {
		Product product= new Product(103, "Pencil Box", 150.00, "study");
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		
		session.getTransaction().begin();
		session.persist(product);
		session.getTransaction().commit();
		session.close(); 
		sessionFactory.close();
	
	}
	private static void read() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		Product product;
		product=session.find(Product.class, 102);
		
		System.out.println(product);
		session.close();
		sessionFactory.close();
	
	}
	private static void update() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		Product product=session.find(Product.class, "102");
		product.setName(product.getName().toUpperCase());
		session.getTransaction().begin();
		session.merge(product);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();}
	
	private static void delete() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		Product product;
		product=session.find(Product.class, 102);
		session.getTransaction().begin();
		session.remove(product);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();}
	
	
	private static void readAll() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		
	
		String str="from Product";    //HQL
		Query<Product> qry=session.createQuery(str,Product.class);
		List<Product> productList=qry.getResultList();
		System.out.println(productList);
		session.close();
		sessionFactory.close();}
	
	
	public static void main(String[] args) {
		
		//insert();
		//read();
//		update();
	readAll();
		//delete();
	}
}
