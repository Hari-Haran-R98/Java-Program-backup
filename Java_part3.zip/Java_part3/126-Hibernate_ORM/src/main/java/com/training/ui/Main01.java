package com.training.ui;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.training.model.Contact;

public class Main01 {

	private static void insert() {
		Contact contact= new Contact(103, "Muruga", "Muruga@gmail.com", "3463849873"); 
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		
		session.getTransaction().begin();
		session.persist(contact);
		session.getTransaction().commit();
		session.close(); 
		sessionFactory.close();
	
	}
	private static void read() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		Contact contact;
		contact=session.find(Contact.class, 103);
		
		System.out.println(contact);
		session.close();
		sessionFactory.close();
	
	}
	private static void update() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		Contact contact=session.find(Contact.class, "103");
		contact.setName(contact.getName().toUpperCase());
		session.getTransaction().begin();
		session.merge(contact);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();}
	
	private static void delete() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
	
		Session session=sessionFactory.openSession();     
		Contact contact;
		contact=session.find(Contact.class, 102);
		session.getTransaction().begin();
		session.remove(contact);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();}
	
	
	private static void readAll() {
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		
	
		String str="from Contact";    //HQL
		Query<Contact> qry=session.createQuery(str,Contact.class);
		List<Contact> contactList=qry.getResultList();
		System.out.println(contactList);
		session.close();
		sessionFactory.close();}
	
	public static void main(String[] args) {
		//insert();
		// read();
		//update();
		readAll();
		//delete();
	}
}
