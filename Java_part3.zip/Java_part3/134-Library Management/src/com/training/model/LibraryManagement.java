package com.training.model;

import java.util.LinkedList;
import java.util.List;

public class LibraryManagement {
List<Book> allBooks;

public LibraryManagement() {
	super();
	this.allBooks= new LinkedList<>();
	Book book1= new Book("HarryPotter1", "Jk Rowling", 500, false);
	Book book2= new Book("HarryPotter2", "Jk Rowling", 500, false);
	Book book3= new Book("HarryPotter3", "Jk Rowling", 500, false);
	Book book4= new Book("HarryPotter4", "Jk Rowling", 500, false);
	Book book5= new Book("HarryPotter5", "Jk Rowling", 500, false);
	Book book6= new Book("HarryPotter6", "Jk Rowling", 500, false);
	Book book7= new Book("HarryPotter7", "Jk Rowling", 500, false);
	Book book8= new Book("HarryPotter7-1", "Jk Rowling", 500, false);
	Book book9= new Book("HarryPotter7-2", "Jk Rowling", 500, false);
	Book book10= new Book("HarryPotter7-3", "Jk Rowling", 500, false);
	
	allBooks.add(book1);
	allBooks.add(book2);
	allBooks.add(book3);
	allBooks.add(book4);
	allBooks.add(book5);
	allBooks.add(book6);
	allBooks.add(book7);
	allBooks.add(book8);
	allBooks.add(book9);
	allBooks.add(book10);
	
}

public void issueBook(String bookName) {
	for (Book book : allBooks) {
		if(book.getBookName()==bookName) {
			book.setIssueStatus(true);
			System.out.println(book);
		}
	}
	
}
public void printAvailableBooks() {
	for (Book book : allBooks) {
		if(!book.issueStatus) 
			System.out.println(book);
		}}
public int getAvailableBooksCount() {
	
		int available=(int) allBooks.stream().filter(c->c.issueStatus==false).count();
	return available;
}

public int getIssuedBookCount() {
	int issued=(int) allBooks.stream().filter(c->c.issueStatus==true).count();
return issued;


}
}
