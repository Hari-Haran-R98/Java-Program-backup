package com.training.ui;

import com.training.model.LibraryManagement;

public class Main {

	public static void main(String[] args) {
		LibraryManagement management= new LibraryManagement();
		
		management.printAvailableBooks();
		System.out.println();
		System.out.println("==========================");
		System.out.println();
		management.issueBook("HarryPotter6");
		System.out.println();
		System.out.println("==========================");
		System.out.println();
		int available =management.getAvailableBooksCount();
		System.out.println(available);
		System.out.println();
		System.out.println("==========================");
		System.out.println();
		management.issueBook("HarryPotter5");
		System.out.println();
		System.out.println("==========================");
		int issued= management.getIssuedBookCount();
		System.out.println(issued);
		System.out.println();
		System.out.println("==========================");
		System.out.println();
		management.issueBook("HarryPotter4");
		System.out.println();
		System.out.println("==========================");
		System.out.println();
		int available1 =management.getAvailableBooksCount();
		System.out.println(available1);
		System.out.println();	
	}
}
