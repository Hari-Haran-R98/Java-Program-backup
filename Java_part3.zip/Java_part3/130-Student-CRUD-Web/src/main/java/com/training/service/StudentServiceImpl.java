package com.training.service;

import java.sql.Connection;

import java.util.LinkedList;
import java.util.List;

import com.training.db.ConnectionManager;
import com.training.db.StudentDAOMysqlImpl;
import com.training.db.StudentMysqlDAO;
import com.training.model.Student;

public class StudentServiceImpl implements StudentService {

	private List<Student> allStudents;

	public StudentServiceImpl() {
		this.allStudents = new LinkedList<>();
	}

	static StudentServiceImpl instance = null;

	public static StudentService getInstance() {
		if (instance == null)
			instance = new StudentServiceImpl();
		return instance;
	}

	@Override
	public boolean addStudent(Student student) {
		Connection connection= ConnectionManager.createConnection();
		StudentMysqlDAO dao= new StudentDAOMysqlImpl();
		boolean status = dao.insertStudent(connection, student);
		ConnectionManager.closeConnection(connection);
		
		return status;
	}

	@Override
	public Student searchStudent(int rollNumber){
		Student student = new Student();
		Connection connection= ConnectionManager.createConnection();
		StudentMysqlDAO dao= new StudentDAOMysqlImpl();
		student=dao.findStudentByRollNumber(connection, rollNumber);
		ConnectionManager.closeConnection(connection);
	return student;
	}

	public boolean isPresent(Student student) {
		boolean result=false;
		for(Student student2:allStudents) {
			if(result=student2.getRollNumber()==student.getRollNumber())
				result= true;
		}
		return result;
	}
	@Override
	public boolean updateStudent(Student student) {
		boolean status=false;
		Connection connection= ConnectionManager.createConnection();
		StudentMysqlDAO dao= new StudentDAOMysqlImpl();
		status = dao.updateStudent(connection, student);
		ConnectionManager.closeConnection(connection);
		return status;
	}

	@Override
	public List<Student> getAllStudents() {
		Connection connection= ConnectionManager.createConnection();
		StudentMysqlDAO dao= new StudentDAOMysqlImpl();
		List<Student> status= dao.findAllStudents(connection);
		return status;
	}

	@Override
	public boolean deleteStudent(int rollNumber){
		Student student = new Student();
		student.setRollNumber(rollNumber);
		Connection connection= ConnectionManager.createConnection();
		StudentMysqlDAO dao= new StudentDAOMysqlImpl();
		boolean status=dao.deleteStudent(connection, student);
		ConnectionManager.closeConnection(connection);
	return status;

	}
	

}
