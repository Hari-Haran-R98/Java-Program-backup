package com.training.ui;

import java.time.LocalDate;
import java.util.List;

import com.training.model.Bill;
import com.training.model.ContactInfo;
import com.training.model.Course;
import com.training.model.Person;
import com.training.model.Subject;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main10 {

	private static void insert() {
		Course course= new Course("Diploma Web Technologies",40000.00 , null);
		Subject subject= new Subject("Java", 40);
		Subject subject1= new Subject("Html", 25);
		Subject subject2= new Subject("CSS", 27);
		Subject subject3= new Subject("C++", 30);
		Subject subject4= new Subject("Python", 20);
		
		course.addSubject(subject);
		course.addSubject(subject1);
		course.addSubject(subject2);
		course.addSubject(subject3);
		course.addSubject(subject4);
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		  EntityManager em= emf.createEntityManager();
		  em.getTransaction().begin();
			em.persist(course);
			em.getTransaction().commit();
			
			em.close();
			emf.close();

	}
	
	private static void read() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Course course= em.find(Course.class, 1);
		
		System.out.println(course);
		em.close();
		emf.close();
		
	}
	
	public static void main(String[] args) {
		//insert();
		read();
	}
}
