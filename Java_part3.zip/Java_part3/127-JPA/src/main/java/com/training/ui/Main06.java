package com.training.ui;

import java.util.List;

import com.training.model.Book;
import com.training.model.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main06 {

	private static void insert() {
	  Book book= new Book("SCJP", "Kathy Sierra");
	  book.addTopic("Java Introduction");
	  book.addTopic("OOps Introduction");
	  book.addTopic("Multi Threading");
	  book.addTopic("Collection API");
	  
	  EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
	  EntityManager em= emf.createEntityManager();
	  em.getTransaction().begin();
		em.persist(book);
		em.getTransaction().commit();
		
		em.close();
		emf.close();

	  
	}
	
	private static void read() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Employee employee=em.find(Employee.class, 2);
		System.out.println(employee);
		em.close();
		emf.close();
	}
	private static void update() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
	
		Book book = em.find(Book.class, 4);
		book.addTopic("Stream Api");
		em.getTransaction().begin();
		em.merge(book);
		em.getTransaction().commit();
		em.close();
		em.close();
	}
	private static void readAll() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String qry="from Book";
		Query qurey=em.createQuery(qry);
		List<Book> book=qurey.getResultList();
		System.out.println(book);
		em.close();
		emf.close();
		
	}
	
	private static void delete() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		Book book = em.find(Book.class, 1);
		em.getTransaction().begin();
		em.remove(book);
		em.getTransaction().commit();
		em.close();
		em.close();
	}
	
	public static void main(String[] args) {
		//insert();
		update();
		//readAll();
		//delete();
		readAll();
	}
}
