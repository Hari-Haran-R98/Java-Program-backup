package com.training.ui;

import java.util.List;

import com.training.model.Player;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main02 {

	private static void insert() {
		Player player = new Player(104, "Kholi", "Batsman", 25, 18);
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(player);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
		
		private static void read() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			
			Player player=em.find(Player.class, 103);
			System.out.println(player);
			em.close();
			emf.close();
		}
		private static void update() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			
			Player player=em.find(Player.class, 102);
			player.setTypeOfPlayer("Bowler");
			em.getTransaction().begin();
			em.merge(player);
			em.getTransaction().commit();
			em.close();
			em.close();
		}
		private static void readAll() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			
			String qry="from Player";
			Query qurey=em.createQuery(qry);
			List<Player> players=qurey.getResultList();
			System.out.println(players);
			em.close();
			emf.close();
		}
		
		private static void delete() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			
			Player player=em.find(Player.class, 104);
			em.getTransaction().begin();
			em.remove(player);
			em.getTransaction().commit();
			em.close();
			em.close();
		}

		
		public static void main(String[] args) {
			//insert();
			//read();
			readAll();
		     //update();
			//delete();
			
				}

}
