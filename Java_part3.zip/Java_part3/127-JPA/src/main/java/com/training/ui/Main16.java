package com.training.ui;

import java.util.List;

import com.training.model.Doctor;
import com.training.model.Loan;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main16 {
	private static void test1() {
		EntityManagerFactory emf= Persistence
	.createEntityManagerFactory("PU");
		EntityManager em= emf.createEntityManager();
		
		Query query= em.createNamedQuery("findAllLoans");
		List<Loan> allLoans= query.getResultList();
		System.out.println(allLoans);
		
		em.close();
		emf.close();
	}

	private static void test2() {
		EntityManagerFactory emf= Persistence
	.createEntityManagerFactory("PU");
		EntityManager em= emf.createEntityManager();
		
		
		
		Query query= em.createNamedQuery("findByLoanId");
		query.setParameter("searchId", 3);
		Loan loans= (Loan) query.getSingleResult();
		System.out.println(loans);
		
		em.close();
		emf.close();
	}
	
	private static void test3() {
		EntityManagerFactory emf= Persistence
	.createEntityManagerFactory("PU");
		EntityManager em= emf.createEntityManager();
		
		Query query= em.createNamedQuery("updateLoanAmount");
		em.getTransaction().begin();
		int r= query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(r+ "records Updated");
		
		em.close();
		emf.close();
	}
	
	private static void test4() {
		EntityManagerFactory emf= Persistence
	.createEntityManagerFactory("PU");
		EntityManager em= emf.createEntityManager();
		
		
		
		Query query= em.createNamedQuery("deleteAboveLoan");
		query.setParameter("tenureCutOff", 8);
		em.getTransaction().begin();
		int r= query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(r+ "records deleted");
		
		em.close();
		emf.close();

	}
	public static void main(String[] args) {
		
		//test1();
		test2();
		//test3();
	//test4();
	}

}
