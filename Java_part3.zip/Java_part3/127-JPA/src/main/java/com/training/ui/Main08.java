package com.training.ui;

import java.time.LocalDate;
import java.util.List;

import com.training.model.Bill;
import com.training.model.Billitem;
import com.training.model.Category;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
public class Main08 {

	
	static Billitem billitem1= new Billitem(1,"DELL", 2, 80000.00);
	static Billitem billitem2= new Billitem(2,"Iphone", 2, 70000.00);
	static Billitem billitem3= new Billitem(3, "Logitech Mouse", 2, 400.00);
	static Billitem billitem4= new Billitem(4, "Samsung", 1, 140000.00);
	static Billitem billitem5= new Billitem(5, "Nokia", 2, 60000.00);
	
	
	private static void insert() {
		Bill bill= new Bill("haran", LocalDate.of(2024, 12, 10));
		bill.addBillitem(billitem1);
		bill.addBillitem(billitem2);
		bill.addBillitem(billitem3);
		bill.addBillitem(billitem4);
		bill.addBillitem(billitem5);
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		  EntityManager em= emf.createEntityManager();
		  em.getTransaction().begin();
			em.persist(bill);
			em.getTransaction().commit();
			
			em.close();
			emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
	
		Bill bill = em.find(Bill.class, 1);
		bill.removeBillitem(billitem5);
		bill.addBillitem(new Billitem(1, "Nokia", 3, 90000.00));
		em.getTransaction().begin();
		em.merge(bill);
		em.getTransaction().commit();
		em.close();
		em.close();
	}
	
	private static void read() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Bill bill=em.find(Bill.class, 1);
		System.out.println(bill);
		em.close();
		emf.close();
	}
	private static void readAll() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String qry="from Bill";
		Query qurey=em.createQuery(qry);
		List<Bill> categories=qurey.getResultList();
		System.out.println(categories);
		em.close();
		emf.close();
		
	}
	
	private static void delete() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		Bill bill = em.find(Bill.class, 3);
		em.getTransaction().begin();
		em.remove(bill);
		em.getTransaction().commit();
		em.close();
		em.close();
	}

	
	public static void main(String[] args) {
		//insert();
		//update();
		readAll();
		//delete();
	}
}
