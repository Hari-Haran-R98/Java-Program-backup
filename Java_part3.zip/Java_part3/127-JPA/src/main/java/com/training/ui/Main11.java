package com.training.ui;

import java.time.LocalDate;

import com.training.model.Doctor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main11 {

	public static void main(String[] args) {
		Doctor doctor= new Doctor("HariHaran", 500, "Male", LocalDate.of(2006, 12, 15));
		Doctor doctor1= new Doctor("Hari", 2500, "Male", LocalDate.of(2004, 2, 25));
		Doctor doctor2= new Doctor("Kumar", 1500, "Male", LocalDate.of(2003, 4, 16));
		Doctor doctor3= new Doctor("Ajith", 4500, "Male", LocalDate.of(2008, 7, 18));
		Doctor doctor4= new Doctor("Shalani", 2500, "Female", LocalDate.of(2012, 9, 12));
		Doctor doctor5= new Doctor("Pooja", 2500, "Female", LocalDate.of(2010, 11, 17));

		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		
		em.persist(doctor1);
		em.persist(doctor2);
		em.persist(doctor3);
		em.persist(doctor4);
		em.persist(doctor5);
		
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
	}
}
