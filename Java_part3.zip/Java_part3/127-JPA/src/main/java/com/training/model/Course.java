package com.training.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="courses")
public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	
	@Column
	String courseName;
	
	@Column
	double fees;
	
	@OneToMany(cascade = CascadeType.ALL)
	Set<Subject> subject;
	
	public Course(String courseName, double fees, Set<Subject> subject) {
		super();
		this.courseName = courseName;
		this.fees = fees;
		this.subject = new HashSet<>();
	}

	public Course() {
		super();
		this.subject = new HashSet<>();
	}

	@Override
	public String toString() {
		return "\nCourse [id=" + id + ", courseName=" + courseName + ", fees=" + fees + ", subject=" + subject + "]";
	}
	
	

	public int getId() {
		return id;
	}

	public String getCourseName() {
		return courseName;
	}

	public double getFees() {
		return fees;
	}

	public Set<Subject> getSubject() {
		return subject;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public void setSubject(Set<Subject> subject) {
		this.subject = subject;
	}

	public void addSubject(Subject subject) {
		this.subject.add(subject);	}

	public void removeSubject(Subject subject) {
		this.subject.remove(subject);
}
	

}
