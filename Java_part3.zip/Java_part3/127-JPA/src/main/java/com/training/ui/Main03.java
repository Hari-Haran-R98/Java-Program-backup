package com.training.ui;

import java.util.List;

import com.training.model.Candidate;
import com.training.model.Player;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main03 {
	private static void insert() {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Candidate candidate= new Candidate("Haran", "Delhi", new double[] {70.0,60.0,50.0});
		
		
		em.getTransaction().begin();
		em.persist(candidate);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
		
		private static void read() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			
			Candidate candidate=em.find(Candidate.class, 1);
			System.out.println(candidate);
			em.close();
			emf.close();
		}
		private static void update() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			
			Candidate candidate= em.find(Candidate.class, 2);
			candidate.setCity("Banglore");
			candidate.getMarks()[0]=25.0;
			em.getTransaction().begin();
			em.merge(candidate);
			em.getTransaction().commit();
			em.close();
			em.close();
		}
		private static void readAll() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			
			String qry="from Candidate";
			Query qurey=em.createQuery(qry);
			List<Candidate> candidate=qurey.getResultList();
			System.out.println(candidate);
			em.close();
			emf.close();
			
		}
		
		private static void delete() {
			EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
			EntityManager em=emf.createEntityManager();
			Candidate candidate= em.find(Candidate.class, 3);
			em.getTransaction().begin();
			em.remove(candidate);
			em.getTransaction().commit();
			em.close();
			em.close();
		}

		
		public static void main(String[] args) {
			insert();
			//read();
			//readAll();
		     //update();
			//delete();
			
				}

	
}
