package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Embeddable
public class Billitem {
	@Column
	int slno;
	@Column
	String iteamName;
	@Column
	int quantity;
	@Column
	double price;

	public Billitem(int slno, String iteamName, int quantity, double price) {
		super();
		this.slno=slno;
		this.iteamName = iteamName;
		this.quantity = quantity;
		this.price = price;
	}

	public Billitem() {
		super();
	}

	@Override
	public String toString() {
		return "\nslno=" + slno + ", iteamName=" + iteamName + ", quantity=" + quantity + ", price=" + price;}

	public int getSlno() {
		return slno;
	}

	public String getIteamName() {
		return iteamName;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setSlno(int slno) {
		this.slno = slno;
	}

	public void setIteamName(String iteamName) {
		this.iteamName = iteamName;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
}
