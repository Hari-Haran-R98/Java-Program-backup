package com.training.ui;

import java.util.List;
import com.training.model.Loan;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main15 {
	
	private static void insert() {
		Loan loan1= new Loan("Kumar", 10000.00, 8);
		Loan loan2= new Loan("Deepan", 30000.00, 5);
		Loan loan3= new Loan("Jackup", 50000.00, 9);
		Loan loan4= new Loan("Steve", 13000.00, 12);
		Loan loan5= new Loan("Kiruba", 15000.00, 24);
		Loan loan6= new Loan("Jack", 20000.00, 30);
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("PU");
		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		
		em.persist(loan1);
		em.persist(loan2);
		em.persist(loan3);
		em.persist(loan4);
		em.persist(loan5);
		em.persist(loan6);
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	
	}
	
	private static void test1() {
		EntityManagerFactory emf= Persistence
				.createEntityManagerFactory("PU");
					EntityManager em= emf.createEntityManager();
					
					String nsql="select * from loans";
					Query query=em.createNativeQuery(nsql, Loan.class);
					
					List<Loan> results=query.getResultList();
					
					System.out.println(results);

					em.close();
					emf.close();
					
	}

	private static void test2() {
		EntityManagerFactory emf= Persistence
				.createEntityManagerFactory("PU");
					EntityManager em= emf.createEntityManager();
					
					String nsql="select * from loans where id=3";
					Query query=em.createNativeQuery(nsql, Loan.class);
					
					List<Loan> results=query.getResultList();
					
					System.out.println(results);

					em.close();
					emf.close();
					
	}

	private static void test3() {
		EntityManagerFactory emf= Persistence
				.createEntityManagerFactory("PU");
					EntityManager em= emf.createEntityManager();
					
					String nsql="select * from loans where tenure<20";
					Query query=em.createNativeQuery(nsql, Loan.class);
					
					List<Loan> results=query.getResultList();
					
					System.out.println(results);

					em.close();
					emf.close();
					
	}
	private static void test4() {
		EntityManagerFactory emf= Persistence
				.createEntityManagerFactory("PU");
					EntityManager em= emf.createEntityManager();
					
					String nsql="delete from loans where tenure<6";
					Query query=em.createNativeQuery(nsql, Loan.class);
					
					List<Loan> results=query.getResultList();
					
					System.out.println(results);

					em.close();
					emf.close();
					
	}

	
	public static void main(String[] args) {
		//insert();
		test4();
	}
}
