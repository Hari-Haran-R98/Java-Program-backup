package com.training.model;

import java.util.LinkedList;
import java.util.List;

public class CommonData {
	
	

	public static List<Movie>movies= new LinkedList<>();
	public static List<Person>persons= new LinkedList<>();
	public static List<Booking>bookings= new LinkedList<>();

	
	public static void init() {
	Movie movie1= new Movie(101, "Marco"); 
	Movie movie2= new Movie(102, "96"); 
	Movie movie3= new Movie(103, "Leo"); 
	Movie movie4= new Movie(104, "Veeram"); 
	Movie movie5= new Movie(105, "Jai hind"); 
	Movie movie6= new Movie(106, "Karnan"); 
	
	Person person1 = new Person(1, "Hari","Male", 23);
	Person person2 = new Person(1, "Haran","Male", 23);
	Person person3 = new Person(1, "Krishna","Male", 23);
	Person person4 = new Person(1, "Muruga","Male", 23);
	Person person5 = new Person(1, "Kumara","Male", 23);
	
	movies.add(movie1);
	movies.add(movie2);
	movies.add(movie3);
	movies.add(movie4);
	movies.add(movie5);
	movies.add(movie6);
	
	persons.add(person1);
	persons.add(person2);
	persons.add(person3);
	persons.add(person4);
	persons.add(person5);
	
	
	}
}
