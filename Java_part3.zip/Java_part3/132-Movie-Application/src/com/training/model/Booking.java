package com.training.model;

import java.time.LocalDate;

public class Booking {

	int bookingId;
	Movie movie;
	Person person;
	LocalDate showDate;
	boolean cancleBooking;
	
	public Booking(int bookingId, Movie movie, Person person, LocalDate showDate, boolean cancleBooking) {
		super();
		this.bookingId = bookingId;
		this.movie = movie;
		this.person = person;
		this.showDate = showDate;
		this.cancleBooking = cancleBooking;
	}



	public Booking() {
		super();
	}













	public boolean isCancleBooking() {
		return cancleBooking;
	}



	public void setCancleBooking(boolean cancleBooking) {
		this.cancleBooking = cancleBooking;
	}



	public int getBookingId() {
		return bookingId;
	}



	public Movie getMovie() {
		return movie;
	}



	public Person getPerson() {
		return person;
	}



	public LocalDate getShowDate() {
		return showDate;
	}



	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}



	public void setMovie(Movie movie) {
		this.movie = movie;
	}



	public void setPerson(Person person) {
		this.person = person;
	}



	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}



	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", movie=" + movie + ", person=" + person + ", showDate=" + showDate
				+ ", cancleBooking=" + cancleBooking + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bookingId;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Booking))
			return false;
		Booking other = (Booking) obj;
		if (bookingId != other.bookingId)
			return false;
		return true;
	}
	
}
