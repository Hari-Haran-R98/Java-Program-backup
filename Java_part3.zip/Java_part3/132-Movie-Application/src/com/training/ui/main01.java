package com.training.ui;

import java.time.LocalDate;
import java.util.List;

import com.training.model.CommonData;
import com.training.model.*;

public class main01 {

	static List<Movie> movies= CommonData.movies;
	static List<Person> persons= CommonData.persons;
	
	public static void main(String[] args) {
	
		CommonData.init();
		bookTicket(4, 2);
		bookTicket(1, 3);
		bookTicket(3, 4);
		bookTicket(1, 4);
		bookTicket(4, 1);
		printBookig();
		
	}
	
	private static void bookTicket(int movieIndex, int personIndex) {
		Booking booking= new Booking(1001, movies.get(movieIndex), persons.get(personIndex),
				LocalDate.of(2025, 05, 01), false);
		
		CommonData.bookings.add(booking);
		movies.get(movieIndex).addBooking(booking);
	}
	private static void cancleTicket(int movieIndex, int personIndex) {
		Movie movie= movies.get(movieIndex);
		Person person= persons.get(personIndex);
		
		
		
		CommonData.bookings.add(booking);
		movies.get(movieIndex).addBooking(booking);
	}
	
	private static void printBookig() {
		for(Movie movie: movies) {
			System.out.println(movie.getName());
			for(Booking booking : movie.getAllBookings()) {
				System.out.println("\t\t"+booking.getPerson().getName());
			}
		}
	}
}
