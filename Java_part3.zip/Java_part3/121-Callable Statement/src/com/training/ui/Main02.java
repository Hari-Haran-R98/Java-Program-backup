package com.training.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main02 {
	
	public static void main(String[] args) {

	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver Loaded Successfull");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		System.err.println(e1);
	}
	
	Connection connection= null;
	String dburl= "jdbc:mysql://localhost:3306/trainingdb7?useSSL=false";
	String userName="root";
	String pasword="root";
	
	try {
		connection= DriverManager.getConnection(dburl, userName, pasword);
		System.out.println("Connected to Database");
	} catch (SQLException e) {
	System.err.println(e);
	}
	/// step 3
	
CallableStatement statement;
try {
	statement = connection.prepareCall("{call incrementSalary(?,?,?)}");
	statement.setString(1, "India");
	statement.setInt(2, 5);
	statement.registerOutParameter(3, java.sql.Types.DOUBLE);
	statement.execute();
	System.out.println(statement.getInt(3));
	
} catch (SQLException e) {
	// TODO Auto-generated catch block
	System.err.println(e);
}	
		
	try {
		connection.close();
		System.out.println("Connect close successfully");
	}catch (SQLException e2) {
		System.err.println(e2);

	}
}}
