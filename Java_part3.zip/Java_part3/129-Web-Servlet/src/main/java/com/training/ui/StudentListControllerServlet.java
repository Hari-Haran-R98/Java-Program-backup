package com.training.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.training.model.Student;

//@WebServlet(name = "StudentListController", urlPatterns = { "/SLCS" })
public class StudentListControllerServlet extends HttpServlet {
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
Student student1= new Student(101, "Muruga", "Male", 100, 100);
Student student2= new Student(102, "Hariharan", "Male", 90, 85);
Student student3= new Student(103, "Hari", "Male", 83, 97);
Student student4= new Student(104, "Haran", "Male", 93, 96);
Student student5= new Student(105, "Pooja", "Female", 87, 93);
Student student6= new Student(106, "Anjana", "Female", 89, 91);

List<Student> students= new ArrayList<>();

students.add(student1);
students.add(student2);
students.add(student3);
students.add(student4);
students.add(student5);
students.add(student6);

request.setAttribute("studs", students);
RequestDispatcher dispatcher= request.getRequestDispatcher("StudentList.jsp");
dispatcher.forward(request, response);
		}

}
