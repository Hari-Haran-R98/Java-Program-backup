package com.training.ui;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.training.model.Employee;

/**
 * Servlet implementation class EmployeeControllServlet
 */
@WebServlet("/ECS")
public class EmployeeControllServlet extends HttpServlet {
		
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

String str_id=request.getParameter("txt_id");
String str_name=request.getParameter("txt_name");
String str_gender=request.getParameter("rad_gender");
String str_basicSalary=request.getParameter("txt_basic");


int rollNumber=Integer.parseInt(str_id);
String name=str_name;
String gender=str_gender;
double basicSalary=Double.parseDouble(str_basicSalary);

Employee employee = new Employee(rollNumber, name, gender, basicSalary);
request.setAttribute("emp", employee);
RequestDispatcher dispatcher = request.getRequestDispatcher("EmployeeOutput.jsp");
dispatcher.forward(request, response);

	}

}
