package com.training.model;

import java.time.LocalDate;

public class LeaveApplication {

	int empId;
	
	int managerId;
	
	LocalDate fromDate;
	
	LocalDate toDate;
	
	String reason;
	
	String approvedOrRejected;

	public LeaveApplication(int empId, int managerId, LocalDate fromDate, LocalDate toDate, String reason) {
		super();
		this.empId = empId;
		this.managerId = managerId;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.reason = reason;
	}

	
	
	public LeaveApplication(String approvedOrRejected) {
		super();
		this.approvedOrRejected = approvedOrRejected;
	}



	public LeaveApplication() {
		super();
	}

	public int getEmpId() {
		return empId;
	}

	public int getManagerId() {
		return managerId;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public String getReason() {
		return reason;
	}

	public String getApprovedOrRejected() {
		return approvedOrRejected;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public void setApprovedOrRejected(String approvedOrRejected) {
		this.approvedOrRejected = approvedOrRejected;
	}

	@Override
	public String toString() {
		return "LeaveApplication [empId=" + empId + ", managerId=" + managerId + ", fromDate=" + fromDate + ", toDate="
				+ toDate + ", reason=" + reason + ", approvedOrRejected=" + approvedOrRejected + "]";
	}
	
}
