package com.training.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.training.model.Employee;
import com.training.model.LeaveApplication;
import com.training.model.Manager;

public class Main {

	static List<Employee>employees= new ArrayList<>();
	static List<Manager>managers= new ArrayList<>();
	static List<LeaveApplication> leave= new ArrayList<>();
	static Scanner scanner = new Scanner(System.in);
	private static void insertData() {
	Employee employee1= new Employee(101, "HariHaran");
	Employee employee2= new Employee(102, "Hari");
	Employee employee3= new Employee(103, "Haran");
	Employee employee4= new Employee(104, "Kumar");
	Employee employee5= new Employee(105, "Ram");
	Employee employee6= new Employee(106, "Jai");
	Employee employee7= new Employee(107, "Gowtham");
	
	employees.add(employee1);
	employees.add(employee2);
	employees.add(employee3);
	employees.add(employee4);
	employees.add(employee5);
	employees.add(employee6);
	employees.add(employee7);

	Manager manager1=new Manager(1001, "Akash", "IT");
	Manager manager2=new Manager(1002, "Iyyappan", "HR");
	Manager manager3=new Manager(1003, "Rajan", "Admin");
	
	managers.add(manager1);
	managers.add(manager2);
	managers.add(manager3);
	}

	public static void main(String[] args) {
		insertData();
		
		String role;
		
		String loginName;
		
		while(true) {
		System.out.println("Are you manager or Employee : ");
		
		role=scanner.nextLine();
		if(role.equalsIgnoreCase("Employee")) {
			
			System.out.println("Enter your Name : ");
			
			loginName=scanner.nextLine();
			
			applyLeave(loginName);}
		if(role.equalsIgnoreCase("Manager")) {
			
			System.out.println("Enter your Name : ");
			
			loginName=scanner.nextLine();
			leaveRequest(loginName);
			
			leaveRequest(loginName);
		}
		System.out.println("Enter y to exit : ");
		String exit=scanner.nextLine();
		if(role.equalsIgnoreCase("Y")) {
		System.exit(0);
		}}
	}
		
		// if role is employee take input for leave application 
		//if the role is manager we should display all the leave application submitted to this manager 
		//Manager will see the list he will either approve or reject the leave
		//when an employee is already have a history of leave it should be displayed before the new leave apply 
	
	
	private static void applyLeave(String name) {
		boolean result=employees.stream().anyMatch(e->e.getName().equalsIgnoreCase(name));
		System.out.println(result);
		if(result) {
			System.out.println("Employee Id: ");
			
			int empId=Integer.parseInt(scanner.nextLine());
			
			System.out.println("Manager Id: ");
			
			int mngId=Integer.parseInt(scanner.nextLine());
			
			System.out.println("FromDate : ");
			
		    LocalDate fromDate=LocalDate.parse(scanner.nextLine());
		    
		    System.out.println("ToDate : ");
			
		    LocalDate toDate=LocalDate.parse(scanner.nextLine());
		    
		    System.out.println("Reason : ");

			String reason =scanner.nextLine();
			
			
			
		LeaveApplication application =new LeaveApplication(empId, mngId, fromDate, toDate, reason);
		
		leave.add(application);
	
		}
		
		
	}
	private static void leaveRequest(String name) {
		boolean result=managers.stream().anyMatch(e->e.getName().equalsIgnoreCase(name));
		if(result) {
			
			 System.out.println("Enter the manager Id : ");

				int id =scanner.nextInt();

				for (LeaveApplication leaves : leave) {
					if(leaves.getManagerId()==id) {
						System.out.println(leaves);
					}
				}
		}
		
        	   System.out.println("Enter Empid to select perticular Employee:");
       		int empId = scanner.nextInt();
       		for (LeaveApplication leaves : leave) {
       			if(leaves.getEmpId()==empId && leaves.getApprovedOrRejected()==null ) {
       				System.out.println("enter 1 approve 0 reject: ");

    				int approvel =Integer.parseInt(scanner.nextLine());
    				if(approvel==1) {

       				leaves.setApprovedOrRejected("approved");
       			}
    				if(approvel==0)
    				 {leaves.setApprovedOrRejected("Reject");
           }
		
		}
		
       		}}}
		



