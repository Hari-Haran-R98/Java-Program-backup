package com.training.model;

public class Employee {

	private int id;
	private String name;
	private double basicSalary;
	private boolean manager;
	private char gender;
	private char grade;
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public double getBasicSalary() {
		return basicSalary;
	}
	public boolean isManager() {
		return manager;
	}
	public char getGender() {
		return gender;
	}
	public char getGrade() {
		return grade;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public void setManager(boolean manager) {
		this.manager = manager;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + ", manager=" + manager
				+ ", gender=" + gender + ", grade=" + grade + "]";
	}
	
	
}
