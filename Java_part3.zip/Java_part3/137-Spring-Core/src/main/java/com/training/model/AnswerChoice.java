package com.training.model;

public class AnswerChoice {

	String answerTxt;
	boolean rightChooice;
	public String getAnswerTxt() {
		return answerTxt;
	}
	public boolean isRightChooice() {
		return rightChooice;
	}
	public void setAnswerTxt(String answerTxt) {
		this.answerTxt = answerTxt;
	}
	public void setRightChooice(boolean rightChooice) {
		this.rightChooice = rightChooice;
	}
	@Override
	public String toString() {
		return "AnswerChoice [answerTxt=" + answerTxt + ", rightChooice=" + rightChooice + "]";
	}
	
	
	
}
