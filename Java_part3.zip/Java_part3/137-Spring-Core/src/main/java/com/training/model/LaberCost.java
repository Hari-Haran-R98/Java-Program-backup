package com.training.model;

public class LaberCost {

	private int hrs;
	private double hourlyWage;
	public int getHrs() {
		return hrs;
	}
	public double getHourlyWage() {
		return hourlyWage;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public void setHourlyWage(double hourlyWage) {
		this.hourlyWage = hourlyWage;
	}
	
	public double getCalculateWage() {
		return this.hrs*this.hourlyWage;
	}
	@Override
	public String toString() {
		return "LaberCost [hrs=" + hrs + ", hourlyWage=" + hourlyWage + "]";
	}


}
