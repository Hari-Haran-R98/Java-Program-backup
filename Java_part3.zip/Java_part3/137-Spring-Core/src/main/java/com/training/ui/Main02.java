package com.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.HelloWorld;
import com.training.model.Shape;

public class Main02 {

	public static void main(String[] args) {

		HelloWorld helloWorld ;
		ApplicationContext context= new ClassPathXmlApplicationContext("beans.xml");
		helloWorld = (HelloWorld) context.getBean("helloWorldBean");
		System.out.println(helloWorld.getMessage());
		
	}
}
