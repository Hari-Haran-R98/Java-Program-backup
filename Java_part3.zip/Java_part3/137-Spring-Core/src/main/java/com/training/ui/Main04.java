package com.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.Student;

public class Main04 {

	public static void main(String[] args) {
		
		Student student1;
		Student student2;
		Student student3;
		
		ApplicationContext context= new ClassPathXmlApplicationContext("beans.xml");

		student1= (Student) context.getBean("StudentBean");
		System.out.println(student1);
		student1.setRollNumber(101);
		System.out.println(student1);
	
		student2= (Student) context.getBean("StudentBean");
		System.out.println(student2);
		student2.setRollNumber(102);
		System.out.println(student2);
	
		student3= (Student) context.getBean("StudentBean");
		System.out.println(student3);
		student3.setRollNumber(101);
		System.out.println(student3);
	
	}
}
