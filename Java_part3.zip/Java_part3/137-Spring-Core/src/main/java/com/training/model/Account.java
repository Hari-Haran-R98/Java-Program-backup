package com.training.model;

public class Account {

	int accId;
	String type;
	double balance;
	public int getAccId() {
		return accId;
	}
	public String getType() {
		return type;
	}
	public double getBalance() {
		return balance;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", type=" + type + ", balance=" + balance + "]";
	}
	
	
}
