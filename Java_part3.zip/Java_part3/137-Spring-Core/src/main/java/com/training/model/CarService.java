package com.training.model;

public class CarService {

	Spare spare;
	LaberCost laberCost;
	double totalcost;
	
	public Spare getSpare() {
		return spare;
	}
	public LaberCost getLaberCost() {
		return laberCost;
	}
	public double getTotalcost() {
		return this.totalcost+laberCost.getCalculateWage()+spare.spareCost;
	}
	public void setSpare(Spare spare) {
		this.spare = spare;
	}
	public void setLaberCost(LaberCost laberCost) {
		this.laberCost = laberCost;
	}
	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}
	@Override
	public String toString() {
		return "CarService [spare=" + spare + ", laberCost=" + laberCost + ", totalcost=" + totalcost + "]";
	}
	
	
}
