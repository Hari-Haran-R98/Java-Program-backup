package com.training.model;

public class Spare {

	String spareName;
	double spareCost;
	public String getSpareName() {
		return spareName;
	}
	public double getSpareCost() {
		return spareCost;
	}
	public void setSpareName(String spareName) {
		this.spareName = spareName;
	}
	public void setSpareCost(double spareCost) {
		this.spareCost = spareCost;
	}
	@Override
	public String toString() {
		return "Spare [spareName=" + spareName + ", spareCost=" + spareCost + "]";
	}
	
}
