package com.training.ui;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.CarService;
import com.training.model.SalesEmployee;

public class Main14 {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		SalesEmployee salesEmployee=(SalesEmployee) context.getBean("salesEmployee");
		
		System.out.println(salesEmployee);
		context.close();
	}
}
