package com.training.ui;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.Customer;

public class Main12 {

	public static void main(String[] args) {
ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		Customer customer=(Customer) context.getBean("customerBean");
		
		System.out.println(customer);
		context.close();
	}
}
