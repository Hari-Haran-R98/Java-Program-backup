package com.training.model;

import java.util.LinkedList;
import java.util.List;

public class EmployeeManagement {

	List<Employee> employees;
	
	
	
	@Override
	public String toString() {
		return "EmployeeManagement [employees=" + employees + "]";
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public void initialize() {
		this.employees= new LinkedList<Employee>();
		System.out.println("initialing employees");
	}
	
	public void cleanUp() {
		this.employees.clear();
		this.employees=null;
		
	}
}
