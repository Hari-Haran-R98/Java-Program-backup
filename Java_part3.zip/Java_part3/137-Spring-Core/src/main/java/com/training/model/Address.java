package com.training.model;

public class Address {

	private String doorNo;
	private String pincode;
	public String getDoorNo() {
		return doorNo;
	}
	public String getPincode() {
		return pincode;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", pincode=" + pincode + "]";
	}
	
	
	
}
