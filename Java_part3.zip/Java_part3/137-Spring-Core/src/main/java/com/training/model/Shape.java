package com.training.model;

public interface Shape {

	double getArea();
	
	void setSize(int size);
	
}
