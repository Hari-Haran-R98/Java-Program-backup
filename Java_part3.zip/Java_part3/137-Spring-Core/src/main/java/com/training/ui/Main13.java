package com.training.ui;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.CarService;
import com.training.model.Customer;

public class Main13 {
public static void main(String[] args) {
	ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	
	CarService service=(CarService) context.getBean("carServiceBean");
	
	System.out.println(service);
	context.close();
}
}
