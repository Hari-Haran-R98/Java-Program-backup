package com.training.model;

public interface Loan {

	void setLoanAmount(double amount);
	
	double getIntrestAmount();
	
	
}
