package com.training.model;

import java.util.Arrays;

public class Person {

	String name;
	int age;
	String[] emailId;
	String[] contactNumbers;
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String[] getEmailId() {
		return emailId;
	}
	public String[] getContactNumbers() {
		return contactNumbers;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setEmailId(String[] emailId) {
		this.emailId = emailId;
	}
	public void setContactNumbers(String[] contactNumbers) {
		this.contactNumbers = contactNumbers;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", emailId=" + Arrays.toString(emailId) + ", contactNumbers="
				+ Arrays.toString(contactNumbers) + "]";
	}
	
	
}
