package com.training.model;

public class HomeLoan implements Loan{

	double la;
	
	@Override
	public void setLoanAmount(double amount) {
		this.la=amount;
		
	}

	@Override
	public double getIntrestAmount() {
		
		return this.la*12*0.11;
	}

	public double getLa() {
		return la;
	}

	public void setLa(double la) {
		this.la = la;
	}

	@Override
	public String toString() {
		return "HomeLoan [la=" + la + "]";
	}

	
}
