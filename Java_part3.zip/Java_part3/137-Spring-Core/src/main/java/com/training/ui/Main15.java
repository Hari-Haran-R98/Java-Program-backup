package com.training.ui;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.SalesEmployee;
import com.training.model.Student;

public class Main15 {

	public static void main(String[] args) {
ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		Student student=(Student) context.getBean("studentBean");
		
		System.out.println(student);
		context.close();

	}
}
