package com.training.ui;


import java.util.List;

import com.training.linkedlist.LinkedList;

public class Main {

	public static void main(String[] args) {
		Customer customer1= new Customer(103, "Hari");
		Customer customer2= new Customer(104, "Haran");
		Customer customer3= new Customer(105, "Muruga");
		
	LinkedList<Customer> customers;
	customers=new LinkedList<Customer>();
	customers.addToList(customer1);
	customers.addToList(customer2);
	customers.addToList(customer3);
	System.out.println("=================================");
	

	Customer customer4= new Customer(106, "Vellava");
	
	System.out.println(customers.count());
	customers.display();
	System.out.println("========================================");
	customers.insertAfter(customer2, customer4);
	
	customers.display();
	
}}
