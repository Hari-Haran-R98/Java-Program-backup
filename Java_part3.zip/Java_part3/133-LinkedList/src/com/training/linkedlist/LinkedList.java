package com.training.linkedlist;

import java.util.List;

import com.training.ui.Customer;

public class LinkedList<T> {

	public static Node start=null;
	public void addToList(T data) {
		Node<Customer> nodenew= new Node(data);
		nodenew.nextnode=null;
		
		if(start==null) {
			start=nodenew;
		}
		else {
			Node current=start;
			while(current.nextnode !=null) {
				current=current.nextnode;
			}
			current.nextnode=nodenew;
		}
		
	}
	public int count() {
		int countofList=0;
		Node<T> current=start;
		while(current!=null) {
			current=current.nextnode;
			countofList++;
		}
		return countofList;
	}
	
	public void insertAfter(T position,T data) {
		
		if(position==null && start!=null) {
			Node<T> newNode= new Node(data);
			newNode.nextnode=start;
			start=newNode;
		}
		int index=0;
		Node<T> current=start;
		Node<T> previous = null;
		while(current!=null) {
			index++;
			
			previous=current;
			
			if(current.data==position)
			break;
			current=current.nextnode;
		}
		Node<T> newNode= new Node(data);
		
		
			
		newNode.nextnode=current.nextnode;
		current.nextnode=newNode;
	}
	
	public void display() {
		Node<T> current=start;
		while(current!=null) {
			System.out.println(current.data);
			current=current.nextnode;
		
		
	}

	
	}}
