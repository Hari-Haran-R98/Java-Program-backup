package com.training.linkedlist;

public class Node<T> {

	public T data;
	public Node<T> nextnode;
	
	Node(T data){
		this.data=data;
		nextnode=null;
	}
}
