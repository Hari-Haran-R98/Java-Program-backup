package com.training.model;

public class Account {

	static String accountNumber;
	static String acountHolder;
	static double balance;
	public Account(String accountNumber, String acountHolder, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.acountHolder = acountHolder;
		this.balance = balance;
	}
	public Account() {
		super();
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public String getAcountHolder() {
		return acountHolder;
	}
	public double getBalance() {
		return balance;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public void setAcountHolder(String acountHolder) {
		this.acountHolder = acountHolder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", acountHolder=" + acountHolder + ", balance=" + balance
				+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Account))
			return false;
		Account other = (Account) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		return true;
	}
	
	public static double deposit(double amt) {
		return balance+amt;
	}
	public static double withdraw(double amt) {
		if(balance>100) {
		return balance-amt;}
		System.out.println("Overdraft limit reached");
		return balance;
	}
	
}
