package com.training.model;

public class CurrentAccount extends Account{

}
