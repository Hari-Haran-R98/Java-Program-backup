package com.training.model;

public class SavingsAccount extends Account{

}
