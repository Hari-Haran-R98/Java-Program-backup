package com.training.ui;

public class Main01 {

	public static void main(String[] args) throws Exception {
		MenuHandlerCustomer handler = new MenuHandlerCustomer();
		int choice;
		do {
			System.out.println("   ");
			handler.displayMenu();
			choice = handler.getChoice();
			System.out.println("  ");
			ChoiceHandlerCustomer.handleChoice(choice);
		} while (choice < 6);
	}
	
}
