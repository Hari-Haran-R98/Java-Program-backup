package com.training.db;

import java.sql.Connection;

import java.util.List;

import com.training.model.Customer;

public interface CustomerMysqDAO {
	

	String INSERT_QRY="insert into customers value(?,?,?,?,?)";
	String UPDATE_QRY="update customers set name=?,balance=?,email=?,phone=? where id=?";
	String DELETE_QRY="delete from customers where id =?";
	String SEARCH_QRY="select * from customers where id=?";
	String FINDALL_QRY="select * from customers";
	
	boolean insertCustomer(Connection connection,Customer customer);
	boolean updateCustomer(Connection connection,Customer customer);
	boolean deleteCustomer(Connection connection,Customer customer);
	Customer findCustomerById(Connection connection,int id);
	List<Customer> findAllCustomer(Connection connection);
	
//	
//	boolean searchStudent(Connection connection,Student student);
//	boolean findallStudent(Connection connection,Student student);
	
	
	
	
}
