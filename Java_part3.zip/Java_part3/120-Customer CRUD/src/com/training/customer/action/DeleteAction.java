package com.training.customer.action;

import com.training.action.exception.InvalidRollNumber;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;
import com.training.ui.util.ConsoleIO;

public class DeleteAction extends Action {

	boolean status = false;
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Delete  Student");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() throws Exception {
		
		System.out.println("\t\t Deteting Customer");
		int idTODelete = 0;
try {
		ConsoleIO.prompt("Enter Customer ID Number to Delete ");
		idTODelete = ConsoleIO.intInput();
		if(idTODelete < 100 ) {
			InvalidRollNumber e= new InvalidRollNumber("Incorrect Customer Id "+idTODelete);
			throw e;
			}}
		catch (InvalidRollNumber e) {
			System.err.println(e);
			System.exit(0);
		}


		CustomerService service = new CustomerServiceImpl();
		status =service.deleteCustomer(idTODelete);

	}	

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true)
		System.out.println("\t\t Deleting Customer Completed");
		System.out.println("\n\n");
		if(status==false)
			System.out.println("\t\t Deleting Customer failed");
			System.out.println("\n\n");
		

	}

}
