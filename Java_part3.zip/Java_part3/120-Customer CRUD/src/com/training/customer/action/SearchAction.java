package com.training.customer.action;

import com.training.action.exception.InvalidRollNumber;
import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;
import com.training.ui.util.ConsoleIO;

public class SearchAction extends Action {

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Search Customer");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() throws Exception {
		System.out.println("\t\t Searching a Customer");
		int searchCustomerId = 0;
		try {
		ConsoleIO.prompt("Enter Customer ID to search ");
		searchCustomerId = ConsoleIO.intInput();
		if(searchCustomerId < 100 ) {
			InvalidRollNumber e= new InvalidRollNumber("Incorrect CustomerID "+searchCustomerId);
			throw e;
			}}
		catch (InvalidRollNumber e) {
			System.err.println(e);
			System.exit(0);
		}

		CustomerService service = new CustomerServiceImpl();
		Customer customer = service.searchCustomer(searchCustomerId);
		if (customer != null) {
			System.out.println("\t\t Customer ID : " + customer.getId());
			System.out.println("\t\t Name        : " + customer.getName());
			System.out.println("\t\t Balance     : " + customer.getBalance());
			System.out.println("\t\t Email       : " + customer.getEmail());
			System.out.println("\t\t Phone       : " + customer.getPhone());
			}
		else {
			System.out.println("\n\n\t\t Student Not Found !!! ");
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\t Searching Student Completed");
		System.out.println("\n\n");

	}

}
