package com.training.customer.action;

import java.util.List;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;

public class ListAction extends Action {

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Customer");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() {
		CustomerService service =new CustomerServiceImpl();
		List<Customer> customerList = service.getAllCustomer();
		if (customerList == null || customerList.isEmpty()) {
			System.out.println("\n\n\t\t No Customer Found !!!");
		} else {
			System.out.printf("\t\tID \tName \t\t Balance \t Email \t Phone \n");
			customerList.stream().forEach((s) -> {
				System.out.printf("\t\t%d \t %-20s \t %10.2f \t %s \t %s\n", s.getId(), s.getName(),
						s.getBalance(), s.getEmail(), s.getPhone());
		});

	}}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Customer Completed");
		System.out.println("\n\n");
	}

}
