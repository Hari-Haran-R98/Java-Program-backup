package com.training.customer.action;

public abstract class Action {

	public final void go()  {
		init();
		try {
			execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		complete();
	}

	public abstract void init();

	public abstract void execute() throws Exception;

	public abstract void complete();
}
