package com.training.customer.action;

import com.training.action.exception.InvalidGenderException;

import com.training.action.exception.InvalidMarkException;
import com.training.action.exception.InvalidRollNumber;
import com.training.action.exception.InvalidStudentName;
import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;
import com.training.ui.util.ConsoleIO;

public class UpdateAction extends Action {
 
	boolean status=false;
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Update Customer");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() throws Exception {
		System.out.println("\t\t Enter Customer ID to Updating");

		int id=0;
		String name=null;
		double balance=0;
		String email =null;
		String phone=null;

		try {
			ConsoleIO.prompt("Enter Customer ID Number");
			id = ConsoleIO.intInput();
			if(id < 100 ) {
				InvalidRollNumber e= new InvalidRollNumber("Incorrect CustomerId "+id);
				throw e;
				}
			
			}
			catch (InvalidRollNumber e) {
				System.err.println(e);
				System.exit(0);
			}
			try {
			ConsoleIO.prompt("Enter Name");
			name = ConsoleIO.stringInput();
			if(name==null || name.length()==0) {
				InvalidStudentName e1= new InvalidStudentName("name is invalid "+name);
				throw e1;
			}}
			catch (InvalidStudentName e1) {
				System.err.println(e1);
				System.exit(0);
			}
			try {
				ConsoleIO.prompt("Enter Balance");
				balance = ConsoleIO.doubleInput();
				if( balance < 0) {
					InvalidGenderException e2= new InvalidGenderException("invalid balance is "+balance);
					throw e2;
				}}
				catch (Exception e2) {
					System.err.println(e2);
					System.exit(0);
				}
				try {
				ConsoleIO.prompt("Enter email");
				email = ConsoleIO.stringInput();
				if(email ==null || email.length()==0) {
					InvalidMarkException e3= new InvalidMarkException("Incorrect email "+ email);
					throw e3;
					}
				
				}catch (Exception e3) {
					System.err.println(e3);
					System.exit(0);
				}
				try {
					ConsoleIO.prompt("Enter phone");
					phone = ConsoleIO.stringInput();
					if(phone ==null || phone.length()==0) {
						InvalidMarkException e4= new InvalidMarkException("Incorrect phone "+phone);
						throw e4;
						}
					

				} catch (Exception e4) {
					System.err.println(e4);
					System.exit(0);
				}
				
				Customer customer= new Customer(id, name, balance, email, phone);
				CustomerService service= new CustomerServiceImpl();
				status=service.updateCustomer(customer);
				
			}

			@Override
			public void complete() {
				System.out.println("\n\n");
				if(status==true)
				System.out.println("\t\t Updating customer Completed Successfully");
				System.out.println("\n\n");
				if(status==false)
				System.out.println("\t\t updating Customer failed ");
				System.out.println("\n\n");

			}

			
}