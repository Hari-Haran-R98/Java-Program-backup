package com.training.action;

import java.util.List;

import com.training.model.Student;
import com.training.service.StudentService;
import com.training.service.StudentServiceImpl;

public class ListAction extends Action {

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Student");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() {
		StudentService service =new StudentServiceImpl();
		List<Student> studentlist = service.getAllStudents();
		if (studentlist == null || studentlist.isEmpty()) {
			System.out.println("\n\n\t\t No Student Found !!!");
		} else {
			System.out.printf("\t\tRollNo \tName \t\t Gender \t Mark1 \t Mark2 \t Total \t Average \n");
			studentlist.stream().forEach((s) -> {
				System.out.printf("\t\t%d \t %-20s \t %s \t %d \t %d \t %d \t %10.2f\n", s.getRollNumber(), s.getName(),
						s.getGender(), s.getMark1(), s.getMark2(), s.getTotal(), s.getAverage()

				);
			});
		}

	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Student Completed");
		System.out.println("\n\n");
	}

}
