package com.training.action;

import com.training.action.exception.InvalidRollNumber;
import com.training.model.Student;
import com.training.service.StudentService;
import com.training.service.StudentServiceImpl;
import com.training.ui.util.ConsoleIO;

public class SearchAction extends Action {

	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Search Student");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() throws Exception {
		System.out.println("\t\t Searching a student");
		int searchRollNumber = 0;
		try {
		ConsoleIO.prompt("Enter Roll Number to search ");
		searchRollNumber = ConsoleIO.intInput();
		if(searchRollNumber < 100 ) {
			InvalidRollNumber e= new InvalidRollNumber("Incorrect RollNumber "+searchRollNumber);
			throw e;
			}}
		catch (InvalidRollNumber e) {
			System.err.println(e);
			System.exit(0);
		}

		StudentService service = new StudentServiceImpl();
		Student student = service.searchStudent(searchRollNumber);
		if (student != null) {
			System.out.println("\t\t Roll Number : " + student.getRollNumber());
			System.out.println("\t\t Name        : " + student.getName());
			System.out.println("\t\t Gender      : " + student.getGender());
			System.out.println("\t\t Mark1       : " + student.getMark1());
			System.out.println("\t\t Mark2       : " + student.getMark2());
			System.out.println("\t\t Total       : " + student.getTotal());
			System.out.println("\t\t Average     : " + student.getAverage());
		} else {
			System.out.println("\n\n\t\t Student Not Found !!! ");
		}
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\t Searching Student Completed");
		System.out.println("\n\n");

	}

}
