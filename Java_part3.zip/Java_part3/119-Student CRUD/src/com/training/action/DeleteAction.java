package com.training.action;

import com.training.action.exception.InvalidRollNumber;
import com.training.service.StudentService;
import com.training.service.StudentServiceImpl;
import com.training.ui.util.ConsoleIO;

public class DeleteAction extends Action {

	boolean status = false;
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Delete  Student");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() throws Exception {
		
		System.out.println("\t\t Deteting student");
		int rollNumberTODelete = 0;
try {
		ConsoleIO.prompt("Enter Roll Number to Delete ");
		rollNumberTODelete = ConsoleIO.intInput();
		if(rollNumberTODelete < 100 ) {
			InvalidRollNumber e= new InvalidRollNumber("Incorrect RollNumber "+rollNumberTODelete);
			throw e;
			}}
		catch (InvalidRollNumber e) {
			System.err.println(e);
			System.exit(0);
		}

		StudentService service = StudentServiceImpl.getInstance();
		status =service.deleteStudent(rollNumberTODelete);

	}	

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true)
		System.out.println("\t\t Deleting Student Completed");
		System.out.println("\n\n");
		if(status==false)
			System.out.println("\t\t Deleting Student failed");
			System.out.println("\n\n");
		

	}

}
