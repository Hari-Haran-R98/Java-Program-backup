package com.training.action;

import com.training.action.exception.InvalidMarkException;
import com.training.action.exception.InvalidRollNumber;
import com.training.action.exception.InvalidStudentName;
import com.training.model.Student;
import com.training.service.StudentService;
import com.training.service.StudentServiceImpl;
import com.training.ui.util.ConsoleIO;

public class UpdateAction extends Action {
 
	boolean status=false;
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Update Student");
		System.out.println("\t\t ---------------------------------------");

	}

	@Override
	public void execute() throws Exception {
		System.out.println("\t\t Enter Rollnumber to Updating");

		int rollNumber=0;
		String name=null;
		char gender=0;
		int mark1=0;
		int mark2=0;

		try {
			ConsoleIO.prompt("Enter Roll Number");
			rollNumber = ConsoleIO.intInput();
			if(rollNumber < 100 ) {
				InvalidRollNumber e= new InvalidRollNumber("Incorrect RollNumber "+rollNumber);
				throw e;
				}
			
			}
			catch (InvalidRollNumber e) {
				System.err.println(e);
				System.exit(0);
			}
			try {
			ConsoleIO.prompt("Enter Name");
			name = ConsoleIO.stringInput();
			if(name==null || name.length()==0) {
				InvalidStudentName e1= new InvalidStudentName("name is invalid "+name);
				throw e1;
			}}
			catch (InvalidStudentName e1) {
				System.err.println(e1);
				System.exit(0);
			}
			//try {
			ConsoleIO.prompt("Enter Gender (F/M)");
			gender = ConsoleIO.charInput();
//			if( gender !='M' || gender != 'm' || gender != 'f' || gender !='F') {
//				InvalidGenderException e2= new InvalidGenderException("invalid grade is "+gender);
//				throw e2;
//			}}
//			catch (Exception e2) {
//				System.err.println(e2);
//				System.exit(0);
//			}
			try {
			ConsoleIO.prompt("Enter Mark1");
			mark1 = ConsoleIO.intInput();
			if(mark1 < 0 || mark1 >100) {
				InvalidMarkException e3= new InvalidMarkException("Incorrect mark1 "+mark1);
				throw e3;
				}
			
			}catch (Exception e3) {
				System.err.println(e3);
				System.exit(0);
			}
			try {
				ConsoleIO.prompt("Enter Mark2");
				mark2 = ConsoleIO.intInput();
				if(mark2 < 0 || mark2 >100) {
					InvalidMarkException e4= new InvalidMarkException("Incorrect mark1 "+mark1);
					throw e4;
					}
				Student student = new Student(rollNumber, name, gender, mark1, mark2);
				StudentService service= new StudentServiceImpl();
				 status=service.updateStudent(student);	

			} catch (Exception e4) {
				System.err.println(e4);
				System.exit(0);
			}

		

	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true) {
		System.out.println("\t\t Update Student Completed");
		System.out.println("\n\n");
		}
		else{
			System.out.println("\t\t Update Student Failed");
			System.out.println("\n\n");
				
		}
	}

}
