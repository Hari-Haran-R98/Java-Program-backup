package com.training.ui;

public class Main01 {

	public static void main(String[] args) throws Exception {
		MenuHandler handler = new MenuHandler();
		int choice;
		do {
			System.out.println("   ");
			handler.displayMenu();
			choice = handler.getChoice();
			System.out.println("  ");
			ChoiceHandler.handleChoice(choice);
		} while (choice < 6);
	}
}
