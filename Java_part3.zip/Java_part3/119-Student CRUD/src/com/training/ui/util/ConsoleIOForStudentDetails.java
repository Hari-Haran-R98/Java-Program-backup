package com.training.ui.util;

public class ConsoleIOForStudentDetails extends ConsoleIO{

	
}
